﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Common.Functional.Enum
{
    /// <summary>
    /// Cardless transaction Statuses
    /// </summary>
    public enum Statuses
    {
        Prestaged = 1,
        Completed = 2,
        Declined = 3,
        Deleted = 4
    }
}
