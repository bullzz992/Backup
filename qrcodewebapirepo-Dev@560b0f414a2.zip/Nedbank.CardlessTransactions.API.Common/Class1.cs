﻿using System;

namespace Nedbank.CardlessTransactions.API.Common
{
    public class Class1
    {
    }
}
