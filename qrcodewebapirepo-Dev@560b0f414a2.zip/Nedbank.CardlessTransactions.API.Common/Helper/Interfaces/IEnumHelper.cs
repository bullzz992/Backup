﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Common.Helper.Interfaces
{
    public interface IEnumHelper
    {
         bool IsDefined<T>(string strEnumText);

        bool IsDefined<T>(int iEnumValue);

        bool TryParse<T>(string text, out T enumValue) where T : struct;

        T GetDefault<T>();
    }
}
