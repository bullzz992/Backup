﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Common.Helper
{
    public interface ICommonHelper
    {
        DateTime ConvertStringIntoDateTime(string dateTime);

        string ConvertDateTimeIntoString(DateTime dateTime);

        bool CompareDate(DateTime dt1, DateTime dt2);

        bool CompareDateTime(DateTime dt1, DateTime dt2);



        public bool IsValidEmailId(string email);

        public string GetValidEmails(string emails);
        public HttpClient Client { get; }

        public Task<RS> PostAsync<RQ, RS>(string urlWithQueryString,
                                            RQ request, Dictionary<string, string> headers = null,
                                            string compressionAlgorithm = null,
                                            bool? expect100Continue = false);

        public string GetUserId();
        public string GetToken();
        public string GetNedBankId();
    }
}
