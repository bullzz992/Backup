﻿using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;
using Nedbank.CardlessTransactions.API.Common.Constants;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Common.Helper
{
    public class CommonHelper : ICommonHelper
    {
        private static readonly HttpClient client = new HttpClient();
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CommonHelper(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        private static readonly JsonSerializerSettings SerializerSettings = new JsonSerializerSettings()
        {
            NullValueHandling = NullValueHandling.Ignore
        };
        public HttpClient Client
        {
            get
            {
                var handler = new HttpClientHandler();
                if (handler.SupportsAutomaticDecompression)
                {
                    handler.AutomaticDecompression = DecompressionMethods.GZip |
                                                     DecompressionMethods.Deflate;

                }
                return new HttpClient(handler)
                {
                    Timeout = new TimeSpan(0, 5, 0)
                };
            }


        }

        //HttpClient ICommonHelper.Client { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public DateTime ConvertStringIntoDateTime(string dateTime)
        {
            return DateTime.ParseExact(dateTime, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
        }

        public string ConvertDateTimeIntoString(DateTime dateTime)
        {
            return dateTime.ToString("yyyy-MM-dd HH:mm");
        }

        public string GenerateRefNo(int appointmentId)
        {
            return (appointmentId.ToString().Length < 7) ? "NDR" + new string('0', (6 - appointmentId.ToString().Length)) + appointmentId.ToString() : "NDR" + appointmentId.ToString();
        }

        /// <summary>
        /// Compare date only not time.
        /// </summary>
        /// <param name="dt1"></param>
        /// <param name="dt2"></param>
        /// <returns></returns>
        public bool CompareDate(DateTime dtOne, DateTime dtTwo)
        {
            return dtOne.Year == dtTwo.Year && dtOne.Month == dtTwo.Month && dtOne.Day == dtTwo.Day;
        }

        /// <summary>
        /// Compare date with time.
        /// </summary>
        /// <param name="dtOne"></param>
        /// <param name="dtTwo"></param>
        /// <returns></returns>
        public bool CompareDateTime(DateTime dtOne, DateTime dtTwo)
        {
            return dtOne.Year == dtTwo.Year && dtOne.Month == dtTwo.Month && dtOne.Day == dtTwo.Day && dtOne.Hour == dtTwo.Hour && dtOne.Minute == dtTwo.Minute;
        }


        /// <summary>
        /// Method to Validate Email collection(semi colon ; separated) and remove invalid emails.
        /// </summary>
        /// <param name="emails">The emails.</param>
        /// <returns>Returns only valid emails</returns>
        public string GetValidEmails(string emails)
        {
            string validEmails = string.Empty;
            emails = emails.Replace(";", ",");
            string[] emailCollection = emails.Split(',');
            foreach (string email in emailCollection)
            {
                if (!string.IsNullOrEmpty(email) && IsValidEmailId(email))
                {
                    validEmails += email + ",";
                }
            }

            if (!string.IsNullOrEmpty(validEmails) && validEmails.Length > 0)
                validEmails = validEmails.Substring(0, validEmails.Length - 1);

            return validEmails;
        }

        /// <summary>
        /// Method is used to match email.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns>Returns if mail is valid</returns>
        public bool IsValidEmailId(string email)
        {
            if (!string.IsNullOrEmpty(email))
            {
                return Regex.IsMatch(email.Trim(), GlobalConstants.Email);
            }
            else
            {
                return false;
            }

        }


        public async Task<RS> PostAsync<RQ, RS>(string urlWithQueryString, RQ request,
                                                Dictionary<string, string> headers = null, string compressionAlgorithm = null,
                                                bool? expect100Continue = false)
        {
            var client = default(HttpClient);
            try
            {
                Uri uri = new Uri(urlWithQueryString);
                var jsonRequest = JsonConvert.SerializeObject(request, SerializerSettings);
                byte[] bytes = Encoding.UTF8.GetBytes(jsonRequest);
                ByteArrayContent byteArrayAsHttpContent = new ByteArrayContent(bytes);
                byteArrayAsHttpContent.Headers.ContentLength = bytes.LongLength;
                byteArrayAsHttpContent.Headers.ContentType = System.Net.Http.Headers.MediaTypeHeaderValue.Parse("application/json");
                client = Client;
                if (headers != null && headers.Any())
                {
                    client.DefaultRequestHeaders.Clear();
                    if (!string.IsNullOrEmpty(compressionAlgorithm))
                    {
                        client.DefaultRequestHeaders.Add("Accept-Encoding", compressionAlgorithm);
                    }
                    if (expect100Continue.HasValue && expect100Continue.Value)
                    {
                        client.DefaultRequestHeaders.ExpectContinue = true;
                    }
                    else
                    {
                        client.DefaultRequestHeaders.ExpectContinue = false;
                    }
                    foreach (var item in headers)
                    {
                        try
                        {
                            client.DefaultRequestHeaders.TryAddWithoutValidation(item.Key, item.Value);
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
                //For authorization Token sending in request header
                //if (!string.IsNullOrEmpty(authToken))
                //{
                //    //client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "Bearer " + authToken);
                //    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authToken);
                //}
                HttpResponseMessage apiResponse = await client.PostAsync(uri, byteArrayAsHttpContent);
                string jsonResponse = await apiResponse.Content.ReadAsStringAsync();
                if ((int)apiResponse.StatusCode == (int)HttpStatusCode.Unauthorized)
                {
                    throw new UnauthorizedAccessException("You are not authorized to perform this operation!");
                }
                apiResponse.EnsureSuccessStatusCode();
                return JsonConvert.DeserializeObject<RS>(jsonResponse);
            }
            finally
            {
                if (client != null)
                {
                    client.Dispose();
                }
            }
        }




        public string GetUserId()
        {
            var userId = string.Empty;

            var context = _httpContextAccessor.HttpContext;

            if (context != null && context.User != null && context.User.Identity != null && context.User.Identity.IsAuthenticated)
            {

                var identity = context.User.Identity as ClaimsIdentity;

                if (identity != null)
                {
                    IEnumerable<Claim> claims = identity.Claims;
                    userId = identity.FindFirst("BusinessEntityUserId").Value;
                }
            }
            return userId;
        }
        public string GetToken()
        {
            var token = string.Empty;

            if (_httpContextAccessor.HttpContext != null && _httpContextAccessor.HttpContext.Request != null)
            {
                token = AuthenticationHeaderValue.Parse(_httpContextAccessor.HttpContext.Request.Headers[HeaderNames.Authorization]).Parameter;
            }

            return token;
        }
        /// <summary>
        /// For getting the NedbankId from Auth Token
        /// </summary>
        /// <returns></returns>
        public string GetNedBankId()
        {
            string nedBankId = string.Empty;
            var context = _httpContextAccessor.HttpContext;
            if (context != null && context.User != null && context.User.Identity != null && context.User.Identity.IsAuthenticated)
            {
                var identity = context.User.Identity as ClaimsIdentity;
                if (identity != null)
                {
                    IEnumerable<Claim> claims = identity.Claims;
                    nedBankId = identity.FindFirst("NedbankId").Value;
                }
            }
            return nedBankId;
        }
    }
}

