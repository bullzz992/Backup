﻿using Nedbank.CardlessTransactions.API.Common.Helper.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Common.Helper
{
    public class EnumHelper: IEnumHelper
    {
        public bool IsDefined<T>(string strEnumText)
        {
            string s = strEnumText.Trim().ToUpper();
            string[] names = Enum.GetNames(typeof(T));
            foreach (string n in names)
            {
                if (n.ToUpper() == s)
                {
                    return true;
                }
            }
            return false;
        }

        public bool IsDefined<T>(int iEnumValue)
        {
            int[] vals = (int[])Enum.GetValues(typeof(T));
            foreach (int i in vals)
            {
                if (iEnumValue == i)
                {
                    return true;
                }
            }
            return false;
        }

        public bool TryParse<T>(string text, out T enumValue) where T : struct
        {
            if (IsDefined<T>(text))
            {
                enumValue = (T)Enum.Parse(typeof(T), text, true);
                return true;
            }
            else
            {
                enumValue = GetDefault<T>();
                return false;
            }
        }

        public T GetDefault<T>()
        {
            if (IsDefined<T>("None"))
            {
                return (T)Enum.Parse(typeof(T), "None", true);
            }
            else if (IsDefined<T>(0))
            {
                return (T)Enum.ToObject(typeof(T), 0);
            }
            else
            {
                throw new ArgumentException("No default value found for type " + typeof(T).FullName);
            }
        }
    }
}
