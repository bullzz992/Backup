﻿using System;
using System.Runtime.Serialization;

namespace Nedbank.CardlessTransactions.API.Common.Constants
{
    public class GlobalConstants
    {
        public static class ResultCodes
        {
            public const string SuccessCode = "R00";
            public const string RecordNotFound = "R11";
            public const string ErrorCodeR10 = "R10";
            public const string ErrorCodeR02 = "R02";
            public const string ErrorCodeR04 = "R04";
            public const string ErrorCodeR03 = "R03";
            public const string ErrorCodeR01 = "R01";
            public const string ErrorCodeR05 = "R05";
        }

        public const string EmailTagFormat = "{{#{0}}";
        public const string Email = @"^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";

        // EWOC JWT Token User Claims Constants 

        public const string UserAccessClaimName = "scopes";
        public const string UserAccessClaimValue_EWOCBOCAdministrator = "EWOCBOCAdministrator";
        public const string UserAccessClaimValue_Staff = "Staff";

        // Prestage constants
        public static class PrestageConstants
        {
            public const int PrestageReqValidUpto = 8;
            public const int MinWithdrawalAmount = 100;
            public const int MaxWithdrawalAmount = 5000;
        }
        public static class BackOfficeNotificationConstants
        {
            public const string Heading = "NEDBANK MONEY";
            public const string NotificationType = "INF";
            #region Success PreStaged Constants
            public const string PreStagedBody = "R{ waiting for you to withdraw.";
            public const string PreStagedSubHeading = "QR Code Withdrawals";
            public const string PrestagedDisplayCategory = "CardLess Transaction";
            public const string PrestagedDisplaySubCategory = "QR Code Withdrawals";
            public const string url = "";
            #endregion
            #region Failure Case

            #endregion

        }
        public static class ErrorMessages
        {
            public const string Invaid_Arguments = "Inavlid arguments.";
            public const string PrestageStatus_cdnt_Retireved = "Prestage transaction status couldn't be retrieved.";
            public const string PrestageReq_NotFound = "No QRCode withdrawal request was found.";
            public const string Prestage_Status_NotChanged = "QRCode withdrawal request status couldn't be changed.";
            public const string ID_SHDBE_GRTR_THN_ZERO = "Invalid Id: Id should be greater than 0.";
            public const string Prestage_Statuses_Cdnt_Retrieved = "Prestage statuses could not be retrieved.";
            public const string Active_Prestage_Req = "You already have a QRCode withdrawal request in Prestaged state that is not expired yet!";
            public const string QRCode_withdrl_Cntbe_Created = "QRCode withdrawal request can't be created.";
            public const string No_Active_PestageReq_Found = "You don't have active QRCode withdrawal request.";
            public const string Dont_Have_Permission = "You don't have permission to access this resource.";

            #region QR Code Endpoint 
            public const string QR_Code_Not_Created = "Not able to get the qr Code, Please try again";
            public const string No_PreStage_Data_Found = "No preStage Data found for preStageId: ";
            public const string QR_Code_Expired = "QR code has been expired for preStageId :";
            public const string QR_Not_Found = "No QR Code has been found for preStageId:-";
            public const string Notification_Not_Sent = "Not able to send the notification to ATM to dispense cash.";
            public const string Bad_Request = "Required fields are missing";
            #endregion
        }

    }
}

