using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Nedbank.CardlessTransactions.CommandHub.API.Application.Authentication;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.NotificationHub;
using Nedbank.EAPI.SDK.Builder;
using Nedbank.EAPI.SDK.DependencyInjection;
using System;

namespace Nedbank.CardlessTransactions.CommandHub.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSignalR(hubOptions =>
            {
                hubOptions.ClientTimeoutInterval = TimeSpan.FromSeconds(60);
                hubOptions.EnableDetailedErrors = true;
            });
            //CoE framework configuration.
            ServiceConfiguration.ConfigureServices(services, Configuration);
            services.Configure<ClientSecret>(Configuration.GetSection("ClientSecret"));
            var coreEnableUrl = Configuration.GetSection("CoreEnableUrl").Value;
            services.AddCors(options =>
            {
                options.AddPolicy("corePolices", builder =>
                builder.WithOrigins(coreEnableUrl)
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    .AllowCredentials()
                    .SetIsOriginAllowed((host) => true));

                //options.AddPolicy("AllowAll", builder => builder.AllowAnyOrigin()
                //                .AllowAnyHeader()
                //                .AllowAnyMethod());
            });

            services.AddSingleton<IConnectionManager, ConnectionManager>();
            services.AddSingleton<IHubNotificationManager, HubNotificationManager>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddFile("Logs/CommandHub-{Date}.txt");
            app.UseCors("corePolices");
            PipelineConfiguration.Configure(app, env, Configuration);
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            //app.UseMiddleware<HubAuthentication>();

            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHub<ATMNotificationHub>("/atmNotificationHub");
            });
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
