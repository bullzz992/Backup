﻿using Microsoft.AspNetCore.SignalR;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;
using System;
using System.Threading.Tasks;

//namespace Nedbank.CardlessTransactions.CommandHub.API.Application.NotificationHub
namespace Nedbank.CardlessTransactions.CommandHub.API.Domain.NotificationHub
{
    public class ATMNotificationHub : Hub
    {
        private readonly IConnectionManager _manager;

        //public IHubNotificationManager HubNotification { get; }

        //public ATMNotificationHub(IConnectionManager manager, IHubNotificationManager hubNotification)
        //{
        //    this._manager = manager;
        //    HubNotification = hubNotification;
        //}
        public ATMNotificationHub(IConnectionManager manager)
        {
            this._manager = manager;
        }
        public override Task OnConnectedAsync()
        {
            return base.OnConnectedAsync();
        }
        public async Task RegisterConnectionId(string terminalId, string transactionId)
        {
            await _manager.AddConnection(terminalId, transactionId, Context.ConnectionId);
        }
        public override Task OnDisconnectedAsync(Exception exception)
        {
            //Remove connectionId from available terminal 
            _manager.RemoveConnection(Context.ConnectionId);
            return base.OnDisconnectedAsync(exception);
        }

    }
}
