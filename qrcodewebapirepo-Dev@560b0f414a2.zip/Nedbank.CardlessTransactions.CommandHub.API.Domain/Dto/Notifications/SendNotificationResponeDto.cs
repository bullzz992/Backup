﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications
{
    public class SendNotificationResponseDto
    {
        public string TransactionId { get; set; }
        public string TerminalId { get; set; }
        public long Amount { get; set; }
        public string AccountType { get; set; }
        public string CardNumber { get; set; }
        public string CardExpiryDate { get; set; }
        public bool IsValid { get; set; }
    }
}
