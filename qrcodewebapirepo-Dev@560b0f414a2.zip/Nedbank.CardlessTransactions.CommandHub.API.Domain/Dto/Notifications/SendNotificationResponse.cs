﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.CommandHub.API.Domain.Dto.Notifications
{
    public class SendNotificationResponse
    {
        public bool IsSuccess { get; set; }
    }
}
