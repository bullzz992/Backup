﻿
using Microsoft.Extensions.Logging;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Dto.Notifications;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;

using Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications;
using System;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager
{
    public class HubNotificationManager : IHubNotificationManager
    {
        private readonly IConnectionManager _connectionManager;
        private readonly ILogger<HubNotificationManager> _logger;

        //public IHubContext<ATMNotificationHub> _hubContext { get; }
        //public HubNotificationHelper(IHubContext<ATMNotificationHub> hubContext, IConnectionManager connectionManager)
        //{
        //    _hubContext = hubContext;
        //    this._connectionManager = connectionManager;
        //}
        public HubNotificationManager(IConnectionManager connectionManager, ILogger<HubNotificationManager> logger)
        {
            _connectionManager = connectionManager;
            this._logger = logger;
        }
        public async Task<SendNotificationResponse> SendNotication(SendNotificationDto input)
        {
            _logger.LogInformation("Inside HubNotificationManager SendNotication");
            SendNotificationResponse response = new SendNotificationResponse();
            bool status = false;
            string connectionId = _connectionManager.GetConnections(input.TerminalId, input.TransactionId);
            try
            {
                if (!string.IsNullOrEmpty(connectionId))
                {
                    try
                    {
                        _logger.LogInformation($"HubNotificationManager SendNotication: calling SendDispenseCashhNotification, Connectionid: {connectionId}");
                        status =await _connectionManager.SendDispenseCashhNotification(connectionId, input);
                        response.IsSuccess = status;
                    }
                    catch (Exception ex)
                    {
                        var sb = new StringBuilder();
                        sb.AppendLine($"Error message:{ex.Message}");
                        sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                        _logger.LogError($"HubNotificationManager SendNotication: {sb.ToString()}");
                        response.IsSuccess = false;
                    }
                }
                _logger.LogInformation($"Exit HubNotificationManager SendNotication: Response: {response.IsSuccess}");
                return response;
            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"Error message:{ex.Message}");
                sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                _logger.LogError($"HubNotificationManager SendNotication: {sb.ToString()}");
                response.IsSuccess = false;
                _logger.LogInformation($"Exit HubNotificationManager SendNotication: Response: {response.IsSuccess}");
                return response;
            }
        }
    }
}
