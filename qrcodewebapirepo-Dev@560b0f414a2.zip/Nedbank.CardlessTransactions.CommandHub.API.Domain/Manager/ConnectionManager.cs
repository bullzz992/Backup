﻿
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.NotificationHub;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager
{
    public class ConnectionManager : IConnectionManager
    {
        private Hashtable terminalAvailable = new Hashtable();
        private readonly ILogger<ConnectionManager> _logger;

        public IHubContext<ATMNotificationHub> _hubContext { get; }
        public ConnectionManager(IHubContext<ATMNotificationHub> hubContext, ILogger<ConnectionManager> logger)
        {
            _hubContext = hubContext;
            this._logger = logger;
        }

        public async Task AddConnection(string terminalId, string transactionId, string connectionId)
        {
            _logger.LogInformation($"Inside ConnectionManager AddConnection:terminalId: {terminalId},transactionId: {transactionId}, connectionId:{connectionId}.");
            string connectionKey = $"{terminalId}{transactionId}";
            _logger.LogInformation($"ConnectionManager AddConnection:connectionKey: {connectionKey}.");
            try
            {
                lock (terminalAvailable)
                {
                    if (!terminalAvailable.ContainsKey(connectionKey))
                    {
                        terminalAvailable.Add(connectionKey, connectionId);
                    }
                }
                // Sending Success msg to ATM
                _logger.LogInformation($"ConnectionManager AddConnection:Calling SendSuccessMessageToATM.");
                await _hubContext.Clients.Client(connectionId)
                                                    .SendAsync("ReceiveMessage", terminalId, transactionId, "Success");
            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"Error message:{ex.Message}");
                sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                _logger.LogError($"ConnectionManager AddConnection: {sb.ToString()}");
                _logger.LogInformation($"ConnectionManager AddConnection:Calling SendSuccessMessageToATM.");

                //await SendSuccessMessageToATM(terminalId, transactionId, connectionId, "Failed");
            }
        }
        public string GetConnections(string terminalId, string transactionId)
        {
            _logger.LogInformation($"Inside ConnectionManager GetConnections:terminalId: {terminalId},transactionId: {transactionId}.");
            string connectionId = string.Empty;
            string key = $"{terminalId}{transactionId}";
            try
            {
                lock (terminalAvailable)
                {
                    if (terminalAvailable.ContainsKey(key))
                    {
                        connectionId = terminalAvailable[key].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"Error message:{ex.Message}");
                sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                _logger.LogError($"ConnectionManager GetConnections: {sb.ToString()}");
                connectionId = null;
            }
            _logger.LogInformation($"Exit ConnectionManager GetConnections:connectionId: {connectionId}.");
            return connectionId;
        }
        public void RemoveConnection(string connectionId)
        {
            _logger.LogInformation($"Inside ConnectionManager RemoveConnection:connectionId: {connectionId}.");
            lock (terminalAvailable)
            {
                foreach (var terminal in terminalAvailable.Keys)
                {
                    if (terminalAvailable.ContainsKey(terminal))
                    {
                        if (terminalAvailable.ContainsValue(connectionId))
                        {
                            terminalAvailable.Remove(connectionId);
                            break;
                        }
                    }
                }
            }
            _logger.LogInformation($"Exit ConnectionManager RemoveConnection:connectionId: {connectionId}.");
        }
        //public async Task SendSuccessMessageToATM(string terminalId, string transactionId, string connectionId, string status)
        //{
        //    await _hubContext.Clients.Client(connectionId)
        //                                            .SendAsync("ReceiveMessage", terminalId, transactionId, status);
        //}

        public async Task<bool> SendDispenseCashhNotification(string connectionId, SendNotificationDto input)
        {
            _logger.LogInformation($"Inside ConnectionManager SendDispenseCashhNotification: connectionId: {connectionId}.");
            // Need to parse the object at Client side
            var response = ParseSendNotificationDto(input);
            var message = JsonConvert.SerializeObject(response);
            // Client-Side will check based on IsValid 
            await _hubContext.Clients.Client(connectionId)
                                                .SendAsync("ReceiveMessageCash", message);
            _logger.LogInformation($"Exit ConnectionManager SendDispenseCashhNotification.");
            return true;
        }
        private SendNotificationResponseDto ParseSendNotificationDto(SendNotificationDto sendNotificationDto)
        {
            return new SendNotificationResponseDto
            {
                Amount = sendNotificationDto.Amount,
                CardNumber = sendNotificationDto.CardNumber,
                CardExpiryDate = sendNotificationDto.CardExpiryDate,
                IsValid = sendNotificationDto.IsValid,
                TerminalId = sendNotificationDto.TerminalId,
                TransactionId = sendNotificationDto.TransactionId,
                AccountType = sendNotificationDto.AccountType
            };
        }
    }
}
