﻿using Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface
{
    public interface IConnectionManager
    {
        Task AddConnection(string terminalId, string transactionId, string connectionId);
        void RemoveConnection(string connectionId);
        string GetConnections(string termivalId, string transactionId);
        Task<bool> SendDispenseCashhNotification(string connectionId, SendNotificationDto input);
    }
}
