﻿using Nedbank.CardlessTransactions.CommandHub.API.Domain.Dto.Notifications;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface
{
    public interface IHubNotificationManager
    {
        Task<SendNotificationResponse> SendNotication(SendNotificationDto input);
    }
}
