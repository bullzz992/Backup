﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
//using Nedbank.CardlessTransactions.Models;

namespace Nedbank.CardlessTransactions.API.Controllers
{
    //[Route("/withdrawals/qrCode")]
    //[ApiController]
    //public class QRCodesController : ControllerBase
    //{
    //    /// <summary>
    //    /// Returns QRCode
    //    /// </summary>
    //    /// <param name="terminalId"></param>
    //    /// <param name="transactionId"></param>
    //    /// <returns></returns>
    //    [HttpGet("{transactionId}/{terminalId}")]
    //    public string Get(string terminalId, string transactionId)
    //    {
    //        return terminalId + transactionId;
    //    }

    //    /// <summary>
    //    /// Get the status of QRCode
    //    /// </summary>
    //    /// <param name="transactionId"></param>
    //    /// <returns></returns>
    //    [HttpGet("/withdrawals/qrCode/transaction/{transactionId}/status")]
    //    public string GetQRCodeStatus(string transactionId)
    //    {
    //        return "active";
    //    }

    //    /// <summary>
    //    /// This API will update the QRCode status
    //    /// </summary>
    //    /// <param name="transactionId"></param>
    //    /// <returns></returns>
    //    [HttpPut("/withdrawals/qrCode/transaction/{transactionId}/status")]
    //    public string UpdateQRCodeStatus(string transactionId)
    //    {
    //        return "active";
    //    }

    //    /// <summary>
    //    /// This API will scan, validate the QRCode
    //    /// </summary>
    //    /// <param name="value"></param>
    //    [HttpPost]
    //    public void Post([FromBody] QRCodeScan value)
    //    {
    //    }
//    }
}
