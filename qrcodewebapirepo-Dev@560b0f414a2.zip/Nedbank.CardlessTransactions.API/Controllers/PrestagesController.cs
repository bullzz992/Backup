﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Nedbank.CardlessTransactions.API.Controllers
{
    //[Route("/withdrawals/prestage")]
    //[ApiController]
    //public class PrestagesController : ControllerBase
    //{
    //    // GET: api/<PrestageController>
    //    [HttpGet]
    //    public IEnumerable<string> Get()
    //    {
    //        return new string[] { "value1", "value2" };
    //    }

    //    // GET api/<PrestageController>/5
    //    [HttpGet("{id}")]
    //    public string Get(int id)
    //    {
    //        return "value";
    //    }

    //    // GET prestage request status
    //    [HttpGet("/withdrawals/prestage/{id}/status")]
    //    public string GetStatus(int id)
    //    {
    //        return "value";
    //    }

    //    // GET Validate preatage request by prestage Id
    //    [HttpGet("/withdrawals/prestage/validate")]
    //    public string GetPrestageValidate(int id)
    //    {
    //        return "value";
    //    }

    //    // POST api/<PrestageController>
    //    [HttpPost]
    //    public void Post([FromBody] string value)
    //    {
    //    }

    //    // PUT api/<PrestageController>/5
    //    [HttpPut("{id}")]
    //    public void Put(int id, [FromBody] string value)
    //    {
    //    }

    //    // PUT update prestage request status after ATM transaction
    //    [HttpPut("/withdrawals/prestage/{id}/status")]
    //    public void UpdatePrestageStatus(int id, [FromBody] string value)
    //    {
    //    }

    //    // DELETE api/<PrestageController>/5
    //    [HttpDelete("{id}")]
    //    public void Delete(int id)
    //    {
    //    }
    //}
}
