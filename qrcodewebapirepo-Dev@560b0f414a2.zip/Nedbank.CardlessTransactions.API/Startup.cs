using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Logging;
using Nedbank.CardlessTransactions.API.ApplicationCore.Authentication;
using Nedbank.CardlessTransactions.API.ApplicationCore.Authorization;
using Nedbank.CardlessTransactions.API.ApplicationCore.Caching;
using Nedbank.CardlessTransactions.API.Common.Helper;
using Nedbank.CardlessTransactions.API.Common.Helper.Interfaces;
using Nedbank.CardlessTransactions.API.Configurations;
using Nedbank.CardlessTransactions.API.DataLayer;
using Nedbank.CardlessTransactions.API.DataLayer.EntityFrameworkCore.UnitOfWork;
using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using Nedbank.CardlessTransactions.API.Domain.Authentication;
using Nedbank.CardlessTransactions.API.Domain.Configuration;
using Nedbank.CardlessTransactions.API.Domain.FinancialAccounts;
using Nedbank.CardlessTransactions.API.Domain.Manager;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.API.Domain.MappingProfile;
using Nedbank.CardlessTransactions.Application.Filters;
using Nedbank.EAPI.SDK.Builder;
using Nedbank.EAPI.SDK.DependencyInjection;
using Nedbank.EAPI.Skynet.Resources.NedbankID;
using Nedbank.EAPI.Skynet.Resources.Profile;

namespace Nedbank.CardlessTransactions.API
{
    public class Startup
    {
        #region Members
        public IConfiguration Configuration { get; }
        #endregion

        #region Ctor
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            MemoryCacheManager.Configuration = configuration;
        }
        #endregion

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //  JWT authroization handling.
            services.AddAuthentication(NedbankAuthenticationDefaults.AuthenticationScheme)
                    .AddNedbankId();


            // Setup Authorization Policies
            services.AddAuthSetup(Configuration);

            //CoE framework configuration.
            ServiceConfiguration.ConfigureServices(services, Configuration);
            services
                .AddMvc();
            services.AddSingleton<IConfiguration>(Configuration);
            //Configuring QR Code setting
            services.Configure<QRCodeConfigurationSetting>(Configuration.GetSection("QRCodeConfigurationSetting"));
            // Configuring BackOffice Notification config
            services.Configure<BackOfficeNotificationConfiguration>(Configuration.GetSection("BackOfficeNotificationConfiguration"));
            // HttpContextAccessor
            services.AddHttpContextAccessor();

            //things particular to this API...
            services.AddScoped<IAuthenticationLogic, AuthenticationLogicLocal>();
            services.AddScoped<IAuthenticationLogic, AuthenticationLogic>();
            services.AddScoped<IFinancialAccountsLogic, FinancialAccountsLogic>();

            services.AddScoped<INedbankIdResource, NedbankIdResourceRestV3>();
            services.AddScoped<IProfileResource, ProfileResourceSoapV19>();

            #region Apart from CoE configurations

            //services.AddControllers(config =>
            //{
            //    config.Filters.Add(new ResponseWrapperFilter());
            //});

            services.AddScoped<IPrestagesManager, PrestagesManager>();
            services.AddScoped<IQRCodesManager, QRCodesManager>();
            services.AddScoped<INotificationsManager, NotificationsManager>();
            services.AddScoped(typeof(IEfRepository<>), typeof(EfRepository<>));
            services.AddScoped<ICommonHelper, CommonHelper>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();

            services.AddSingleton<IEnumHelper, EnumHelper>();
            services.AddAutoMapper(typeof(Startup));

            // ASP.NET Authorization Polices Handler
            services.AddSingleton<IAuthorizationHandler, ClaimsRequirementHandler>();

            services.AddDbContext<CardlessTransactionsContext>(options =>
            options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"), sqlServerOptions => sqlServerOptions.CommandTimeout(300)));

            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });

            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            services.AddMemoryCache();
            services.Add(new ServiceDescriptor(typeof(IMemoryCacheManager), typeof(MemoryCacheManager), ServiceLifetime.Singleton));



            #endregion
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {

            loggerFactory.AddFile("Logs/CardlessTransactions-{Date}.txt");

            PipelineConfiguration.Configure(app, env, Configuration);

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            if (env.IsDevelopment())
            {
                IdentityModelEventSource.ShowPII = true;
            }

            app.UseHttpsRedirection();


            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();


            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
