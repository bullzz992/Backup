﻿using Microsoft.Extensions.DependencyInjection;
using System;
using Microsoft.Extensions.Configuration;
using Nedbank.CardlessTransactions.API.ApplicationCore.Authorization;
using Nedbank.CardlessTransactions.API.Common.Constants;

namespace Nedbank.CardlessTransactions.API.Configurations
{
    public static class AuthorizationSetup
    {
        public static void AddAuthSetup(this IServiceCollection services, IConfiguration configuration)
        {
            if (services == null) throw new ArgumentNullException(nameof(services));

            services.AddAuthorization(options =>
            {
                options.AddPolicy("EWOCAdminAccess", policy => policy.Requirements.Add(new ClaimRequirement(GlobalConstants.UserAccessClaimName, GlobalConstants.UserAccessClaimValue_EWOCBOCAdministrator)));
                options.AddPolicy("EWOCStaffAccess", policy => policy.Requirements.Add(new ClaimRequirement(GlobalConstants.UserAccessClaimName, GlobalConstants.UserAccessClaimValue_Staff)));

                //        options.AddPolicy("EWOCAccess", policy =>
                //policy.RequireAssertion(context =>
                //    context.User.HasClaim(c =>
                //        (c.Type == "scopes" &&
                //                 (c.Value.Contains("EWOCBOCAdministrator") || c.Value.Contains("Staff"))))));
            });
        }

    }
}
