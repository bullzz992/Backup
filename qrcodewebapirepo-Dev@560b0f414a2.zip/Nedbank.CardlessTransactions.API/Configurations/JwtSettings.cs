﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Configurations
{
    public class JwtSettings
    {
        public bool IsEnabled { get; set; }
        public string SecurityKey { get; set; }
        public string Audience { get; set; }
        //public int Expiration { get; set; }
        public string Issuer { get; set; }
        //public string ValidAt { get; set; }
        public bool ShowPII { get; set; }
    }
}
