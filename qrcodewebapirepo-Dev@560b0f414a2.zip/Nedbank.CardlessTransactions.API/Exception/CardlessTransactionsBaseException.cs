﻿namespace Nedbank.CardlessTransactions.Api.Exception
{

    [System.Serializable]
    public class CardlessTransactionsBaseException : System.Exception
    {
        public CardlessTransactionsBaseException()
        { }

        public CardlessTransactionsBaseException(string message)
            : base(message)
        { }

        public CardlessTransactionsBaseException(string message, System.Exception innerException)
            : base(message, innerException)
        { }
    }
}
