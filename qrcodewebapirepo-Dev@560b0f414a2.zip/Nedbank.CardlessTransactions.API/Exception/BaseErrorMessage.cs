﻿namespace Nedbank.CardlessTransactions.Api.Exception
{
    public class BaseErrorMessage
    {

        public int StatusCode { get; set; }

        public string Message { get; set; }
    }
}
