﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Nedbank.CardlessTransactions.API.ApplicationCore.Exceptions;
using Nedbank.CardlessTransactions.API.Exception;
using Nedbank.CardlessTransactions.Application.Models;
using Newtonsoft.Json;
using System;
using System.Net;

namespace Nedbank.CardlessTransactions.Api.Exception
{
    public class CardlessTransactionsExceptionFilter : IExceptionFilter
    {
        public ILogger<CardlessTransactionsExceptionFilter> Logger { get; set; }


        public CardlessTransactionsExceptionFilter()
        {
            Logger = NullLogger<CardlessTransactionsExceptionFilter>.Instance;
        }

        public void OnException(ExceptionContext context)
        {
            HttpStatusCode status = (context.Exception as WebException != null &&
                        ((HttpWebResponse)(context.Exception as WebException).Response) != null) ?
                         ((HttpWebResponse)(context.Exception as WebException).Response).StatusCode
                         : ExceptionHelper.GetErrorCode(context.Exception.GetType());

            String message = String.Empty;

            var exceptionType = context.Exception.GetType();
            if (exceptionType == typeof(UnauthorizedAccessException))
            {
                message = "Unauthorized Access";
                status = HttpStatusCode.Unauthorized;
            }
            else if (exceptionType == typeof(NotImplementedException))
            {
                message = "A server error occurred.";
                status = HttpStatusCode.NotImplemented;
            }          
            else if (exceptionType == typeof(InvalidRequestException))
            {
                message = context.Exception.Message.ToString();
                status = HttpStatusCode.BadRequest;
            }
            else
            {
                message = context.Exception.Message;
                status = HttpStatusCode.InternalServerError;
            }

            HandleAndWrapException(context, status, message);
        }

        /// <summary>
        /// Handle and wrap exception 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="status"></param>
        /// <param name="message"></param>
        private void HandleAndWrapException(ExceptionContext context, HttpStatusCode status, string message)
        {

            context.HttpContext.Response.Clear();
            context.HttpContext.Response.StatusCode = (int)status;
            context.HttpContext.Response.ContentType = "application/json";

            APIResponse<string> errorResponse = new APIResponse<string>();
            errorResponse.CreateErrorResponse(message, status, ErrorCodeEnum.InternalError);
            string responseResult = JsonConvert.SerializeObject(errorResponse);
            context.HttpContext.Response.ContentLength = responseResult.Length;
            context.HttpContext.Response.WriteAsync(responseResult);

            #region Old Code for reference
            //var logLevel = context.Exception.GetLogLevel();
            //Logger.LogWithLevel(logLevel, $"---------- {nameof(APIResponse<string>)} ----------");
            //Logger.LogWithLevel(logLevel, _jsonSerializer.Serialize(errorResponse, indented: true));
            //Logger.LogException(context.Exception, logLevel);

            context.Exception = null;
            context.ExceptionHandled = true;
            #endregion
        }
    }
}
