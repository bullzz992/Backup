﻿using Nedbank.CardlessTransactions.CommandHub.Test.MockData;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.CommandHub.Test.Base
{
    public class BaseNotificationFixture
    {
        public TestData TestData { get; set; }
        public BaseNotificationFixture()
        {
            TestData = new TestData();
        }
    }
}
