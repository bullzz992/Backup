﻿//using Microsoft.AspNetCore.SignalR;
//using Moq;
//using Nedbank.CardlessTransactions.CommandHub.API.Domain.Model;
//using Nedbank.CardlessTransactions.CommandHub.API.Domain.Model.Interface;
//using Nedbank.CardlessTransactions.CommandHub.API.Domain.NotificationHub;
//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.Threading.Tasks;
//using Xunit;

//namespace Nedbank.CardlessTransactions.CommandHub.Test.TestCases.UnitTestCases.Notification
//{
//    public class ATMNotificationTest
//    {
//        Mock<IConnectionManager> _mockConnManager;
//        public IConnectionManager _connManager;
//        private Mock<IHubContext<ATMNotificationHub>> ock = new Mock<IHubContext<ATMNotificationHub>>();
//        public ATMNotificationTest()
//        {
//            _mockConnManager = new Mock<IConnectionManager>();
//            _connManager = new ConnectionManager(ock.Object);
//        }
//        [Fact]
//        public async Task Add()
//        {
//            ATMNotificationHub aTMNotificationHub = new ATMNotificationHub(_connManager);
//            _mockConnManager.Setup(a => a.AddConnection("ter1", "trans1", "conn")).Returns(Task.FromResult(_mockConnManager.Object));
//            await aTMNotificationHub.RegisterConnectionId("ter1", "trans1");
            
//        }
//    }
//}
