﻿using Microsoft.Extensions.Logging;
using Moq;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;
using Nedbank.CardlessTransactions.CommandHub.Test.TestFixtures;
using Shouldly;
using System.Threading.Tasks;
using Xunit;

namespace Nedbank.CardlessTransactions.CommandHub.Test.TestCases.UnitTestCases.Notification
{
    public class NotificationManagerTest : IClassFixture<NotificationManagerFixture>
    {
        #region Member
        private readonly NotificationManagerFixture _fixture;
        private IHubNotificationManager _manager;
        private IConnectionManager _connectionManager;
        private readonly ILogger<HubNotificationManager> _logger;

        #endregion
        public NotificationManagerTest(NotificationManagerFixture fixture)
        {
            _fixture = fixture;
            _connectionManager = _fixture._connectionManager.Object;
            _logger = Mock.Of<ILogger<HubNotificationManager>>();
            _manager = new HubNotificationManager(_connectionManager, _logger);
        }
        #region Positive Test Case
        [Theory]
        [InlineData("ter1", "tran1")]
        public async Task SendNotication_Should_Return_Success(string terminalId, string transactionId)
        {
            var sendNotificationData = _fixture.TestData.GetNotificationDtoData(terminalId, transactionId);
            _fixture._connectionManager.Setup(a => a.GetConnections(terminalId, transactionId))
                                       .Returns(_fixture.TestData.GetConnectionId());
            _fixture._connectionManager.Setup(_ => _.SendDispenseCashhNotification(_fixture.TestData.GetConnectionId(), sendNotificationData))
                                        .Returns(Task.FromResult(true));
            var response = await _manager.SendNotication(sendNotificationData);
            response.IsSuccess.ShouldBeTrue();
        }
        #endregion
        #region Negative Test Cases
        [Theory]
        [InlineData("ter1", "tran1")]
        public async Task SendNotication_Should_Return_False(string terminalId, string transactionId)
        {
            var sendNotificationData = _fixture.TestData.GetNotificationDtoData(terminalId, transactionId);
            _fixture._connectionManager.Setup(a => a.GetConnections(terminalId, transactionId))
                                       .Returns(_fixture.TestData.GetEmptyConnectionId());
            //_fixture._connectionManager.Setup(_ => _.SendDispenseCashhNotification(_fixture.TestData.GetConnectionId(), sendNotificationData))
                                        //.Returns(Task.FromResult(true));
            var response = await _manager.SendNotication(sendNotificationData);
            response.IsSuccess.ShouldBeFalse();
        }
        #endregion region
        //Start Here
        //
        //
        //mockClients.Setup(clients => clients.All).Returns(mockClientProxy.Object);

        //ATMNotificationHub hub = new ATMNotificationHub(_connectionManager.Object, _manager.Object)
        //{
        //    Clients = mockClients.Object
        //};

        //// act
        //await hub.RegisterConnectionId(terminalId, transactionId);


        //// assert
        //mockClients.Verify(clients => clients.All, Times.Once);

        //mockClientProxy.Verify(
        //    clientProxy => clientProxy.SendCoreAsync(
        //        "welcome",
        //        It.Is<object[]>(o => o != null && o.Length == 1 && ((object[])o[0]).Length == 3),
        //        default(CancellationToken)),
        //    Times.Once);
        // End here

    }
}
