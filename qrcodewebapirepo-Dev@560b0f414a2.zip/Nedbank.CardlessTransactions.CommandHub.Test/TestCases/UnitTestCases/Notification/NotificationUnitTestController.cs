﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using Moq;
using Nedbank.CardlessTransactions.CommandHub.API.Application.Controllers;
using Nedbank.CardlessTransactions.CommandHub.API.Application.Controllers.Interfaces;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications;
using Nedbank.CardlessTransactions.CommandHub.Test.TestFixtures;
using Shouldly;
using System.Threading.Tasks;
using Xunit;

namespace Nedbank.CardlessTransactions.CommandHub.Test.TestCases.UnitTestCases.Notification
{
    public class NotificationUnitTestController : IClassFixture<NotificationFixture>
    {
        #region Member
        private readonly NotificationFixture _fixture;

        INotificationsController _controller;
        Mock<IHubNotificationManager> _manager;
        private readonly ILogger<NotificationsController> _logger;
        //Mock<IConnectionManager> _connectionManager;
        #endregion

        public NotificationUnitTestController(NotificationFixture fixture)
        {
            _fixture = fixture;
            _manager = _fixture._hubNotificationManager;
            _logger = Mock.Of<ILogger<NotificationsController>>();
            _controller = new NotificationsController(_manager.Object, _logger);
            
        }
        [Theory]
        [InlineData("ter1", "tran1")]
        public async Task PostAsync_SendNotification_Should_Return_Success(string terminalId, string transactionId)
        {
            var sendNotificationData = _fixture.TestData.GetNotificationDtoData(terminalId,transactionId); 
            _manager.Setup(a => a.SendNotication(It.IsAny<SendNotificationDto>()))
                                 .ReturnsAsync(_fixture.TestData.SendNotificationSuccess());
            var response = await _controller.PostAsyncSendNotification(sendNotificationData);
            response.Data.IsSuccess.ShouldBeTrue();
        }

        [Theory]
        [InlineData("ter1", "tran1")]
        public async Task PostAsync_SendNotification_Should_Return_Fail(string terminalId, string transactionId)
        {
            SendNotificationDto sendNotificationDto = new SendNotificationDto
            {
                Amount = 100,
                TerminalId = terminalId,
                TransactionId = transactionId,
                CardNumber = "CC",
                CardExpiryDate = "1010",
                IsValid = false,
                PrestageId = 1
            };
            _manager.Setup(a => a.SendNotication(It.IsAny<SendNotificationDto>()))
                     .ReturnsAsync(_fixture.TestData.SendNotificationFail());
            var response = await _controller.PostAsyncSendNotification(sendNotificationDto);
            response.Data.IsSuccess.ShouldBeFalse();
        }


    }
}
