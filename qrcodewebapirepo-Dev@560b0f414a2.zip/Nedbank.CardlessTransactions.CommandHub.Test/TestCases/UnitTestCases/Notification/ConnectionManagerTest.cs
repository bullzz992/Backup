﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using Moq;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;
using Nedbank.CardlessTransactions.CommandHub.Test.TestFixtures;
using System.Threading.Tasks;
using Xunit;

namespace Nedbank.CardlessTransactions.CommandHub.Test.TestCases.UnitTestCases.Notification
{
    public class ConnectionManagerTest : IClassFixture<ConnectionManagerFixture>
    {

        private readonly Mock<IHubCallerClients> _mockClients;
        private readonly Mock<IClientProxy> _mockClientProxy;
        private readonly Mock<IHubClients> _mockClient;
        private readonly Mock<HubCallerContext> _mockContext;
        private readonly Mock<IHubClients> _client;

        private readonly ConnectionManagerFixture _fixture;
        public IConnectionManager _connManager;
        private readonly ILogger<ConnectionManager> _logger;

        public ConnectionManagerTest(ConnectionManagerFixture fixture)
        {
            this._fixture = fixture;
            _mockClients = new Mock<IHubCallerClients>();
            _mockClientProxy = new Mock<IClientProxy>();
            _mockClient = new Mock<IHubClients>();
            _mockContext = new Mock<HubCallerContext>();
            _logger = Mock.Of<ILogger<ConnectionManager>>();
            _connManager = new ConnectionManager(_fixture._hubContext.Object, _logger);
            _client = new Mock<IHubClients>();

        }

        #region Positive Test cases
        [Theory]
        [InlineData("ter1", "trans1", "conn1")]
        public async Task AddConnection_Should_Add_Connection_Success(string terminalId, string transactionId, string connectionId)
        {
            _fixture._hubContext.Setup(x => x.Clients).Returns(_client.Object);
            _fixture._hubContext.Setup(x => x.Clients.Client(connectionId)).Returns(_mockClientProxy.Object);
            _client.Setup(a => a.Client(connectionId)).Returns(_mockClientProxy.Object);
            await _connManager.AddConnection(terminalId, transactionId, connectionId);
            _fixture._hubContext.Verify(a => a.Clients.Client(connectionId), Times.AtLeastOnce);
        }

        #endregion

        #region Negative Test Cases
        [Theory]
        [InlineData("ter1", "trans1", "conn1")]
        public async Task AddConnection_Should_Return_Fail(string terminalId, string transactionId, string connectionId)
        {
            _mockClient.Setup(client => client.Client("conn1"))
                                    .Returns(_mockClientProxy.Object);
            _fixture._hubContext.Setup(x => x.Clients.Client("conn1")).Returns(_mockClientProxy.Object);
            _mockContext.Setup(a => a.ConnectionId).Returns("conn1");
            await _connManager.AddConnection(terminalId, transactionId, connectionId);
            _mockClient.Verify(clients => clients.Client("conn1"), Times.Never);
        }
        #endregion
        
        //[Theory]
        //[InlineData("ter1", "trans1", "conn1")]
        //public async Task SignalR_OnConnect(string terminalId, string transactionId, string connectionId)
        //{
        //    // arrange
        //    //Mock<IHubCallerClients> mockClients = new Mock<IHubCallerClients>();
        //    //Mock<IClientProxy> mockClientProxy = new Mock<IClientProxy>();
        //    //mockClients.Setup(clients => clients.Client("conn1")).Returns(mockClientProxy.Object);
        //    //ATMNotificationHub simpleHub = new ATMNotificationHub(_connManager)
        //    //{
        //    //    Clients = mockClients.Object
        //    //};
        //    // act
        //    //Mock<IHubClients> mock = new Mock<IHubClients>();

        //    //_fixture._hubContext.Setup(x => x.Clients).Returns(mock.Object);
        //    _fixture._hubContext.Setup(x => x.Clients).Returns(_client.Object);
        //    _fixture._hubContext.Setup(x => x.Clients.Client(connectionId)).Returns(_mockClientProxy.Object);
        //    //mock.Setup(a => a.Client("conn1")).Returns(mockClientProxy.Object);
        //    _client.Setup(a => a.Client(connectionId)).Returns(_mockClientProxy.Object);

        //    await _connManager.AddConnection(terminalId, transactionId, connectionId);
        //    _fixture._hubContext.Verify(a => a.Clients.Client(connectionId), Times.AtLeastOnce);

        //    //mockClients.Verify(clients => clients.Client("conn1"), Times.Once);

        //    //mockClientProxy.Verify(
        //    //    clientProxy => clientProxy.SendAsync(
        //    //        "ReceiveMessage", "ter1", "trans1", "conn1",
        //    //        //It.Is<object[]>(o => o != null && o.Length == 1 && ((object[])o[0]).Length == 3),
        //    //        default),
        //    //    Times.Once);
        //}
    }
}
