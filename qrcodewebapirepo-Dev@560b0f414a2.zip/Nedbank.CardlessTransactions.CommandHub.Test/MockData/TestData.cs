﻿using Nedbank.CardlessTransactions.CommandHub.API.Domain.Dto.Notifications;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.CommandHub.Test.MockData
{
    public class TestData
    {
        public SendNotificationResponse SendNotificationSuccess()
        {
            return new SendNotificationResponse()
            {
                IsSuccess = true
            };
        }
        public SendNotificationResponse SendNotificationFail()
        {
            return new SendNotificationResponse()
            {
                IsSuccess = false
            };
        }

        public SendNotificationDto GetNotificationDtoData(string terminalId, string transactionId)
        {
            return new SendNotificationDto
            {
                Amount = 100,
                TerminalId = terminalId,
                TransactionId = transactionId,
                CardNumber = "CC",
                CardExpiryDate = "1010",
                IsValid = true,
                PrestageId = 1
            };
        }

        public string GetConnectionId()
        {
            return "conn123";
        }
        public string GetEmptyConnectionId()
        {
            return "";
        }
    }
}
