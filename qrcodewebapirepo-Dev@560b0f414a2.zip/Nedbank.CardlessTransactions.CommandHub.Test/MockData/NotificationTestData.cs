﻿using Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.CommandHub.Test.MockData
{
    public class NotificationTestData : IEnumerable<object[]>
    {
        public IEnumerator<object[]> GetEnumerator()
        {
            yield return new object[]
                {
                    new SendNotificationDto()
                    {
                        Amount=100,

                    }

                };
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
