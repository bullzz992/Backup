﻿using Moq;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;
using Nedbank.CardlessTransactions.CommandHub.Test.Base;

namespace Nedbank.CardlessTransactions.CommandHub.Test.TestFixtures
{
    public class NotificationManagerFixture : BaseNotificationFixture
    {
        public Mock<IHubNotificationManager> NotificationManager { get; }
        public Mock<IConnectionManager> _connectionManager { get; }
        public NotificationManagerFixture()
        {
            this.NotificationManager = new Mock<IHubNotificationManager>();
            this._connectionManager = new Mock<IConnectionManager>();
        }
    }
}
