﻿using Nedbank.CardlessTransactions.CommandHub.Test.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.CommandHub.Test.TestFixtures
{
    public class NotificationControllerFixture : BaseNotificationFixture
    {
    }
}
