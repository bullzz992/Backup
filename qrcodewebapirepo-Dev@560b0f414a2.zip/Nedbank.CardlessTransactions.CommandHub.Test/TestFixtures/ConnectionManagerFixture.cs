﻿using Microsoft.AspNetCore.SignalR;
using Moq;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.NotificationHub;
using Nedbank.CardlessTransactions.CommandHub.Test.Base;

namespace Nedbank.CardlessTransactions.CommandHub.Test.TestFixtures
{
    public class ConnectionManagerFixture : BaseNotificationFixture
    {
        public Mock<IHubContext<ATMNotificationHub>> _hubContext;
        public ConnectionManagerFixture()
        {
            _hubContext = new Mock<IHubContext<ATMNotificationHub>>();
        }
    }
}
