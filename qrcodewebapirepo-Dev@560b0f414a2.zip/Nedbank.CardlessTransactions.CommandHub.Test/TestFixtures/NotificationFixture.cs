﻿using Moq;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;
using Nedbank.CardlessTransactions.CommandHub.Test.Base;

namespace Nedbank.CardlessTransactions.CommandHub.Test.TestFixtures
{
    public class NotificationFixture: BaseNotificationFixture
    {
        public Mock<IHubNotificationManager> _hubNotificationManager { get; }

        public NotificationFixture()
        {
            _hubNotificationManager =new Mock<IHubNotificationManager>();
        }
    }
}
