﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.Tests.MockData
{
    public class GetQRCodeNegativeTestData : IEnumerable<object[]>
    {
        public IEnumerator<object[]> GetEnumerator()
        {
            yield return new object[] { string.Empty, string.Empty };
            yield return new object[] { string.Empty, "trans1" };
            yield return new object[] { "term1", string.Empty };

        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
