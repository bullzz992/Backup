﻿using Nedbank.CardlessTransactions.API.Common.Functional.Enum;
using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using Nedbank.CardlessTransactions.API.Domain.Configuration;
using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.Tests.MockData
{
    public class TestData
    {
        #region PreStage 

        public virtual List<Prestage> GetPrestageData()
        {
            var PrestageData =
                new List<Prestage>()
                        {
                            new Prestage
                            {
                            Id = 1,//Guid.NewGuid().ToString(),
                            CardNumber="act123",
                            CardExpiryDate=2510,
                            AccountType = "saving",
                            Amount = 1000,
                            ProfileNumber="pn1",
                            ValidUpto=DateTime.Now,
                            PrestageStatus=Statuses.Prestaged.ToString()
                            },
                            new Prestage
                            {
                            Id = 2,
                            CardNumber="act123",
                            CardExpiryDate=2510,
                            AccountType = "saving",
                            Amount = 2000,
                            ProfileNumber="pn2",
                            ValidUpto=DateTime.Now,
                            PrestageStatus=Statuses.Completed.ToString()
                            },
                            new Prestage
                            {
                            Id = 3,
                            CardNumber="act123",
                            CardExpiryDate=2510,
                            AccountType = "saving",
                            Amount = 3000,
                            ProfileNumber="pn3",
                            ValidUpto=DateTime.Now,
                            PrestageStatus=Statuses.Completed.ToString()
                            }
                        };
            return PrestageData;
        }

        public virtual Prestage GetPresatgeCreated()
        {
            return new Prestage()
            {
                Id = 1,
                CardNumber = "act123",
                CardExpiryDate = 2510,
                AccountType = "saving",
                Amount = 1000,
                ProfileNumber = "pn1",
                ValidUpto = DateTime.Now,
                PrestageStatus = Statuses.Prestaged.ToString(),
                CreatedToken = "tk1"
            };
        }

        public virtual Prestage GetPresatgeUpdated()
        {
            return new Prestage()
            {
                Id = 1,
                CardNumber = "act123",
                CardExpiryDate = 2510,
                AccountType = "saving",
                Amount = 3000,
                ProfileNumber = "pn1",
                ValidUpto = DateTime.Now,
                PrestageStatus = Statuses.Prestaged.ToString(),
                LastModifiedToken = "tk1"
            };
        }

        public virtual Prestage GetPresatgeUpdated_Blank()
        {
            return null;
        }

        public virtual Prestage GetPresatgeDeleted()
        {
            return new Prestage()
            {
                Id = 1,
                CardNumber = "act123",
                CardExpiryDate = 2510,
                AccountType = "saving",
                Amount = 1000,
                ProfileNumber = "pn1",
                ValidUpto = DateTime.Now,
                PrestageStatus = Statuses.Deleted.ToString(),
                LastModifiedToken = "tk1"
            };
        }

        public virtual Prestage GetPrestagedStatus()
        {
            return new Prestage()
            {
                Id = 1,
                CardNumber = "act123",
                CardExpiryDate = 2510,
                AccountType = "saving",
                Amount = 1000,
                ProfileNumber = "pn1",
                ValidUpto = DateTime.Now,
                PrestageStatus = Statuses.Prestaged.ToString(),
                LastModifiedToken = "tk1"
            };
        }

        public virtual Prestage Getstatus_null()
        {
            return null;
        }

        public virtual Prestage GetPrestageNull()
        {
            return null;
        }
        public virtual BackOfficeNotificationConfiguration BackOfficeNotificationSetting()
        {
            return new BackOfficeNotificationConfiguration()
            {
                clientId="client1",
                clientSecretKey="clientSecret"
            };
        }

        #endregion

        #region QRCode
        public virtual QRCode GetQRCodeCreated()
        {
            return new QRCode()
            {
                Id = 1,
                TerminalId = "ter1",
                TransactionId = "tran1",
                SessionId = "sess1",
                QrCode = $"ter1:tran1:sess1",
                DateCreated = DateTime.Now,
                ValidUpto = DateTime.Now.AddSeconds(45),
                Token = "Token1"

            };
        }

        public virtual List<QRCode> GetQRCodeList()
        {
            try
            {
                var qrCodeData = new List<QRCode>()
                {
                    new QRCode
                    {
                         Id = 1,
                TerminalId = "ter1",
                TransactionId = "tran1",
                SessionId="sess1",
                QrCode = $"ter1:tran1:sess1",
                DateCreated =  DateTime.Now,
                ValidUpto =  DateTime.Now.AddSeconds(45),
                Token = "Token1"

                    },
                new QRCode
                {
                Id = 5,
                QrCode = "123:56777:",
                TerminalId = "123",
                SessionId="ses1",
                TransactionId = "56777",
               DateCreated =  DateTime.Now,
                ValidUpto =  DateTime.Now.AddSeconds(45),
                },
                new QRCode
                {
                    Id = 4,
                QrCode = "1:123:",
                TerminalId = "1",
                TransactionId = "123",
                SessionId="sess234",
               DateCreated =  DateTime.Now,
                ValidUpto =  DateTime.Now.AddSeconds(45),
                },
                new QRCode
                {
                    Id =11,
                QrCode = "11:123:sess234",
                TerminalId = "11",
                TransactionId = "123",
                SessionId="sess234",
                DateCreated =  DateTime.Now.AddDays(1),
                ValidUpto =  DateTime.Now.Subtract(new TimeSpan(1,0,0)),
                },
                };
                return qrCodeData;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public virtual List<Prestage> GetPreStageDataList()
        {
            var response = new List<Prestage>
            {
                new Prestage()
                    {
                     Id = 1,
                   CardNumber="act123",
                   CardExpiryDate=2510,
                  AccountType = "Saving",
                  Amount = 1000,
                  ProfileNumber = "Pn1",
                  DateCreated = DateTime.Now,
                  ValidUpto = DateTime.Now.AddHours(8),
                  PrestageStatus = Statuses.Prestaged.ToString(),
                  QRCodeId = 1,
                  StatusMessage = "Sm1",
                  CreatedToken = "Token1"
                    },
                new Prestage()
                {
                     Id = 3,
                   CardNumber="act123",
                   CardExpiryDate=2510,
                  AccountType = "Current",
                  Amount = 2000,
                  ProfileNumber = "Pn123",
                  DateCreated = DateTime.Now,
                  ValidUpto = DateTime.Now.AddHours(8),
                  PrestageStatus = Statuses.Prestaged.ToString(),
                  QRCodeId = 5,
                  StatusMessage = "Sm1",
                  CreatedToken = "Token123"
                },
                new Prestage()
                {
                     Id = 11,
                   CardNumber="act123",
                   CardExpiryDate=2510,
                  AccountType = "Saving",
                  Amount = 1000,
                  ProfileNumber = "P1",
                  DateCreated = DateTime.Now,
                  ValidUpto = DateTime.Now.AddHours(8),
                  PrestageStatus = Statuses.Prestaged.ToString(),
                  QRCodeId = 5,
                  StatusMessage = "Sm1",
                  CreatedToken = "Token123"
                },
            };
            return response;
        }

        public virtual QRCode GetQRCodeDataByTranId()
        {
            return new QRCode()
            {
                Id = 1,
                TerminalId = "ter1",
                TransactionId = "tran1",
                DateCreated = DateTime.Now,
                QrCode = "qrcode1",
                SessionId = "session1",
                Token = "tk1",
                ValidUpto = DateTime.Now.AddSeconds(50)
            };
        }

        public virtual QRCode GetQRCodeDataByTranId_null()
        {
            return null;
        }

        internal bool SendNotification()
        {
            return true;
        }

        public virtual QRCodeConfigurationSetting QrCodeConfigSetting()
        {
            return new QRCodeConfigurationSetting()
            {
                NotificationHubBaseUrl = "test.com",
                QRCodeExpiry = 45,
                QRCodeGraphic = 20
            };
        }
        #endregion
    }
}
