﻿using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.Tests.MockData
{
    public class PrestageNegativeFlowTestData : IEnumerable<object[]>
    {
        public IEnumerator<object[]> GetEnumerator()
        {
            yield return new object[]
                {
                    new CreatePrestageRequestDto()
                    {
                       AccountType="saving",
                       CardNumber="act123",
                       CardExpiryDate=2510,
                       Amount=50,
                    } };
            yield return new object[]
                {
                     new CreatePrestageRequestDto()
                    {
                       AccountType = "",
                       CardNumber = "act123",
                       CardExpiryDate=2510,
                       Amount = 500,
                    } };
            yield return new object[]
                {
                     new CreatePrestageRequestDto()
                    {
                       AccountType = "saving",
                       CardNumber = "",
                       CardExpiryDate=2510,
                       Amount = 500,
                    } };
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

    public class PrestageUpdateNegativeFlowTestData : IEnumerable<object[]>
    {
        public IEnumerator<object[]> GetEnumerator()
        {
            yield return new object[]
                {
                    0,
                    new UpdatePrestageRequestDto()
                    {
                       AccountType="saving",
                       CardNumber="act123",
                       CardExpiryDate=2210,
                       Amount=50,
                    }
                };
            yield return new object[]
               {
                   2,
                     new UpdatePrestageRequestDto()
                    {
                       AccountType="",
                       CardNumber="act123",
                       CardExpiryDate=2210,
                       Amount=500,
                    }
               };
            yield return new object[]
               {
                   -1,
                      new UpdatePrestageRequestDto()
                    {
                       AccountType="saving",
                       CardNumber="act123",
                       CardExpiryDate=2210,
                       Amount=500,
                    }
               };
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
