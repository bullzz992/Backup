﻿using Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.Tests.MockData
{
    public class ValidateQRCodeNegativeFlowTestData : IEnumerable<object[]>
    {
        public IEnumerator<object[]> GetEnumerator()
        {
            yield return new object[]
                {
                    //new PostQRCodeRequest()
                    //{
                    //    PrestageId=1,
                    //    QrCode=null
                    //},
                    new PostQRCodeRequest()
                    {
                        PrestageId=1,
                        QrCode="ter1"
                    }
                };
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
    public class ValidatePostQRCodeNegativeFlowTestData : IEnumerable<object[]>
    {
        public IEnumerator<object[]> GetEnumerator()
        {
            yield return new object[]
                {
                    new PostQRCodesResponse()
                    {
                        Isvalid=false,
                        TerminalId="ter1",
                        TransactionId="trans1"
                    },
                    new PostQRCodesResponse()
                    {
                        Isvalid=false,
                        TerminalId="",
                        TransactionId=""
                    }
        };
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

}
