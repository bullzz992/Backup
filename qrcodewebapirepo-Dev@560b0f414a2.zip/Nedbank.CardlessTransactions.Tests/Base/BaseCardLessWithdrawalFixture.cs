﻿using AutoMapper;
using Nedbank.CardlessTransactions.API.DataLayer;
using Nedbank.CardlessTransactions.API.Domain.MappingProfile;
using Nedbank.CardlessTransactions.Tests.MockData;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.Tests.Base
{
    public class BaseCardLessWithdrawalFixture
    {
        public IMapper AutoMapper { get; set; }
        public TestData TestData { get; set; }
        public CardlessTransactionsContext Context { get; set; }
        public BaseCardLessWithdrawalFixture()
        {
            this.AutoMapper = new MapperConfiguration(c =>
                                      c.AddProfile<MappingProfile>()).CreateMapper();
            this.TestData = new TestData();
           // this.Context = new Nedbank.CardlessTransactions.Tests.ConnectionFactory.ConnectionFactory().CreateContext();
        }
    }
}
