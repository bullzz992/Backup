﻿using Nedbank.CardlessTransactions.API.Common.Functional.Enum;
using Nedbank.CardlessTransactions.API.DataLayer;
using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;

namespace Nedbank.Bookings.Application.Tests
{
    public static class PrestageData
    {
        private static readonly object _lock = new object();
        private static bool _databaseInitialized;

        public static void SeedPrestages(this CardlessTransactionsContext context)
        {
            lock (_lock)
            {
                if (!_databaseInitialized)
                {
                    if (context != null)
                    {
                        var prestageList = new List<Prestage>()
                        {
                            new Prestage
                            {
                           // Id = 1,//Guid.NewGuid().ToString(),
                            CardNumber="act123",
                            CardExpiryDate=2510,
                            AccountType = "saving",
                            Amount = 1000,
                            ProfileNumber="pn1",
                             DateCreated=DateTime.Now,
                            ValidUpto=DateTime.Now.AddHours(8),                         
                            PrestageStatus=Statuses.Prestaged.ToString(),
                            CreatedToken="Tk1",
                            },
                             new Prestage
                            {
                            CardNumber="act123",
                            CardExpiryDate=2510,
                            AccountType = "saving",
                            Amount = 2000,
                            ProfileNumber="pn2",
                            DateCreated=DateTime.Now,
                            ValidUpto=DateTime.Now.AddHours(8),                          
                            PrestageStatus=Statuses.Completed.ToString(),
                            CreatedToken="Tk2",
                            }
                        };

                        context.Prestage.AddRange(prestageList);
                        context.SaveChanges();
                    }
                }

                _databaseInitialized = true;
            }
        }


    }
}
