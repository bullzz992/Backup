﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.Application.Tests
{
    public class TestHelper
    {

    }
}
