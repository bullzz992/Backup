﻿using Microsoft.Extensions.Logging;
using Moq;
using Nedbank.Bookings.Application.Tests;
using Nedbank.CardlessTransactions.API.Common.Helper;
using Nedbank.CardlessTransactions.API.Common.Helper.Interfaces;
using Nedbank.CardlessTransactions.API.DataLayer.EntityFrameworkCore.UnitOfWork;
using Nedbank.CardlessTransactions.API.Domain.Manager;
using Nedbank.CardlessTransactions.Tests.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.Tests.TestFixtures
{
    public class PrestagesManagerFixture : BaseCardLessWithdrawalFixture
    {
        public Mock<IUnitOfWork> _unitOfWork;
        public Mock<ILogger<PrestagesManager>> _persategeLogger;
        public Mock<ICommonHelper> _helper { get; }
        public Mock<IEnumHelper> _enumHelper { get; set; }
        public PrestagesManagerFixture()
        {
            this._unitOfWork = new Mock<IUnitOfWork>();
            this._unitOfWork.Setup(x => x.Context).Returns(base.Context);
            this._helper = new Mock<ICommonHelper>();
            this._enumHelper = new Mock<IEnumHelper>();
            this.Context.SeedPrestages();
            this._persategeLogger = new Mock<ILogger<PrestagesManager>>();

        }
    }
}
