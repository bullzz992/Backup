﻿using Microsoft.EntityFrameworkCore.Internal;
using Moq;
using Nedbank.CardlessTransactions.API.Common.Functional.Enum;
using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.Tests.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nedbank.CardlessTransactions.Tests.TestFixtures
{
    public class PrestagesControllerFixture : BaseCardLessWithdrawalFixture
    {
        public IEfRepository<API.DataLayer.Entities.Prestage> _repository { get; }
        public Mock<IPrestagesManager> PreStageManager { get; }

        List<PrestageResponseDto> lstprestageResponses = new List<PrestageResponseDto>();
       


        public PrestagesControllerFixture()
        {
            this._repository = new EfRepository<API.DataLayer.Entities.Prestage>(this.Context);
            this.PreStageManager = new Mock<IPrestagesManager>();
         
            lstprestageResponses.Add(new PrestageResponseDto { PrestageId = 1, FromAccount = "ac1", 
                AccountType = "saving", Amount = 1000, Status = Statuses.Prestaged.ToString(), validUpto = DateTime.Now.AddHours(-4) });
            lstprestageResponses.Add(new PrestageResponseDto
            {
                PrestageId = 2,
                FromAccount = "ac2",
                AccountType = "saving",
                Amount = 2000,
                Status = Statuses.Completed.ToString(),
                validUpto = DateTime.Now.AddHours(-10)
            });

        }

        //public PrestageResponseDto GetActiveTransaction()
        //{
        //    PrestageResponseDto prestageResponseDto = new PrestageResponseDto();
        //    prestageResponseDto.PrestageId = 1;
        //    prestageResponseDto.IsExistingUser = true;
        //    prestageResponseDto.FromAccount = "Ac1234";
        //    prestageResponseDto.AccountType = "Saving";
        //    prestageResponseDto.Amount = 1000;
        //    prestageResponseDto.Status = Statuses.Prestaged.ToString();
        //    prestageResponseDto.validUpto = DateTime.Now;

        //    return prestageResponseDto;
        //}

        public PrestageResponsesDto GetActiveTransaction()
        {
            PrestageResponsesDto prestageResponseDto = new PrestageResponsesDto();
            PrestageResponses res = new PrestageResponses();

            res.PrestageId = 1;
            res.CardNumber = "Ac1234";
            res.CardExpiryDate = 2510;
            res.AccountType = "Saving";
            res.Amount = 1000;
            res.Status = Statuses.Prestaged.ToString();
            res.validUpto = DateTime.Now;
            prestageResponseDto.PrestageResponses = new PrestageResponses[1] { res };
            prestageResponseDto.IsExistingUser = true;

            return prestageResponseDto;
        }

        //public PrestageResponseDto GetActiveTransaction_blank()
        //{          
        //    return new PrestageResponseDto();
        //}

        public PrestageResponsesDto GetActiveTransaction_blank()
        {
            return new PrestageResponsesDto();
        }

        public PrestageResponsesDto GetActiveTransaction_Existinguser()
        {
            PrestageResponsesDto dto = new PrestageResponsesDto();
            dto.IsExistingUser = true;
            return dto;
        }

        public PrestageStatusResponseDto GetStaus(long prestageId)
        {
            PrestageStatusResponseDto prestagestatusResponseDto = new PrestageStatusResponseDto();

            prestagestatusResponseDto.StatusCode = lstprestageResponses.FirstOrDefault(x => x.PrestageId == 1).Status;
            return prestagestatusResponseDto;
        }

        public PrestageStatusResponseDto GetStaus_Notfound(long prestageId)
        {
            PrestageStatusResponseDto prestagestatusResponseDto = new PrestageStatusResponseDto();        
            return prestagestatusResponseDto;
        }

        public CreatePrestageResponseDto CreatePrestageRequest()
        {
            CreatePrestageResponseDto prestagestatusResponseDto = new CreatePrestageResponseDto();
            prestagestatusResponseDto.PrestageId = 1;
            return prestagestatusResponseDto;
        }

        public CreatePrestageResponseDto CreatePrestageRequest_Returns0()
        {
            CreatePrestageResponseDto prestagestatusResponseDto = new CreatePrestageResponseDto();
            prestagestatusResponseDto.PrestageId = 0;
            return prestagestatusResponseDto;
        }

        public UpdatePrestageResponseDto UpdatePrestageRequest()
        {
            UpdatePrestageResponseDto updateResponseDto = new UpdatePrestageResponseDto();
            updateResponseDto.PrestageId = 1;
            return updateResponseDto;
        }

        public UpdatePrestageResponseDto UpdatePrestageRequest_Failed()
        {
            UpdatePrestageResponseDto updateResponseDto = new UpdatePrestageResponseDto();
            return updateResponseDto;
        }

        public UpdatePrestageResponseDto UpdatePrestageStatusRequest()
        {
            UpdatePrestageResponseDto updateResponseDto = new UpdatePrestageResponseDto();
            updateResponseDto.PrestageId = 1;
            return updateResponseDto;
        }

        public UpdatePrestageResponseDto UpdatePrestageStatusNotFound()
        {
            UpdatePrestageResponseDto updateResponseDto = new UpdatePrestageResponseDto();
            return updateResponseDto;
        }

        public UpdatePrestageResponseDto UpdateAsyncPrestageRequest()
        {
            UpdatePrestageResponseDto updateResponseDto = new UpdatePrestageResponseDto();
            return updateResponseDto;
        }

        public DeletePrestageResponse DeletePrestageRequest()
        {
            DeletePrestageResponse prestagestatusResponseDto = new DeletePrestageResponse();
            prestagestatusResponseDto.PrestageId = 1;
            return prestagestatusResponseDto;
        }

        public DeletePrestageResponse DeletePrestageRequest_Blank()
        {
            DeletePrestageResponse prestagestatusResponseDto = new DeletePrestageResponse();
            return prestagestatusResponseDto;
        }

        public PrestageStatusResponseDto GetPrestageRequestStatus()
        {
            PrestageStatusResponseDto prestagestatusResponseDto = new PrestageStatusResponseDto();
            return prestagestatusResponseDto;
        }
    }
}
