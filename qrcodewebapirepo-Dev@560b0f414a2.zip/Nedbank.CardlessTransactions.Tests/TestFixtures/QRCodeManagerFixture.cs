﻿using Microsoft.Extensions.Logging;
using Moq;
using Nedbank.CardlessTransactions.API.Common.Helper;
using Nedbank.CardlessTransactions.API.DataLayer.EntityFrameworkCore.UnitOfWork;
using Nedbank.CardlessTransactions.API.Domain.Manager;
using Nedbank.CardlessTransactions.Tests.Base;
using Nedbank.CardlessTransactions.Tests.TestCases.UnitTestCases.QRCode;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.Tests.TestFixtures
{
    public class QRCodeManagerFixture : BaseCardLessWithdrawalFixture
    {
        public Mock<IUnitOfWork> _unitOfWork;
        public Mock<ICommonHelper> _helper { get; }
        public Mock<ILogger<QRCodesManager>> _appointmentLogger;
        public QRCodeManagerFixture()
        {
            this._unitOfWork = new Mock<IUnitOfWork>();
            _unitOfWork.Setup(a => a.Context).Returns(base.Context);
            this._helper = new Mock<ICommonHelper>();
            this._appointmentLogger = new Mock<ILogger<QRCodesManager>>();

        }
    }
}
