﻿using Moq;
using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.Tests.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.Tests.TestFixtures
{
    public class QRCodeFixture : BaseCardLessWithdrawalFixture
    {
        public IEfRepository<API.DataLayer.Entities.QRCode> _repository { get; }
        public Mock<IQRCodesManager> QRCodeManager { get; }
        public QRCodeFixture()
        {
            this._repository = new EfRepository<API.DataLayer.Entities.QRCode>(this.Context);
            this.QRCodeManager = new Mock<IQRCodesManager>();
        }

        public string GetQRCode()
        {
            return "tter1tran1";
        }

        public virtual PostQRCodesResponse PostQRCodeNotFound()
        {
           return  new PostQRCodesResponse()
            {
                Isvalid = false,
                TerminalId = "",
                TransactionId = ""
            };
        }
        public virtual PostQRCodesResponse PostQRDataFail()
        {
            return new PostQRCodesResponse()
            {
                Isvalid = true,
                TerminalId = "ter1",
                TransactionId = "trans1"
            };
        }

    }
}
