﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using Nedbank.CardlessTransactions.API.Common.Functional.Enum;
using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using Nedbank.CardlessTransactions.API.DataLayer.Specifications;
using Nedbank.CardlessTransactions.API.Domain.Configuration;
using Nedbank.CardlessTransactions.API.Domain.Dto.Notifications;
using Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto;
using Nedbank.CardlessTransactions.API.Domain.Manager;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.Tests.TestFixtures;
using Shouldly;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Nedbank.CardlessTransactions.Tests.TestCases.UnitTestCases.QRCode
{
    public class QRCodeManagerTest : IClassFixture<QRCodeManagerFixture>
    {
        private readonly QRCodeManagerFixture _fixture;
        private readonly IMapper _mapper;
        public IQRCodesManager _qRCodesManager;
        private readonly Mock<IHttpContextAccessor> __httpContextAccessor;
        private readonly Mock<IEfRepository<API.DataLayer.Entities.QRCode>> _qRCodeRepository;
        private readonly Mock<IEfRepository<API.DataLayer.Entities.Prestage>> _preStageRepository;
        private readonly ILogger<QRCodesManager> _logger;
        private readonly IOptions<QRCodeConfigurationSetting> _options;
        public QRCodeManagerTest(QRCodeManagerFixture fixture)
        {
            this._fixture = fixture;
            _qRCodeRepository = new Mock<IEfRepository<API.DataLayer.Entities.QRCode>>();
            _preStageRepository = new Mock<IEfRepository<API.DataLayer.Entities.Prestage>>();
            __httpContextAccessor = new Mock<IHttpContextAccessor>();
            _fixture = fixture;
            _mapper = _fixture.AutoMapper;
            _options = Options.Create(_fixture.TestData.QrCodeConfigSetting());
            _logger = Mock.Of<ILogger<QRCodesManager>>();
            _qRCodesManager = new QRCodesManager(
                                _fixture._unitOfWork.Object,
                                __httpContextAccessor.Object,
                                _fixture.Context,
                                _mapper,
                                _fixture._helper.Object,
                                _logger, _options);
        }
        #region Positive  Test Cases
        [Theory]
        [InlineData("ter1", "tran1", "sess1")]
        public async Task GetQRCodeAsync_Should_Create_QR_Code_And_Return(string terminalId, string transactionId, string atmSessionToken)
        {
            var request = $"{terminalId}:{transactionId}:{atmSessionToken}";
            _qRCodeRepository.Setup(a => a.AddAsync(It.IsAny<API.DataLayer.Entities.QRCode>())).ReturnsAsync(_fixture.TestData.GetQRCodeCreated());
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.QRCode>()).Returns(_qRCodeRepository.Object);
            var response = await _qRCodesManager.GetQRCodeAsync(terminalId, transactionId);
            response.ShouldNotBeNull();
        }

        [Theory]
        [InlineData("1", "ter1:tran1:sess1")]
        public async Task PostQRCodeAsync_Should_Validate_QR_Code(int preStageId, string qRCode)
        {
            string profilenum = "Pn1";
            var input = new PostQRCodeRequest()
            {
                PrestageId = preStageId,
                QrCode = qRCode
            };
            string[] qrCodeInput = qRCode.Split(":");
            string terminalId = qrCodeInput[0];
            string transactionId = qrCodeInput[1];
            string sessionId = qrCodeInput[2];
            var qrCodeSpecification = new QRCodeValidateFilterSpecification(terminalId: terminalId, transactionId: transactionId
                                                                            , sessionId: sessionId);
            var preStageSpecification = new PrestageUpdateFilterSpecification(Id: input.PrestageId,
                                                                                PrestageStatus: Statuses.Prestaged.ToString(),
                                                                                 ProfileNumber: profilenum);
            _qRCodeRepository.Setup(a => a.FindSingleByAsync(It.IsAny<QRCodeValidateFilterSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetQRCodeList().AsQueryable()
                                            .SingleOrDefault(qrCodeSpecification.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.QRCode>()).Returns(_qRCodeRepository.Object);

            _preStageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageUpdateFilterSpecification>()))
                                        .ReturnsAsync(_fixture.TestData.GetPreStageDataList().AsQueryable()
                                        .SingleOrDefault(preStageSpecification.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_preStageRepository.Object);
            _preStageRepository.Setup(s => s.UpdateAsync(It.IsAny<API.DataLayer.Entities.Prestage>())).Verifiable();
            _fixture._unitOfWork.Setup(x => x.CommitAsync()).ReturnsAsync(1);

            var response = await _qRCodesManager.PostQRCodeAsync(input);
            response.ShouldNotBeNull();
            response.TerminalId.ShouldBe(terminalId);
            response.TransactionId.ShouldBe(transactionId);
            response.Isvalid.ShouldBe(true);

        }
        //[Theory]
        //[InlineData("1", "ter1:tran1:Token1", true)]
        //public async Task PostSendNotificationAsync_Should_Send_Notification(int preStageId, string qRCode, bool isValid)
        //{
        //    string profilenum = "Pn1";
        //    var input = new PostQRCodeRequest()
        //    {
        //        PrestageId = preStageId,
        //        QrCode = qRCode
        //    };
        //    string[] qrCodeInput = qRCode.Split(":");
        //    string terminalId = qrCodeInput[0];
        //    string transactionId = qrCodeInput[1];
        //    string sessionId = qrCodeInput[2];

        //    var preStageSpecification = new PrestageGetFilterSpecification(ProfileNumber: profilenum,
        //                                                                   ValidUpto: DateTime.Now,
        //                                                                   PrestageStatus: Statuses.Prestaged.ToString());
        //    _preStageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageGetFilterSpecification>()))
        //                                .ReturnsAsync(_fixture.TestData.GetPreStageDataList().AsQueryable()
        //                                .SingleOrDefault(preStageSpecification.Criteria));
        //    _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_preStageRepository.Object);

        //    SendNotificationDto sendDto = new SendNotificationDto
        //    {
        //        Amount = 100,
        //        FromAccount = "saving",
        //        IsValid = isValid,
        //        PrestageId = preStageId,
        //        TerminalId = terminalId,
        //        TransactionId = transactionId
        //    };
        //    //

        //    //
        //    //Testing
        //    var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
        //    handlerMock
        //       .Protected()
        //       // Setup the PROTECTED method to mock
        //       .Setup<Task<HttpResponseMessage>>(
        //          "SendAsync",
        //          ItExpr.IsAny<HttpRequestMessage>(),
        //          ItExpr.IsAny<CancellationToken>()
        //       )
        //       // prepare the expected response of the mocked http call
        //       .ReturnsAsync(new HttpResponseMessage()
        //       {
        //           StatusCode = HttpStatusCode.OK,
        //           Content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(true))
        //           //Content = new StringContent("[{'id':1,'value':'1'}]"),
        //       }).Verifiable();
        //    var client = new HttpClient(handlerMock.Object);

        //    _fixture._helper.Setup(a => a.Client).Returns(client).Verifiable();
        //    //
        //    _fixture._helper.Setup(a => a.PostAsync<SendNotificationDto, bool>(_options.Value.NotificationHubBaseUrl, sendDto, "",
        //                      null, null, false)).ReturnsAsync(true);
        //    bool status = await _qRCodesManager.PostSendNotificationAsync(input, isValid);
        //    status.ShouldBeTrue();
        //    //

        //    //10Sept
        //    //var httpMessageHandler = new Mock<HttpMessageHandler>();
        //    //var fixture = new Fixture();

        //    //// Setup Protected method on HttpMessageHandler mock.    
        //    //httpMessageHandler.Protected()
        //    //    .Setup<Task<HttpResponseMessage>>(
        //    //   "SendAsync",
        //    //    ItExpr.IsAny<HttpRequestMessage>(),
        //    //    ItExpr.IsAny<CancellationToken>()
        //    //    )
        //    //    .ReturnsAsync((HttpRequestMessage request, CancellationToken token) =>
        //    //    {
        //    //        //HttpResponseMessage apiResponse = await client.PostAsync(uri, byteArrayAsHttpContent);
        //    //        //string jsonResponse = await apiResponse.Content.ReadAsStringAsync();
        //    //        //if ((int)apiResponse.StatusCode == (int)HttpStatusCode.Unauthorized)
        //    //        //{
        //    //        //    throw new UnauthorizedAccessException("You are not authorized to perform this operation!");
        //    //        //}
        //    //        //apiResponse.EnsureSuccessStatusCode();
        //    //        //return JsonConvert.DeserializeObject<RS>(jsonResponse);

        //    //        HttpResponseMessage response = new HttpResponseMessage();
        //    //        response.StatusCode = System.Net.HttpStatusCode.OK;//Setting statuscode    
        //    //        response.Content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(true)); // configure your response here    
        //    //        response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json"); //Setting media type for the response    
        //    //        return response;
        //    //    }).Verifiable();

        //    //var httpClient = new HttpClient(httpMessageHandler.Object);
        //    ////httpClient.BaseAddress= fixture.Create<Uri>();
        //    //_fixture._helper.Setup(a => a.Client).Returns(httpClient).Verifiable();
        //    //
        //    //_fixture._helper.Setup(a => a.PostAsync<SendNotificationDto, bool>(_options.Value.NotificationHubBaseUrl, sendDto, "",
        //    //                  null, null, false)).ReturnsAsync(true).Verifiable();


        //    //bool status = await _qRCodesManager.PostSendNotificationAsync(input, isValid);
        //    //status.ShouldBeTrue();
        //}

        #endregion

        #region Negative Test Cases
        [Theory]
        [InlineData("", "trans1")]
        [InlineData("ter1", "")]
        public async Task GetQRCodeAsync_Should_Throw_Exception(string terminalId, string transactionId)
        {
            await Should.ThrowAsync<Exception>(async () =>
            {
                await _qRCodesManager.GetQRCodeAsync(terminalId, transactionId);
            });
        }

        [Theory]
        [InlineData("1", "ter321:tran1:sess1")]
        [InlineData("1", "ter1:tran12:sess1")]
        [InlineData("1", "ter1:tran1:sess12")]
        [InlineData("12", "ter11:tran11:sess12")]
        public async Task PostQRCodeAsync_Should_Throw_QR_Code_Not_Found(int preStageId, string qRCode)
        {
            var input = new PostQRCodeRequest()
            {
                PrestageId = preStageId,
                QrCode = qRCode
            };
            string[] qrCodeInput = qRCode.Split(":");
            string terminalId = qrCodeInput[0];
            string transactionId = qrCodeInput[1];
            string sessionId = qrCodeInput[2];
            var qrCodeSpecification = new QRCodeValidateFilterSpecification(terminalId: terminalId, transactionId: transactionId
                                                                            , sessionId: sessionId);
            _qRCodeRepository.Setup(a => a.FindSingleByAsync(It.IsAny<QRCodeValidateFilterSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetQRCodeList().AsQueryable()
                                            .SingleOrDefault(qrCodeSpecification.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.QRCode>()).Returns(_qRCodeRepository.Object);
            var response = await _qRCodesManager.PostQRCodeAsync(input);
            response.TerminalId.ShouldBeNull();
            response.TransactionId.ShouldBeNull();
            response.Isvalid.ShouldBe(false);
        }

        [Theory]
        [InlineData("2", "ter1:tran1:sess1")]
        [InlineData("10", "123:56777:")]
        public async Task PostQRCodeAsync_Should_Throw_Pre_Staged_Data_Not_Found(int preStageId, string qRCode)
        {
            string profilenum = "Pn1";
            var input = new PostQRCodeRequest()
            {
                PrestageId = preStageId,
                QrCode = qRCode
            };
            string[] qrCodeInput = qRCode.Split(":");
            string terminalId = qrCodeInput[0];
            string transactionId = qrCodeInput[1];
            string sessionId = qrCodeInput[2];
            var qrCodeSpecification = new QRCodeValidateFilterSpecification(terminalId: terminalId, transactionId: transactionId
                                                                            , sessionId: sessionId);
            var preStageSpecification = new PrestageUpdateFilterSpecification(Id: input.PrestageId,
                                                                                PrestageStatus: Statuses.Prestaged.ToString(),
                                                                                 ProfileNumber: profilenum);
            _qRCodeRepository.Setup(a => a.FindSingleByAsync(It.IsAny<QRCodeValidateFilterSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetQRCodeList().AsQueryable()
                                            .SingleOrDefault(qrCodeSpecification.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.QRCode>()).Returns(_qRCodeRepository.Object);

            _preStageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageUpdateFilterSpecification>()))
                                        .ReturnsAsync(_fixture.TestData.GetPreStageDataList().AsQueryable()
                                        .SingleOrDefault(preStageSpecification.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_preStageRepository.Object);
            var response = await _qRCodesManager.PostQRCodeAsync(input);
            response.TerminalId.ShouldBeNull();
            response.TransactionId.ShouldBeNull();
            response.Isvalid.ShouldBe(false);
        }

        [Theory]
        [InlineData("11", "11:123:sess234")]
        public async Task PostQRCodeAsync_Should_Through_Exception(int preStageId, string qRCode)
        {
            string profilenum = "P1";
            var input = new PostQRCodeRequest()
            {
                PrestageId = preStageId,
                QrCode = qRCode
            };
            string[] qrCodeInput = qRCode.Split(":");
            string terminalId = qrCodeInput[0];
            string transactionId = qrCodeInput[1];
            string sessionId = qrCodeInput[2];
            var qrCodeSpecification = new QRCodeValidateFilterSpecification(terminalId: terminalId, transactionId: transactionId
                                                                            , sessionId: sessionId);
            var preStageSpecification = new PrestageUpdateFilterSpecification(Id: input.PrestageId,
                                                                                PrestageStatus: Statuses.Prestaged.ToString(),
                                                                                 ProfileNumber: profilenum);
            _qRCodeRepository.Setup(a => a.FindSingleByAsync(It.IsAny<QRCodeValidateFilterSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetQRCodeList().AsQueryable()
                                            .SingleOrDefault(qrCodeSpecification.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.QRCode>()).Returns(_qRCodeRepository.Object);

            _preStageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageUpdateFilterSpecification>()))
                                        .ReturnsAsync(_fixture.TestData.GetPreStageDataList().AsQueryable()
                                        .SingleOrDefault(preStageSpecification.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_preStageRepository.Object);
            _preStageRepository.Setup(s => s.UpdateAsync(It.IsAny<API.DataLayer.Entities.Prestage>())).Verifiable();
            _fixture._unitOfWork.Setup(x => x.CommitAsync()).ReturnsAsync(1);
            await Should.ThrowAsync<Exception>(async () =>
            {
                await _qRCodesManager.PostQRCodeAsync(input);
            });

        }

        //[Theory]
        //[InlineData("1", "ter1:tran1:Token1", true)]  //TODO: To implement
        public async Task PostSendNotificationAsync_Should_Fail_To_Send_Notification(int preStageId, string qRCode, bool isValid)
        {
            string profilenum = "Ppp1";
            var input = new PostQRCodeRequest()
            {
                PrestageId = preStageId,
                QrCode = qRCode
            };
            string[] qrCodeInput = qRCode.Split(":");
            string terminalId = qrCodeInput[0];
            string transactionId = qrCodeInput[1];
            string sessionId = qrCodeInput[2];

            var preStageSpecification = new PrestageGetFilterSpecification(ProfileNumber: profilenum,
                                                                           ValidUpto: DateTime.Now,
                                                                           PrestageStatus: Statuses.Prestaged.ToString());
            _preStageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageGetFilterSpecification>()))
                                        .ReturnsAsync(_fixture.TestData.GetPreStageDataList().AsQueryable()
                                        .SingleOrDefault(preStageSpecification.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_preStageRepository.Object);

            SendNotificationDto send = new SendNotificationDto
            {
                Amount = 100,
                CardNumber="1234",
                CardExpirydate=2110,
                AccountType = "saving",
                IsValid = isValid,
                PrestageId = preStageId,
                TerminalId = terminalId,
                TransactionId = transactionId
            };
            _fixture._helper.Setup(a => a.PostAsync<SendNotificationDto, bool>(_options.Value.NotificationHubBaseUrl, send, 
                null, "", false)).ReturnsAsync(false);
            bool status = await _qRCodesManager.PostSendNotificationAsync(input, isValid);
            status.ShouldBeFalse();
        }

        #endregion

    }
}
