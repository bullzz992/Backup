﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Nedbank.CardlessTransactions.API.Application.Controllers;
using Nedbank.CardlessTransactions.API.Application.Controllers.Interfaces;
using Nedbank.CardlessTransactions.API.Common.Constants;
using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.Application.Models;
using Nedbank.CardlessTransactions.Tests.MockData;
using Nedbank.CardlessTransactions.Tests.TestFixtures;
using Shouldly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Nedbank.CardlessTransactions.Tests.TestCases.UnitTestCases.QRCode
{
    public class QRCodeUnitTestController : IClassFixture<QRCodeFixture>
    {
        #region Members
        private readonly QRCodeFixture _fixture;
        IEfRepository<API.DataLayer.Entities.QRCode> _repository;
        IQRCodesController _controller;
        Mock<IQRCodesManager> _manager;
        IMapper _mapper;
        private readonly ILogger<QRCodesController> _logger;

        #endregion

        #region Ctor
        public QRCodeUnitTestController(QRCodeFixture fixture)
        {
            _fixture = fixture;
            _mapper = _fixture.AutoMapper;
            _manager = _fixture.QRCodeManager;
            _repository = _fixture._repository;
            _logger = Mock.Of<ILogger<QRCodesController>>();

            _controller = new QRCodesController(_manager.Object, _logger);
        }
        #endregion
        [Theory]
        [InlineData("ter1", "tran1")]
        public async Task GetAsync_QRCode_Should_Return(string terminalId, string transactionId)
        {
            try
            {
                _manager.Setup(x => x.GetQRCodeAsync(terminalId, transactionId)).Returns(Task.FromResult(_fixture.GetQRCode()));
                var response = await _controller.GetQRCodeAsync(terminalId, transactionId);
                ValidateSuccessResponse(response.Metadata);
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        [Theory]
        [InlineData("1", "ter1tran1")]
        public async Task PostAsync_QRCode_Should_Validate(int preStageId, string qRCode)
        {
            var qRCodeRequest = new PostQRCodeRequest()
            {
                PrestageId = preStageId,
                QrCode = qRCode
            };
            var qRCodeResponse = new PostQRCodesResponse()
            {
                Isvalid = true,
                TerminalId = "ter1",
                TransactionId = "tran1"
            };
            _manager.Setup(x => x.PostQRCodeAsync(It.IsAny<PostQRCodeRequest>())).Returns(Task.FromResult(qRCodeResponse));
            _manager.Setup(x => x.PostSendNotificationAsync(It.IsAny<PostQRCodeRequest>(), It.IsAny<bool>())).Returns(Task.FromResult(true));
            var response = await _controller.PostQRCodeAsync(qRCodeRequest);
            response.ShouldNotBeNull();
            ValidateSuccessResponse(response.Metadata);
        }

        #region Negative Test cases
        [Theory]
        [ClassData(typeof(ValidateQRCodeNegativeFlowTestData))]
        public async Task PostAsync_QR_Code_Should_Not_Found(PostQRCodeRequest request)
        {
            _manager.Setup(x => x.PostQRCodeAsync(It.IsAny<PostQRCodeRequest>())).Returns(Task.FromResult(_fixture.PostQRCodeNotFound()));
            _manager.Setup(x => x.PostSendNotificationAsync(It.IsAny<PostQRCodeRequest>(), It.IsAny<bool>())).Returns(Task.FromResult(false));
            var response = await _controller.PostQRCodeAsync(request);
            ValidateNotFoundResponse(response.Metadata);
        }
        [Theory]
        [ClassData(typeof(ValidateQRCodeNegativeFlowTestData))]
        public async Task PostAsync_QR_Code_Should_Fail(PostQRCodeRequest request)
        {
            _manager.Setup(x => x.PostQRCodeAsync(It.IsAny<PostQRCodeRequest>())).Returns(Task.FromResult(_fixture.PostQRDataFail()));
            _manager.Setup(x => x.PostSendNotificationAsync(It.IsAny<PostQRCodeRequest>(), It.IsAny<bool>())).Returns(Task.FromResult(false));
            var response = await _controller.PostQRCodeAsync(request);
            ValidateResponseFail(response.Metadata);
        }
        //[Theory]
        //[ClassData(typeof(GetQRCodeNegativeTestData))]
        //public async Task GetAsync_QRCode_Should_Throw_Exception(string terminalId, string transactionId)
        //{
        //    await Should.ThrowAsync<Exception>(async () =>
        //    {
        //        await _controller.GetQRCodeAsync(terminalId, transactionId); ;
        //    });
        //}

        #endregion

        #region Helper Method
        /// <summary>
        /// Method is used to validate success response checked 
        /// </summary>
        /// <param name="response"></param>
        private static void ValidateSuccessResponse(ResponseMetadata responseMetaData)
        {
            //Data.Status.ShouldBe(ResponseStatus.Success);
            responseMetaData.ResultData[0].ResultCode.ShouldBe((GlobalConstants.ResultCodes.SuccessCode));
            responseMetaData.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.OK));
            responseMetaData.ResultData[0].ResultDescription.ToLowerInvariant().ShouldBe("ok");
        }
        private static void ValidateNotFoundResponse(ResponseMetadata responseMetaData)
        {
            responseMetaData.ResultData[0].ResultCode.ShouldBe((GlobalConstants.ResultCodes.RecordNotFound));
            responseMetaData.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.NotFound));

        }
        private static void ValidateResponseFail(ResponseMetadata responseMetaData)
        {
            responseMetaData.ResultData[0].ResultCode.ShouldBe((GlobalConstants.ResultCodes.ErrorCodeR01));
            responseMetaData.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.InternalServerError));

        }
        #endregion
    }
}
