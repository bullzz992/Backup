﻿using Nedbank.CardlessTransactions.Tests.TestFixtures;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Moq;
using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using Nedbank.CardlessTransactions.API.Domain.Manager;
using System.Threading.Tasks;
using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using Nedbank.CardlessTransactions.API.DataLayer.Specifications;
using Nedbank.CardlessTransactions.API.Common.Functional.Enum;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.EntityFrameworkCore;
using Shouldly;
using System.Configuration;
using Microsoft.Net.Http.Headers;
using System.Net.Http.Headers;
using Microsoft.Extensions.Options;
using Nedbank.CardlessTransactions.API.Domain.Configuration;
using Microsoft.Extensions.Logging;

namespace Nedbank.CardlessTransactions.Tests.TestCases.UnitTestCases.PreStage
{
    public class PrestagesManagerUnitTest : IClassFixture<PrestagesManagerFixture>
    {
        #region [Fields]

        private readonly PrestagesManagerFixture _fixture;
        private readonly IMapper _mapper;
        public IPrestagesManager _prestagesManager;
        private readonly Mock<IHttpContextAccessor> _httpContextAccessor;
        private readonly Mock<IEfRepository<Prestage>> _prestageRepository;
        private readonly Mock<IEfRepository<API.DataLayer.Entities.QRCode>> _qRCodeRepository;
        private readonly ILogger<PrestagesManager> _logger;

        private readonly IOptions<BackOfficeNotificationConfiguration> _options;

        #endregion
        public PrestagesManagerUnitTest(PrestagesManagerFixture fixture)
        {
            _prestageRepository = new Mock<IEfRepository<Nedbank.CardlessTransactions.API.DataLayer.Entities.Prestage>>();
            _qRCodeRepository = new Mock<IEfRepository<API.DataLayer.Entities.QRCode>>();
            _httpContextAccessor = new Mock<IHttpContextAccessor>();
            _fixture = fixture;
            _mapper = _fixture.AutoMapper;
            _logger = Mock.Of<ILogger<PrestagesManager>>();

            //To-Do  Need To add static data in BackOfficeNotificationSetting 
            _options = Options.Create(_fixture.TestData.BackOfficeNotificationSetting());
            _prestagesManager = new PrestagesManager(
                _fixture.Context,
                _mapper,
                fixture._helper.Object,
                _fixture._unitOfWork.Object,
                _fixture._enumHelper.Object,
                _httpContextAccessor.Object,
                _logger,
                _options
                
                );
        }

        #region GetPresateAsync
        [Fact]
        public async Task GetPresateAsync_Should_return_Prestaged_Request()
        {
            // Arrange
            string profilenumber = "pn1";
            var prestageSpec = new PrestageGetFilterSpecification(ProfileNumber: profilenumber, ValidUpto: DateTime.Now,
                                                                   PrestageStatus: Statuses.Prestaged.ToString());

            var prestageIsExistingSpec = new PrestageCheckIsExistingUserFilterSpecification(ProfileNumber: profilenumber);
            _prestageRepository.Setup(s => s.FindFirstOrDefaultByAsync(It.IsAny<PrestageCheckIsExistingUserFilterSpecification>()))
               .ReturnsAsync(_fixture.TestData.GetPrestageData().AsQueryable().SingleOrDefault(prestageIsExistingSpec.Criteria));

            _prestageRepository.Setup(s => s.FindSingleByAsync(It.IsAny<PrestageGetFilterSpecification>()))
               .ReturnsAsync(_fixture.TestData.GetPrestageData().AsQueryable().SingleOrDefault(prestageSpec.Criteria));

            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);

            // Act
            var IsExistingResponse = await _prestagesManager.CheckIsExistingUserAsync();
            var response = await _prestagesManager.GetPrestagedAsync();
            // Assert
            response.IsExistingUser.ShouldBeTrue();
            response.PrestageResponses.ShouldNotBeNull();
            response.PrestageResponses.Length.ShouldBe(1);
        }

        [Fact]
        public async Task GetPresateAsync_Empty_ExistingUserFalse()
        {
            // Arrange
            string profilenumber = "pn1";
            var prestageSpec = new PrestageGetFilterSpecification(ProfileNumber: profilenumber, ValidUpto: DateTime.Now,
                                                                   PrestageStatus: Statuses.Prestaged.ToString());
            var prestageIsExistingSpec = new PrestageCheckIsExistingUserFilterSpecification(ProfileNumber: profilenumber);

            _prestageRepository.Setup(s => s.FindFirstOrDefaultByAsync(It.IsAny<PrestageCheckIsExistingUserFilterSpecification>()))
                .ReturnsAsync(_fixture.TestData.GetPrestageNull());
            _prestageRepository.Setup(s => s.FindSingleByAsync(It.IsAny<PrestageGetFilterSpecification>())).ReturnsAsync(_fixture.TestData.GetPrestageData().
            AsQueryable().SingleOrDefault(prestageSpec.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);

            // Act
            var IsExistingResponse = await _prestagesManager.CheckIsExistingUserAsync();
            var response = await _prestagesManager.GetPrestagedAsync();
            // Assert
            response.IsExistingUser.ShouldBeFalse();
            response.PrestageResponses.ShouldBeNull();
        }

        [Fact]
        public async Task GetPresateAsync_Empty_ExistingUserTrue()
        {
            // Arrange
            string profilenumber = "pn1";
            var prestageSpec = new PrestageGetFilterSpecification(ProfileNumber: profilenumber, ValidUpto: DateTime.Now,
                                                                   PrestageStatus: Statuses.Prestaged.ToString());

            var prestageIsExistingSpec = new PrestageCheckIsExistingUserFilterSpecification(ProfileNumber: profilenumber);
            _prestageRepository.Setup(s => s.FindFirstOrDefaultByAsync(It.IsAny<PrestageCheckIsExistingUserFilterSpecification>())).ReturnsAsync(_fixture.TestData.GetPrestageData().
            AsQueryable().SingleOrDefault(prestageIsExistingSpec.Criteria));
            _prestageRepository.Setup(s => s.FindSingleByAsync(It.IsAny<PrestageGetFilterSpecification>())).ReturnsAsync(_fixture.TestData.GetPrestageNull());
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);
            // Act
            var IsExistingResponse = await _prestagesManager.CheckIsExistingUserAsync();
            var response = await _prestagesManager.GetPrestagedAsync();
            // Assert
            response.IsExistingUser.ShouldBeTrue();
            response.PrestageResponses.ShouldBeNull();
        }

        #endregion

        #region GetStatusAsync

        [Fact]
        public async Task GetStatusAsync_Should_Update_Status()
        {
            // Arrange
            string profilenumber = "pn1";
            long id = 1;
            var prestageSpec = new PrestageGetStatusFilterSpecification(Id: id, ProfileNumber: profilenumber);
            _prestageRepository.Setup(s => s.FindSingleByAsync(It.IsAny<PrestageGetStatusFilterSpecification>())).ReturnsAsync(_fixture.TestData.GetPrestagedStatus());
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);
            // Act
            var response = await _prestagesManager.GetStatusAsync(id);
            // Assert
            response.ShouldNotBeNull();
            response.StatusCode.Equals(Statuses.Prestaged.ToString());
        }

        [Fact]
        public async Task GetStatusAsync_NotFound()
        {
            // Arrange
            string profilenumber = "pn1";
            long id = 1;
            var prestageSpec = new PrestageGetStatusFilterSpecification(Id: id, ProfileNumber: profilenumber);
            _prestageRepository.Setup(s => s.FindSingleByAsync(It.IsAny<PrestageGetStatusFilterSpecification>())).ReturnsAsync(_fixture.TestData.Getstatus_null());
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);
            // Act
            var response = await _prestagesManager.GetStatusAsync(id);
            // Assert
            response.ShouldNotBeNull();
            response.StatusCode.ShouldBeNull();
        }

        #endregion

        #region CreateAsync
        [Fact]
        public async Task CreateAsyncTest()
        {
            // Arrange
            CreatePrestageRequestDto input = new CreatePrestageRequestDto()
            {
                CardNumber = "act123",
                CardExpiryDate = 2510,
                AccountType = "saving",
                Amount = 1000
            };
            _prestageRepository.Setup(a => a.AddAsync(It.IsAny<API.DataLayer.Entities.Prestage>())).ReturnsAsync(_fixture.TestData.GetPresatgeCreated());
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);
            // Act
            var prestageData = await _prestagesManager.CreateAsync(input);
            // Assert
            prestageData.PrestageId.Equals(1);
        }

        [Theory]
        [InlineData(null)]
        public async Task CreateAsync_Input_Null_Throw_Exception(CreatePrestageRequestDto input)
        {
            // Arrange
            await Should.ThrowAsync<Exception>(async () =>
            {
                await _prestagesManager.CreateAsync(input);
            });

        }

        #endregion

        #region UpdateAsync
        [Theory]
        [InlineData(1)]
        public async Task UpdateAsyncTest(long id)
        {
            // Arrange
            UpdatePrestageRequestDto input = new UpdatePrestageRequestDto()
            {
                CardNumber = "act123",
                CardExpiryDate = 2510,
                AccountType = "saving",
                Amount = 1000,
            };
            _httpContextAccessor.Setup(x => x.HttpContext.User.Identity.Name).Returns(It.IsAny<string>());
            var prestageUpdateSpec = new PrestageUpdateFilterSpecification(Id: id, PrestageStatus: Statuses.Prestaged.ToString(), ProfileNumber: "pn1");
            _prestageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageUpdateFilterSpecification>())).ReturnsAsync(_fixture.TestData.GetPresatgeUpdated());
            _prestageRepository.Setup(a => a.UpdateAsync(It.IsAny<API.DataLayer.Entities.Prestage>())).ShouldNotBeNull();
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);
            // Act
            var prestageData = await _prestagesManager.UpdateAsync(id, input);
            // Assert,
            prestageData.PrestageId.Equals(id);
        }


        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        public async Task UpdateAsync_id_Negative_And_Zero_Throw_Exception(long id)
        {
            // Arrange
            UpdatePrestageRequestDto input = new UpdatePrestageRequestDto()
            {
                CardNumber = "act123",
                CardExpiryDate = 2510,
                AccountType = "saving",
                Amount = 1000,
            };

            // Act
            _httpContextAccessor.Setup(x => x.HttpContext.User.Identity.Name).Returns(It.IsAny<string>());

            var prestageUpdateSpec = new PrestageUpdateFilterSpecification(Id: id, PrestageStatus: Statuses.Prestaged.ToString(), ProfileNumber: "pn1");
            _prestageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageUpdateFilterSpecification>())).ReturnsAsync(_fixture.TestData.GetPresatgeUpdated());

            _prestageRepository.Setup(a => a.UpdateAsync(It.IsAny<Prestage>())).ShouldNotBeNull();
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<Prestage>()).Returns(_prestageRepository.Object);


            // Assert

            await Should.ThrowAsync<Exception>(async () =>
            {
                await _prestagesManager.UpdateAsync(id, input); ;
            });
        }

        [Theory]
        [InlineData(4)]
        public async Task UpdateAsync_RecordNotFound_Throw_Exception(long id)
        {
            UpdatePrestageRequestDto input = new UpdatePrestageRequestDto()
            {
                CardNumber = "act123",
                CardExpiryDate = 2510,
                AccountType = "saving",
                Amount = 1000,
            };

            // Act
            _httpContextAccessor.Setup(x => x.HttpContext.User.Identity.Name).Returns(It.IsAny<string>());

            var prestageUpdateSpec = new PrestageUpdateFilterSpecification(Id: id, PrestageStatus: Statuses.Prestaged.ToString(), ProfileNumber: "pn1");
            _prestageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageUpdateFilterSpecification>())).
                ReturnsAsync(_fixture.TestData.GetPresatgeUpdated_Blank());

            _prestageRepository.Setup(a => a.UpdateAsync(It.IsAny<Prestage>())).Verifiable();
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<Prestage>()).Returns(_prestageRepository.Object);

            //ACT
            var response = await _prestagesManager.UpdateAsync(id, input);
            // Assert
            response.ShouldNotBeNull();
            response.PrestageId.Equals(0);
        }

        [Theory]
        [InlineData(1, null)]
        public async Task UpdateAsync_RequestBody_Null_Throw_Exception(long id, UpdatePrestageRequestDto input)
        {
            await Should.ThrowAsync<Exception>(async () =>
            {
                await _prestagesManager.UpdateAsync(id, input); ;
            });
        }
        #endregion

        #region DeleteAsync

        [Theory]
        [InlineData(1)]
        public async Task DeleteAsync_Delete_Successfuly(long id)
        {
            // Arrange
            string profilenum = "pn1";
            var prestageSpec = new PrestageDeleteFilterSpecification(Id: id, PrestagedStatus: Statuses.Prestaged.ToString(), ProfileNuber: profilenum);
            _httpContextAccessor.Setup(x => x.HttpContext.User.Identity.Name).Returns(It.IsAny<string>());
            _prestageRepository.Setup(s => s.FindSingleByAsync(It.IsAny<PrestageDeleteFilterSpecification>())).ReturnsAsync(_fixture.TestData.GetPrestageData().
             AsQueryable().SingleOrDefault(prestageSpec.Criteria));
            _prestageRepository.Setup(a => a.DeleteAsync(It.IsAny<API.DataLayer.Entities.Prestage>())).ShouldNotBeNull();
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);
            // Act
            var response = await _prestagesManager.DeleteAsync(id);
            // Assert
            response.PrestageId.Equals(1);
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        public async Task DeleteAsync_Throw_Exception(long id)
        {

            // Arrange
            string profilenum = "pn1";
            var prestageSpec = new PrestageDeleteFilterSpecification(Id: id, PrestagedStatus: Statuses.Prestaged.ToString(), ProfileNuber: profilenum);
            // Act
            _httpContextAccessor.Setup(x => x.HttpContext.User.Identity.Name).Returns(It.IsAny<string>());
            _prestageRepository.Setup(s => s.FindSingleByAsync(It.IsAny<PrestageDeleteFilterSpecification>())).ReturnsAsync(_fixture.TestData.GetPrestageData().
             AsQueryable().SingleOrDefault(prestageSpec.Criteria));
            _prestageRepository.Setup(a => a.DeleteAsync(It.IsAny<API.DataLayer.Entities.Prestage>())).ShouldNotBeNull();
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);
            await Should.ThrowAsync<Exception>(async () =>
            {
                await _prestagesManager.DeleteAsync(id); ;
            });

        }

        #endregion

        #region CheckIsExistingUserAsync
        [Theory]
        [InlineData("pn1")]
        public async Task CheckIsExistingUserAsyncTest(string profilenumber)
        {
            // Arrange
            var prestageSpec = new PrestageCheckIsExistingUserFilterSpecification(ProfileNumber: profilenumber);

            // Act
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.Prestage>()).Returns(_prestageRepository.Object);

            _prestageRepository.Setup(s => s.FindSingleByAsync(It.IsAny<PrestageCheckIsExistingUserFilterSpecification>()))
                .ReturnsAsync(_fixture.TestData.GetPrestageData().AsQueryable().SingleOrDefault(prestageSpec.Criteria));
            var response = await _prestagesManager.CheckIsExistingUserAsync();
            // Assert
            response.ShouldNotBeNull();
        }
        #endregion

        #region GetPrestageValidateAsync
        [Theory]
        [InlineData("ter1", "tran1", "act123", 1000)]
        public async Task GetPrestageValidateAsync_Should_Validate(string terminalId, string transactionId, string cardNumber, int amount)
        {
            long qrCodeId = 1;
            PrestageValidateResponseDto responsedto = new PrestageValidateResponseDto();
            var qRCodeGetSpec = new QRCodeGetFilterTransactionIdTerminalIdSpecification(Terminalid: terminalId,
                                                                                        Transactionid: transactionId,
                                                                                        ValidUpto: DateTime.Now);
            var preStageSpecification = new PrestageGetByQRCodeIdFilterSpecification(QRCodeId: qrCodeId,
                                                                                   PrestageStatus: Statuses.Prestaged.ToString(),
                                                                                   ValidUpto: DateTime.Now);

            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.QRCode>())
                                                        .Returns(_qRCodeRepository.Object);
            _qRCodeRepository.Setup(a => a.FindSingleByAsync(It.IsAny<QRCodeGetFilterTransactionIdTerminalIdSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetQRCodeList().AsQueryable()
                                            .SingleOrDefault(qRCodeGetSpec.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<Prestage>())
                                            .Returns(_prestageRepository.Object);
            _prestageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageGetByQRCodeIdFilterSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetPreStageDataList().AsQueryable()
                                            .SingleOrDefault(preStageSpecification.Criteria));
            var response = await _prestagesManager.GetPrestageValidateAsync(terminalId, transactionId, cardNumber, amount);
            response.ShouldNotBeNull();
            response.IsValid.ShouldBeTrue();
            response.PrestageId.ShouldBe(1);
        }
        [Theory]
        [InlineData("ter1", "tran1", "saving", 1000)]
        public async Task GetPrestageValidateAsync_Should_Fail(string terminalId, string transactionId, string cardNumber, int amount)
        {
            long qrCodeId = 1;
            PrestageValidateResponseDto responsedto = new PrestageValidateResponseDto();
            var qRCodeGetSpec = new QRCodeGetFilterTransactionIdTerminalIdSpecification(Terminalid: terminalId,
                                                                                        Transactionid: transactionId,
                                                                                        ValidUpto: DateTime.Now);
            var preStageSpecification = new PrestageGetByQRCodeIdFilterSpecification(QRCodeId: qrCodeId,
                                                                                   PrestageStatus: Statuses.Prestaged.ToString(),
                                                                                   ValidUpto: DateTime.Now);

            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.QRCode>())
                                                        .Returns(_qRCodeRepository.Object);
            _qRCodeRepository.Setup(a => a.FindSingleByAsync(It.IsAny<QRCodeGetFilterTransactionIdTerminalIdSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetQRCodeList().AsQueryable()
                                            .SingleOrDefault(qRCodeGetSpec.Criteria));
            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<Prestage>())
                                            .Returns(_prestageRepository.Object);
            _prestageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageGetByQRCodeIdFilterSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetPreStageDataList().AsQueryable()
                                            .SingleOrDefault(preStageSpecification.Criteria));
            var response = await _prestagesManager.GetPrestageValidateAsync(terminalId, transactionId, cardNumber, amount);
            response.IsValid.ShouldBeFalse();
            response.PrestageId.ShouldBe(1);
        }

        [Theory]
        [InlineData("", "", "", 22)]
        [InlineData(" ", "trans1", "saving", 1000)]
        [InlineData("term1", " ", "saving", 1000)]
        [InlineData("term1", "trans1", "", 1000)]
        [InlineData("term1", "trans1", "saving", 0)]
        public async Task GetPrestageValidateAsync_Should_Throw_Exception(string terminalId, string transactionId, string cardNumber, int amount)
        {
            await Should.ThrowAsync<Exception>(async () =>
            {
                await _prestagesManager.GetPrestageValidateAsync(terminalId, transactionId, cardNumber, amount);
            });
        }

        #endregion

        #region UpdatePrestageStatusAsync
        [Theory]
        [InlineData("tran1", "Completed", "Completed")]
        public async Task UpdatePrestageStatusAsync_Should_Update_And_Return(string transactionId, string statusCode, string statusDescription)
        {

            var request = new UpdatePrestageStatusRequestDto
            {
                StatusCode = statusCode
            };
            var response = new UpdatePrestageResponseDto()
            {
                PrestageId = 1
            };

            var qrCodeSpec = new QRCodeGetQRCodeByTransactionIdSpecification(TransactionId: transactionId, ValidUpto: DateTime.Now);

            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.QRCode>())
                                           .Returns(_qRCodeRepository.Object);

            _qRCodeRepository.Setup(a => a.FindSingleByAsync(It.IsAny<QRCodeGetQRCodeByTransactionIdSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetQRCodeDataByTranId());


            var prestageUpdateSpec = new PrestageGetPrestageByQRCodeIdSpecification(QRCodeId: 1,
                                             Status: Statuses.Prestaged.ToString(), ValidUpto: DateTime.Now);

            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<Prestage>())
                                            .Returns(_prestageRepository.Object);
            _prestageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageGetPrestageByQRCodeIdSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetPreStageDataList().AsQueryable()
                                            .SingleOrDefault(prestageUpdateSpec.Criteria));
            _prestageRepository.Setup(s => s.UpdateAsync(It.IsAny<API.DataLayer.Entities.Prestage>())).Verifiable();
            _fixture._unitOfWork.Setup(x => x.CommitAsync()).ReturnsAsync(1);

            var updateResponse = await _prestagesManager.UpdatePrestageStatusAsync(transactionId, request);
            updateResponse.ShouldNotBeNull();
            updateResponse.PrestageId.ShouldBe(response.PrestageId);
        }

        [Theory]
        [InlineData("tran1", "Completed", "Completed")]
        public async Task UpdatePrestageStatusAsync_Should_Fail(string transactionId, string statusCode, string statusDescription)
        {
            string profileNumber = "Pn1";
            var request = new UpdatePrestageStatusRequestDto
            {
                StatusCode = statusCode
            };
            var response = new UpdatePrestageResponseDto()
            {
                PrestageId = 1
            };

            var qrCodeSpec = new QRCodeGetQRCodeByTransactionIdSpecification(TransactionId: transactionId, ValidUpto: DateTime.Now);

            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<API.DataLayer.Entities.QRCode>())
                                           .Returns(_qRCodeRepository.Object);

            //_qRCodeRepository.Setup(a => a.FindSingleByAsync(It.IsAny<QRCodeGetQRCodeByTransactionIdSpecification>()))
            //                                .ReturnsAsync(_fixture.TestData.GetQRCodeDataByTranId());

            _qRCodeRepository.Setup(a => a.FindSingleByAsync(It.IsAny<QRCodeGetQRCodeByTransactionIdSpecification>()))
                                           .ReturnsAsync(_fixture.TestData.GetQRCodeDataByTranId_null());


            var prestageUpdateSpec = new PrestageGetPrestageByQRCodeIdSpecification(QRCodeId: 1,
                                             Status: Statuses.Prestaged.ToString(), ValidUpto: DateTime.Now);

            _fixture._unitOfWork.Setup(a => a.GetRepositoryAsync<Prestage>())
                                            .Returns(_prestageRepository.Object);
            _prestageRepository.Setup(a => a.FindSingleByAsync(It.IsAny<PrestageGetPrestageByQRCodeIdSpecification>()))
                                            .ReturnsAsync(_fixture.TestData.GetPreStageDataList().AsQueryable()
                                            .SingleOrDefault(prestageUpdateSpec.Criteria));
            _prestageRepository.Setup(s => s.UpdateAsync(It.IsAny<API.DataLayer.Entities.Prestage>())).Verifiable();
            _fixture._unitOfWork.Setup(x => x.CommitAsync()).ReturnsAsync(1);

            var updateResponse = await _prestagesManager.UpdatePrestageStatusAsync(transactionId, request);
            updateResponse.PrestageId.ShouldBe(0);
        }

        [Theory]
        [InlineData("", "", "")]
        public async Task UpdatePrestageStatusAsync_Should_Thorw_Exception(string id, string statusCode, string statusDescription)
        {
            var request = new UpdatePrestageStatusRequestDto
            {
                StatusCode = statusCode
            };
            await Should.ThrowAsync<Exception>(async () =>
            {
                await _prestagesManager.UpdatePrestageStatusAsync(id, request);
            });
        }
        #endregion



    }
}
