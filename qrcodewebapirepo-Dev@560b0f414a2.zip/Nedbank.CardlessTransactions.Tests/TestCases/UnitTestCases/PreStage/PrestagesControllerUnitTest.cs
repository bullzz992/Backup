﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using Moq;
using Nedbank.CardlessTransactions.API.Application.Controllers;
using Nedbank.CardlessTransactions.API.Application.Controllers.Interfaces;
using Nedbank.CardlessTransactions.API.Common.Constants;
using Nedbank.CardlessTransactions.API.Common.Functional.Enum;
using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.Application.Models;
using Nedbank.CardlessTransactions.Tests.MockData;
using Nedbank.CardlessTransactions.Tests.TestFixtures;
using Shouldly;
using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Nedbank.CardlessTransactions.Tests.TestCases.UnitTestCases.PreStage
{
    public class PrestagesControllerUnitTest : IClassFixture<PrestagesControllerFixture>
    {

        #region Members
        private readonly PrestagesControllerFixture _fixture;
        IEfRepository<API.DataLayer.Entities.Prestage> _repository;
        IPrestagesController _controller;
        Mock<IPrestagesManager> _manager;
        IMapper _mapper;
        private readonly ILogger<PrestagesController> _logger;

        #endregion

        #region Ctor
        public PrestagesControllerUnitTest(PrestagesControllerFixture fixture)
        {
            _fixture = fixture;
            _repository = _fixture._repository;
            _manager = _fixture.PreStageManager;
            _mapper = _fixture.AutoMapper;
            _logger = Mock.Of<ILogger<PrestagesController>>();
            _controller = new PrestagesController(_manager.Object, _logger);
        }
        #endregion
        #region Test Cases

        #region GetPrestage Async
        [Fact]
        public async Task GetPrestagedAsync_GetActiveRequest()
        {
            // Arrange
            _manager.Setup(a => a.GetPrestagedAsync()).Returns(Task.FromResult(_fixture.GetActiveTransaction()));
            // Act
            var responseDto = await _controller.GetPrestagedAsync();
            //Assert
            responseDto.Data.PrestageResponses.ShouldNotBeNull();
            responseDto.Data.PrestageResponses.Length.ShouldBe(1);
            responseDto.Data.IsExistingUser.ShouldBeTrue();
            responseDto.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.OK));
        }

        [Fact]
        public async Task GetPrestagedAsync_NoActiveRequest_NotExistingUser()
        {
            // Arrange
            _manager.Setup(a => a.GetPrestagedAsync()).Returns(Task.FromResult(_fixture.GetActiveTransaction_blank()));
            // Act
            var responseDto = await _controller.GetPrestagedAsync();
            //Assert
            responseDto.Data.PrestageResponses.ShouldBeNull();
            responseDto.Data.IsExistingUser.ShouldBeFalse();
            responseDto.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.OK));
        }

        [Fact]
        public async Task GetPrestagedAsync_NoActiveRequest_ButExistingUser()
        {
            // Arrange
            _manager.Setup(a => a.GetPrestagedAsync()).Returns(Task.FromResult(_fixture.GetActiveTransaction_Existinguser()));
            // Act
            var responseDto = await _controller.GetPrestagedAsync();
            //Assert
            responseDto.Data.ShouldNotBeNull();
            responseDto.Data.IsExistingUser.ShouldBeTrue();
            responseDto.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.OK));
        }


        #endregion

        #region CreateAsync
        [Fact]
        public async Task CreateAsync_Should_Create_A_New_PreStage()
        {
            // Arrange
            CreatePrestageRequestDto createReqDto = new CreatePrestageRequestDto()
            { AccountType = "Saving", CardNumber = "123",CardExpiryDate=2209, Amount = 1000 };

            _manager.Setup(a => a.CreateAsync(createReqDto)).Returns(Task.FromResult(_fixture.CreatePrestageRequest()));
            //Act      
            var responseDto = await _controller.CreateAsync(createReqDto);
            //Assert
            responseDto.Data.PrestageId.Equals(1);
            responseDto.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.Created));
        }

        [Fact]
        public async Task CreateAsync_Should_Forbidden()
        {
            // Arrange
            CreatePrestageRequestDto createReqDto = new CreatePrestageRequestDto()
            { AccountType = "Saving", CardNumber = "123", CardExpiryDate = 2201, Amount = 1000 };

            _manager.Setup(a => a.CreateAsync(createReqDto)).Returns(Task.FromResult(_fixture.CreatePrestageRequest_Returns0()));
            //Act      
            var responseDto = await _controller.CreateAsync(createReqDto);
            //Assert
            responseDto.Data.ShouldBeNull();
            responseDto.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.Forbidden));
        }


        //[Theory]
        //[ClassData(typeof(PrestageNegativeFlowTestData))]
        //public async Task CreateAsync_Should_Throw_Exception(CreatePrestageRequestDto request)
        //{
        //    //Act      
        //    var responseDto = await _controller.CreateAsync(request);

        //    //Assert
        //    responseDto.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.InternalServerError));
        //}
        #endregion

        #region UpdateAsync
        [Fact]
        public async Task UpdateAsync_Should_Update_And_Return_Success()
        {
            // Arrange
            long id = 1;
            UpdatePrestageRequestDto updateReqDto = new UpdatePrestageRequestDto()
            { AccountType = "Saving", CardNumber = "123", CardExpiryDate=2201, Amount = 1000 };

            _manager.Setup(a => a.UpdateAsync(id, updateReqDto)).Returns(Task.FromResult(_fixture.UpdatePrestageRequest()));
            //Act
            var updateresponse = await _controller.UpdateAsync(id, updateReqDto);
            //Assert
            updateresponse.ShouldNotBeNull();
            updateresponse.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.OK));
            updateresponse.Data.ShouldBeNull();
        }

        [Fact]
        public async Task UpdateAsync_Update_Failed()
        {
            // Arrange
            long id = 1;
            UpdatePrestageRequestDto updateReqDto = new UpdatePrestageRequestDto()
            { AccountType = "Saving", CardNumber = "123", CardExpiryDate = 2201, Amount = 1000 };

            _manager.Setup(a => a.UpdateAsync(id, updateReqDto)).Returns(Task.FromResult(_fixture.UpdatePrestageRequest_Failed()));
            //Act
            var updateresponse = await _controller.UpdateAsync(id, updateReqDto);
            //Assert
            updateresponse.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.NotFound));
        }

        #endregion

        #region Delete Async
        [Fact]
        public async Task DeleteAsync_Should_Delete_PreStage_By_Id_And_Return_Success()
        {
            // Arrange
            int id = 1;
            _manager.Setup(a => a.DeleteAsync(id)).Returns(Task.FromResult(_fixture.DeletePrestageRequest()));
            //Act
            var response = await _controller.DeleteAsync(id);
            //Assert
            ValidateSuccessResponse(response.Metadata);
        }

        [Fact]
        public async Task DeleteAsync_Should_Fail()
        {
            // Arrange
            int id = 1;
            _manager.Setup(a => a.DeleteAsync(id)).Returns(Task.FromResult(_fixture.DeletePrestageRequest_Blank()));
            //Act
            var DelResponse = await _controller.DeleteAsync(id);
            //Assert
            DelResponse.Data.ShouldBeNull();
            DelResponse.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.NotFound));
        }


        #endregion

        #region GetStatusAsync
        [Theory]
        [InlineData("1")]
        public async Task GetStatusAsync_Should_Return_Status_By_Id(int preStageId)
        {
            // Arrange
            _manager.Setup(a => a.GetStatusAsync(preStageId)).Returns(Task.FromResult(_fixture.GetStaus(preStageId)));
            //Act
            var responseDto = await _controller.GetStatusAsync(preStageId);
            //Assert
            responseDto.Data.ShouldNotBeNull();
            responseDto.Data.StatusCode.Equals(Statuses.Prestaged);
        }

        [Theory]
        [InlineData("4")]
        public async Task GetStatusAsync_NotFound(int preStageId)
        {
            // Arrange
            _manager.Setup(a => a.GetStatusAsync(preStageId)).Returns(Task.FromResult(_fixture.GetStaus_Notfound(preStageId)));
            //Act
            var responseDto = await _controller.GetStatusAsync(preStageId);
            //Assert
            responseDto.Data.ShouldBeNull();
            responseDto.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.NotFound));
        }
        #endregion

        #region UpdatePrestageStatusAsync

        [Fact]
        public async Task UpdatePrestageStatusAsync_Should_Return_Success()
        {
            // Arrange
            string id = "tran1";
            UpdatePrestageStatusRequestDto updateStatusReqDto = new UpdatePrestageStatusRequestDto()
            { StatusCode = Statuses.Completed.ToString(), StatusDescription = "Request is Completed" };

            _manager.Setup(a => a.UpdatePrestageStatusAsync(id, updateStatusReqDto))
                    .Returns(Task.FromResult(_fixture.UpdatePrestageStatusRequest()));

            //Act
            var updateresponse = await _controller.UpdatePrestageStatusAsync(id, updateStatusReqDto);
            //Assert
            updateresponse.ShouldNotBeNull();
            updateresponse.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.OK));
        }

        [Fact]
        public async Task UpdatePrestageStatusAsync_Should_Return_NotFound()
        {
            // Arrange
            string id = "tran1";
            UpdatePrestageStatusRequestDto updateStatusReqDto = new UpdatePrestageStatusRequestDto()
            { StatusCode = Statuses.Completed.ToString(), StatusDescription = "Request is Completed" };

            _manager.Setup(a => a.UpdatePrestageStatusAsync(id, updateStatusReqDto))
                    .Returns(Task.FromResult(_fixture.UpdatePrestageStatusNotFound()));

            //Act
            var updateresponse = await _controller.UpdatePrestageStatusAsync(id, updateStatusReqDto);
            //Assert
            updateresponse.ShouldNotBeNull();
            updateresponse.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.NotFound));
            updateresponse.Data.ShouldBeNull();
        }
        #endregion

        #region PrestageValidateAsync
        [Theory]
        [InlineData("term1", "trans1", "saving", 1000)]
        public async Task GetPrestageValidateAsync_Should_Validate(string terminalId, string transactionId, string cardNumber, int amount)
        {
            // Arrange
            PrestageValidateRequestDto requestDto = new PrestageValidateRequestDto()
            {
                Amount = amount,
                CardNumber = cardNumber,
                TerminalId = terminalId,
                TransactionId = transactionId
            };
            var responseDto = new PrestageValidateResponseDto()
            {
                IsValid = true,
                PrestageId = 1
            };
            _manager.Setup(a => a.GetPrestageValidateAsync(terminalId, transactionId, cardNumber, amount))
                    .Returns(Task.FromResult(responseDto));
            //Act
            var response = await _controller.GetPrestageValidateAsync(requestDto);
            //Assert
            response.Data.IsValid.ShouldBeTrue();
            response.Data.PrestageId = 1;
            response.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.OK));
        }

        [Theory]
        [InlineData("term1", "tran1", "saving", 1000)]
        public async Task GetPrestageValidateAsync_Should_Return_Not_Found(string terminalId, string transactionId, string cardNumber, int amount)
        {
            // Arrange
            PrestageValidateRequestDto requestDto = new PrestageValidateRequestDto()
            {
                Amount = amount,
                CardNumber = cardNumber,
                TerminalId = terminalId,
                TransactionId = transactionId

            };
            var responseDto = new PrestageValidateResponseDto()
            {
                IsValid = false,
                PrestageId = 0
            };

            _manager.Setup(a => a.GetPrestageValidateAsync(terminalId, transactionId, cardNumber, amount))
                    .Returns(Task.FromResult(responseDto));
            // Act
            var response = await _controller.GetPrestageValidateAsync(requestDto);
            //Assert
            response.Data.ShouldNotBeNull();
            response.Metadata.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.NotFound));
        }

        #endregion

        #endregion

        #region Helper Method
        /// <summary>
        /// Method is used to validate success response checked 
        /// </summary>
        /// <param name="response"></param>
        private static void ValidateSuccessResponse(ResponseMetadata responseMetaData)
        {
            responseMetaData.ResultData[0].ResultCode.ShouldBe((GlobalConstants.ResultCodes.SuccessCode));
            responseMetaData.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.OK));
            responseMetaData.ResultData[0].ResultDescription.ToLowerInvariant().ShouldBe("ok");
        }

        private static void ValidateFailureResponse(ResponseMetadata responseMetaData)
        {
            // Data.Status.ShouldBe(ResponseStatus.Success);
            //responseMetaData.ResultData[0].ResultCode.ShouldBe((GlobalConstants.ErrorCodes.ErrorCodeR10));
            responseMetaData.ResultData[0].HttpReturnCode.ShouldBe(Convert.ToString((int)HttpStatusCode.BadRequest));
            // responseMetaData.ResultData[0].ResultDescription.ToLowerInvariant().ShouldBe("ok");
        }
        #endregion
    }
}
