﻿using Castle.DynamicProxy.Generators;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Nedbank.CardlessTransactions.API.DataLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace Nedbank.CardlessTransactions.Tests.ConnectionFactory
{
    public class ConnectionFactory : IDisposable
    {
        private bool disposedValue = false;
        private readonly IConfigurationRoot _configuration;
        public ConnectionFactory()
        {
            _configuration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
        }
        public CardlessTransactionsContext CreateContext()
        {
            var option = new DbContextOptionsBuilder<CardlessTransactionsContext>()
                                                     .UseSqlServer(_configuration.GetConnectionString("DefaultConnection")).Options;
            var context = new CardlessTransactionsContext(option);
            EnsureDatabaseSetup(context);
            return context;
        }
        private static void EnsureDatabaseSetup(CardlessTransactionsContext context)
        {
            if (context != null)
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
            }
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects)
                }

                // TODO: free unmanaged resources (unmanaged objects) and override finalizer
                // TODO: set large fields to null
                disposedValue = true;
            }
        }

        // // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~ConnectionFactory()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}
