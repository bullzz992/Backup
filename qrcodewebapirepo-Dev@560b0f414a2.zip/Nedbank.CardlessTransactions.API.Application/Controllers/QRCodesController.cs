﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Nedbank.CardlessTransactions.API.Application.Controllers.Interfaces;
using Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.Application.Models;
using static Nedbank.CardlessTransactions.API.Common.Constants.GlobalConstants;

namespace Nedbank.CardlessTransactions.API.Application.Controllers
{
    
    [Route("/atms/cardlesstransactions/v1/withdrawals/qrCodes")]
    [ApiController]
    public class QRCodesController : ControllerBase, IQRCodesController
    {
        private readonly IQRCodesManager _manager;
        private readonly ILogger<QRCodesController> _logger;

        public QRCodesController(IQRCodesManager manager, ILogger<QRCodesController> logger)
        {
            this._manager = manager;
            this._logger = logger;
        }
        /// <summary>
        /// Returns QRCode
        /// </summary>
        /// <param name="terminalId"></param>
        /// <param name="transactionId"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<APIResponse<string>> GetQRCodeAsync(string terminalId, string transactionId)
        {
            _logger.LogInformation("Inside QRCodesController GetQRCodeAsync");
            string qrCode = string.Empty;
            APIResponse<string> response = new APIResponse<string>();
            try
            {
                _logger.LogInformation($"QRCodesController GetQRCodeAsync : TerminalId:{terminalId},transactionId:{transactionId}");
                qrCode = await _manager.GetQRCodeAsync(terminalId, transactionId);
                response.CreateSuccessResponse(qrCode);
            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"Error message:{ex.Message}");
                sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                _logger.LogError($"QRCodesController GetQRCodeAsync: {sb.ToString()}");
                response.CreateErrorResponse(ex.Message, System.Net.HttpStatusCode.InternalServerError);
            }
            _logger.LogInformation("Exit QRCodesController GetQRCodeAsync");
            return response;
        }

        /// <summary>
        /// This API will validate the scanned QR Code
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost()]
        public async Task<APIResponse<PostQRCodesResponse>> PostQRCodeAsync([FromBody] PostQRCodeRequest input)
        {
            _logger.LogInformation("Inside QRCodesController PostQRCodeAsync");
            APIResponse<PostQRCodesResponse> response = new APIResponse<PostQRCodesResponse>();
            if (ModelState.IsValid)
            {
                try
                {
                    PostQRCodesResponse dto = new PostQRCodesResponse();

                    _logger.LogInformation($"QRCodesController PostQRCodeAsync: Calling PostQRCodeAsync, PrestageId:{input.PrestageId}, QRcode:{input.QrCode}");
                    dto = await _manager.PostQRCodeAsync(input);
                    //Calling Hub Notifcation API 
                    _logger.LogInformation($"QRCodesController PostQRCodeAsync: Calling PostSendNotificationAsync, PrestageId:{input.PrestageId}, QRcode:{input.QrCode},Isvalid:{dto.Isvalid}");
                    bool status = await _manager.PostSendNotificationAsync(input, dto.Isvalid);
                    _logger.LogInformation($"QRCodesController PostQRCodeAsync:status:{status}");
                    if ((dto == null || !(dto.Isvalid)) && !(status))
                    {
                        _logger.LogInformation($"QRCodesController PostQRCodeAsync:Error:{ErrorMessages.QR_Not_Found}, PrestageId:{input.PrestageId}");
                        response.CreateErrorResponse($"{ErrorMessages.QR_Not_Found } {input.PrestageId}", HttpStatusCode.NotFound);
                    }
                    else if ((dto != null || dto.Isvalid) && !(status))
                    {
                        _logger.LogInformation($"QRCodesController PostQRCodeAsync:Error:{ErrorMessages.Notification_Not_Sent}, PrestageId:{input.PrestageId}");
                        response.CreateErrorResponse($"{ErrorMessages.Notification_Not_Sent } {input.PrestageId}");
                    }
                    else
                    {
                        _logger.LogInformation($"QRCodesController PostQRCodeAsync:Notification Sent");
                        response.CreateSuccessResponse(dto);
                    }

                }
                catch (Exception ex)
                {
                    var sb = new StringBuilder();
                    sb.AppendLine($"Error message:{ex.Message}");
                    sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                    _logger.LogError($"QRCodesController PostQRCodeAsync: {sb.ToString()}");

                    _logger.LogInformation("QRCodesController PostQRCodeAsync: Send Failure Notification to ATM, Calling PostSendNotificationAsync");
                    await _manager.PostSendNotificationAsync(input, false);
                    response.CreateErrorResponse(ex.Message);
                }
            }
            else
            {
                _logger.LogInformation($"QRCodesController PostQRCodeAsync: Error:{ErrorMessages.Invaid_Arguments},{HttpStatusCode.BadRequest}");
                response.CreateErrorResponse(ErrorMessages.Invaid_Arguments, HttpStatusCode.BadRequest);
            }
            _logger.LogInformation("Exit QRCodesController PostQRCodeAsync");
            return response;

        }
    }
}
