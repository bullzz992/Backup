﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using Nedbank.CardlessTransactions.API.Application.Controllers.Interfaces;
using Nedbank.CardlessTransactions.API.ApplicationCore.Exceptions;
using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.Application.Models;
using Org.BouncyCastle.Security;
using static Nedbank.CardlessTransactions.API.Common.Constants.GlobalConstants;

namespace Nedbank.CardlessTransactions.API.Application.Controllers
{
    /// <summary>
    /// Controller has functionality of Prestage related request
    /// </summary>
    [Route("/atms/cardlesstransactions/v1/withdrawals/prestages")]
    [ApiController]
    public class PrestagesController : ControllerBase, IPrestagesController
    {
        private readonly IPrestagesManager _prestagesManager;
        private readonly ILogger<PrestagesController> _logger;

        public PrestagesController(IPrestagesManager prestagesManager, ILogger<PrestagesController> logger)
        {
            this._prestagesManager = prestagesManager;
            this._logger = logger;
        }

        /// <summary>
        /// Get Presstaged active cardless request of user
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<APIResponse<PrestageResponsesDto>> GetPrestagedAsync()
        {
            _logger.LogInformation("Inside PrestagesController GetPrestagedAsync");
            APIResponse<PrestageResponsesDto> response = new APIResponse<PrestageResponsesDto>();
            try
            {
                var prestageResponseDto = await _prestagesManager.GetPrestagedAsync().ConfigureAwait(false);
                if (prestageResponseDto.PrestageResponses != null && prestageResponseDto.PrestageResponses.Count() > 0
                    && prestageResponseDto.PrestageResponses[0].PrestageId > 0)
                {
                    _logger.LogInformation($"PrestagesController GetPrestagedAsync:Prestage Request found PrestageId:{prestageResponseDto.PrestageResponses[0].PrestageId}");
                    response.CreateCustomResponse(prestageResponseDto, HttpStatusCode.OK.ToString(), HttpStatusCode.OK, ResultCodes.SuccessCode);
                }
                else
                {
                    _logger.LogInformation($"PrestagesController GetPrestagedAsync:Prestage Request Not found IsExistingUser:{prestageResponseDto.IsExistingUser}");
                    response.CreateCustomResponse(prestageResponseDto, ErrorMessages.No_Active_PestageReq_Found, HttpStatusCode.OK, ResultCodes.RecordNotFound);
                }
            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"Error message:{ex.Message}");
                sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                _logger.LogError($"PrestagesController GetPrestagedAsync: {sb.ToString()}");
                response.CreateCustomErrorResponse(ex.Message, HttpStatusCode.InternalServerError, ResultCodes.ErrorCodeR01);
            }
            _logger.LogInformation("Exit PrestagesController GetPrestagedAsync");
            return response;
        }

        /// <summary>
        /// Get the status of the cardless withdrawal request
        /// </summary>
        /// <param name="id">PrestageId</param>
        /// <returns></returns>
        [HttpGet("{id:long:min(1)}/status")]
        public async Task<APIResponse<PrestageStatusResponseDto>> GetStatusAsync(long id)
        {
            _logger.LogInformation($"Inside PrestagesController GetStatusAsync id: {id}");
            APIResponse<PrestageStatusResponseDto> response = new APIResponse<PrestageStatusResponseDto>();
            try
            {
                var prestageStatusResponseDto = await _prestagesManager.GetStatusAsync(id);
                if (prestageStatusResponseDto == null || string.IsNullOrWhiteSpace(prestageStatusResponseDto.StatusCode))
                {
                    _logger.LogInformation($"PrestagesController GetStatusAsync : {ErrorMessages.PrestageReq_NotFound}");
                    response.CreateCustomEmptyResponse(ErrorMessages.PrestageReq_NotFound, HttpStatusCode.NotFound, ResultCodes.RecordNotFound);
                }
                else
                {
                    _logger.LogInformation($"PrestagesController GetStatusAsync :StatusCode: {prestageStatusResponseDto.StatusCode}");
                    response.CreateCustomResponse(prestageStatusResponseDto, HttpStatusCode.OK.ToString(), HttpStatusCode.OK, ResultCodes.SuccessCode);
                }
            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"Error message:{ex.Message}");
                sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                _logger.LogError($"PrestagesController GetStatusAsync: {sb.ToString()}");
                response.CreateCustomErrorResponse(ex.Message, HttpStatusCode.InternalServerError, ResultCodes.ErrorCodeR01);
            }
            _logger.LogInformation($"Exit PrestagesController GetStatusAsync, id: {id}");
            return response;
        }

        /// <summary>
        /// validate the qr code withdrawal request from Postilion 
        /// </summary>
        /// <param name="requestDto"></param>
        /// <returns></returns>
        [HttpGet("validates")]
        public async Task<APIResponse<PrestageValidateResponseDto>> GetPrestageValidateAsync([FromQuery] PrestageValidateRequestDto requestDto)
        {
            _logger.LogInformation("Inside PrestagesController GetPrestageValidateAsync");
            APIResponse<PrestageValidateResponseDto> response = new APIResponse<PrestageValidateResponseDto>();
            try
            {
                var prestageValidateResponseDto = await _prestagesManager.GetPrestageValidateAsync(requestDto.TerminalId.Trim(),
                    requestDto.TransactionId.Trim(), requestDto.CardNumber.ToString(), requestDto.Amount);

                prestageValidateResponseDto.TerminalId = requestDto.TerminalId;
                prestageValidateResponseDto.TransactionId = requestDto.TransactionId;

                _logger.LogInformation($"PrestagesController GetPrestageValidateAsync: PrestageId:{prestageValidateResponseDto.PrestageId}");
                if (prestageValidateResponseDto.PrestageId > 0)
                {
                    response.CreateCustomResponse(prestageValidateResponseDto, HttpStatusCode.OK.ToString(), HttpStatusCode.OK, ResultCodes.SuccessCode);
                }
                else
                {
                    response.CreateCustomResponse(prestageValidateResponseDto, HttpStatusCode.NotFound.ToString(), HttpStatusCode.NotFound, ResultCodes.RecordNotFound);
                }
            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"Error message:{ex.Message}");
                sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                _logger.LogError($"PrestagesController GetPrestageValidateAsync: {sb.ToString()}");

                PrestageValidateResponseDto resDto = new PrestageValidateResponseDto();
                resDto.TerminalId = requestDto.TerminalId.Trim();
                resDto.TransactionId = requestDto.TransactionId.Trim();
                response.CreateCustomResponse(resDto, ex.Message, HttpStatusCode.InternalServerError, ResultCodes.ErrorCodeR01);
            }
            _logger.LogInformation("Exited the PrestagesController GetPrestageValidateAsync");
            return response;
        }

        /// <summary>
        /// create a prestage withdrawal request
        /// </summary>
        /// <param name="value"></param>
        [HttpPost]
        public async Task<APIResponse<CreatePrestageResponseDto>> CreateAsync([FromBody] CreatePrestageRequestDto input)
        {
            _logger.LogInformation("Inside PrestagesController CreateAsync.");
            APIResponse<CreatePrestageResponseDto> response = new APIResponse<CreatePrestageResponseDto>();
            if (ModelState.IsValid)
            {
                try
                {
                    _logger.LogInformation("PrestagesController CreateAsync: validation successfull");
                    var dto = await _prestagesManager.CreateAsync(input);
                    if (dto == null || dto.PrestageId <= 0)
                    {
                        _logger.LogInformation($"PrestagesController CreateAsync: HttpStatusCode.Forbidden:{ErrorMessages.Active_Prestage_Req}");
                        response.CreateCustomErrorResponse(ErrorMessages.Active_Prestage_Req, HttpStatusCode.Forbidden, ResultCodes.ErrorCodeR01);
                    }
                    else
                    {
                        _logger.LogInformation($"PrestagesController CreateAsync: dto.PrestageId:{dto.PrestageId}");
                        response.CreateCustomResponse(dto, HttpStatusCode.Created.ToString(), HttpStatusCode.Created, ResultCodes.SuccessCode);
                    }
                }
                catch (Exception ex)
                {
                    var sb = new StringBuilder();
                    sb.AppendLine($"Error message:{ex.Message}");
                    sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                    _logger.LogError($"PrestagesController CreateAsync: {sb.ToString()}");
                    response.CreateCustomErrorResponse(ex.Message, HttpStatusCode.InternalServerError, ResultCodes.ErrorCodeR01);
                }
            }
            else
            {
                _logger.LogInformation("PrestagesController CreateAsync: validation Failed");
                response.CreateCustomErrorResponse(ErrorMessages.Invaid_Arguments, HttpStatusCode.InternalServerError, ResultCodes.ErrorCodeR01);
            }
            _logger.LogInformation("Exit PrestagesController CreateAsync");
            return response;
        }

        /// <summary>
        /// Update an prestage withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <param name="value"></param>
        [HttpPut("{id:long:min(1)}")]
        public async Task<APIResponse<UpdatePrestageResponseDto>> UpdateAsync(long id, [FromBody] UpdatePrestageRequestDto input)
        {
            _logger.LogInformation("Inside PrestagesController UpdateAsync.");
            APIResponse<UpdatePrestageResponseDto> response = new APIResponse<UpdatePrestageResponseDto>();
            if (ModelState.IsValid)
            {
                try
                {
                    var responseDto = await _prestagesManager.UpdateAsync(id, input).ConfigureAwait(false);
                    if (responseDto.PrestageId > 0)
                    {
                        _logger.LogInformation($"PrestagesController UpdateAsync: responseDto.PrestageId:{responseDto.PrestageId}");
                        response.CreateCustomEmptyResponse(HttpStatusCode.OK.ToString(), HttpStatusCode.OK, ResultCodes.SuccessCode);
                    }
                    else
                    {
                        _logger.LogInformation($"PrestagesController UpdateAsync:{ErrorMessages.PrestageReq_NotFound}");
                        response.CreateCustomErrorResponse(ErrorMessages.PrestageReq_NotFound, HttpStatusCode.NotFound, ResultCodes.RecordNotFound);
                    }

                }
                catch (Exception ex)
                {
                    var sb = new StringBuilder();
                    sb.AppendLine($"Error message:{ex.Message}");
                    sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                    _logger.LogError($"PrestagesController UpdateAsync:{sb.ToString()}");
                    response.CreateCustomErrorResponse(ex.Message, HttpStatusCode.InternalServerError, ResultCodes.ErrorCodeR01);
                }
            }
            else
            {
                _logger.LogInformation($"PrestagesController UpdateAsync: {ErrorMessages.Invaid_Arguments}");
                response.CreateCustomErrorResponse(ErrorMessages.Invaid_Arguments, HttpStatusCode.BadRequest, ResultCodes.ErrorCodeR01);
            }

            _logger.LogInformation("Exit PrestagesController UpdateAsync");
            return response;
        }

        /// <summary>
        /// update the id of the prestage withdrawal request
        /// </summary>
        /// <param name="id">transactionId</param>
        /// <param name="value"></param>
        [HttpPut("transactions/{transactionid}/statuses")]
        public async Task<APIResponse<UpdatePrestageResponseDto>> UpdatePrestageStatusAsync(string transactionid, [FromBody] UpdatePrestageStatusRequestDto input)
        {
            _logger.LogInformation("Inside PrestagesController UpdatePrestageStatusAsync");
            APIResponse<UpdatePrestageResponseDto> response = new APIResponse<UpdatePrestageResponseDto>();
            if (ModelState.IsValid)
            {
                try
                {
                    _logger.LogInformation("PrestagesController UpdatePrestageStatusAsync: calling UpdatePrestageStatusAsync()");
                    var responseDto = await _prestagesManager.UpdatePrestageStatusAsync(transactionid.Trim(), input).ConfigureAwait(false);
                    _logger.LogInformation($"PrestagesController UpdatePrestageStatusAsync: responseDto.PrestageId:{responseDto.PrestageId}");
                    if (responseDto.PrestageId > 0)
                    {
                        response.CreateCustomEmptyResponse(HttpStatusCode.OK.ToString(), HttpStatusCode.OK, ResultCodes.SuccessCode);
                    }
                    else
                    {
                        response.CreateCustomErrorResponse(ErrorMessages.Prestage_Status_NotChanged, HttpStatusCode.NotFound, ResultCodes.RecordNotFound);
                    }
                }
                catch (Exception ex)
                {
                    var sb = new StringBuilder();
                    sb.AppendLine($"Error message:{ex.Message}");
                    sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                    _logger.LogError($"PrestagesController UpdatePrestageStatusAsync:sb.ToString()");
                    response.CreateCustomErrorResponse(ex.Message, HttpStatusCode.InternalServerError, ResultCodes.ErrorCodeR01);
                }
            }
            else
            {
                _logger.LogInformation($"PrestagesController UpdatePrestageStatusAsync:{ErrorMessages.Invaid_Arguments}");
                response.CreateCustomErrorResponse(ErrorMessages.Invaid_Arguments, HttpStatusCode.BadRequest, ResultCodes.ErrorCodeR01);
            }
            _logger.LogInformation("Exit PrestagesController UpdatePrestageStatusAsync");
            return response;
        }

        /// <summary>
        /// Delete an prestage withdrawal requet
        /// </summary>
        /// <param name="id"></param>
        [HttpDelete("{id:long:min(1)}")]
        public async Task<APIResponse<DeletePrestageResponse>> DeleteAsync(long id)
        {
            _logger.LogInformation("Inside PrestagesController DeleteAsync.");
            APIResponse<DeletePrestageResponse> response = new APIResponse<DeletePrestageResponse>();
            try
            {
                var deletePrestageResponse = await _prestagesManager.DeleteAsync(id).ConfigureAwait(false);
                _logger.LogInformation($"PrestagesController DeleteAsync :Deleted PrestageId:{deletePrestageResponse.PrestageId}");
                if (deletePrestageResponse.PrestageId > 0)
                {
                    response.CreateCustomEmptyResponse(HttpStatusCode.OK.ToString(), HttpStatusCode.OK, ResultCodes.SuccessCode);
                }
                else
                {
                    response.CreateCustomErrorResponse(ErrorMessages.PrestageReq_NotFound, HttpStatusCode.NotFound, ResultCodes.RecordNotFound);
                }

            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"Error message:{ex.Message}");
                sb.AppendLine($"Error stack trace:{ex.StackTrace}");
                _logger.LogError($"PrestagesController DeleteAsync:{sb.ToString()}");
                response.CreateCustomErrorResponse(ex.Message, HttpStatusCode.InternalServerError, ResultCodes.ErrorCodeR01);
            }
            _logger.LogInformation("Exit PrestagesController DeleteAsync");
            return response;
        }

    }
}
