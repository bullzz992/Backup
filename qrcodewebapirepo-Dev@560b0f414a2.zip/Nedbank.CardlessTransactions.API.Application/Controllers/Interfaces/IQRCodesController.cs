﻿using Microsoft.AspNetCore.Mvc;
using Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto;
using Nedbank.CardlessTransactions.Application.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Application.Controllers.Interfaces
{
    public interface IQRCodesController
    {
        Task<APIResponse<string>> GetQRCodeAsync(string terminalId, string transactionId);
        Task<APIResponse<PostQRCodesResponse>> PostQRCodeAsync(PostQRCodeRequest input);

    }
}
