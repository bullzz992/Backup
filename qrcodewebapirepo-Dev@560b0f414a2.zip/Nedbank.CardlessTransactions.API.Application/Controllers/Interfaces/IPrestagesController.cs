﻿using Microsoft.AspNetCore.Mvc;
using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using Nedbank.CardlessTransactions.Application.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Application.Controllers.Interfaces
{

    public interface IPrestagesController
    {
        /// <summary>
        /// Get prestaged cardless withdrawal request 
        /// </summary>
        /// <returns></returns>
        Task<APIResponse<PrestageResponsesDto>> GetPrestagedAsync();
        //Task<PrestageResponsesDto> GetPrestagedAsync();


        /// <summary>
        /// Get the status of the cardless withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<APIResponse<PrestageStatusResponseDto>> GetStatusAsync(long id);

        /// <summary>
        /// Validates Cradless transaction request 
        /// </summary>
        /// <param name="requestDto"></param>
        /// <returns></returns>
        Task<APIResponse<PrestageValidateResponseDto>> GetPrestageValidateAsync([FromQuery] PrestageValidateRequestDto requestDto);

        /// <summary>
        /// Create a cardless withdrawal request
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<APIResponse<CreatePrestageResponseDto>> CreateAsync([FromBody] CreatePrestageRequestDto input);

        /// <summary>
        /// Update the cardless withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<APIResponse<UpdatePrestageResponseDto>> UpdateAsync(long id, [FromBody] UpdatePrestageRequestDto input);

        /// <summary>
        /// update the cardless withdrawal request status
        /// </summary>
        /// <param name="id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<APIResponse<UpdatePrestageResponseDto>> UpdatePrestageStatusAsync(string id, [FromBody] UpdatePrestageStatusRequestDto input);

        /// <summary>
        /// Delete the cardless withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<APIResponse<DeletePrestageResponse>> DeleteAsync(long id);

    }
}
