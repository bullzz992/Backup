﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace Nedbank.CardlessTransactions.Application.Filters
{
    public class ResponseWrapperFilter : IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {          
           ResponseHelper.BuildResponse(context);
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {

        }
    }
}
