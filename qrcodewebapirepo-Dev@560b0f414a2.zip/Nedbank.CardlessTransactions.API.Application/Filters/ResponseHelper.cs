﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Nedbank.CardlessTransactions.Application.Models;
using Newtonsoft.Json;
using System;
using System.Reflection;
using System.Text.Json.Serialization;

namespace Nedbank.CardlessTransactions.Application.Filters
{
    public class ResponseHelper
    {
        #region members
        public static string ContentType { get; set; }

        #endregion

        #region Ctor

        public ResponseHelper()
        {
            ContentType = @"application/json";
        }

        #endregion

        public static void BuildResponse(ActionExecutedContext context)
        {
            var respData = (ObjectResult)context.Result != null ? ((ObjectResult)context.Result).Value : null;
            if (respData != null)
            {
                var type = respData.GetType().ToString();
                if (!type.StartsWith("Nedbank.CardlessTransactions.Application.Models.APIResponse"))
                {
                    if (respData.GetType().IsGenericType)
                    {
                        PropertyInfo magicMethod = respData.GetType().GetProperty("Count");

                        if (magicMethod == null)
                        {
                            CreateEmptyResponse(context);
                        }
                        else
                        {
                            int collCount = Convert.ToInt32(magicMethod.GetValue(respData, null));

                            if (collCount > 0)
                            {
                                CreateSuccessResponse(context, respData);
                            }
                            else
                            {
                                CreateEmptyResponse(context);
                            }
                        }
                    }
                    else
                    {
                        CreateSuccessResponse(context, respData);
                    }
                }
            }
            else
            {
                CreateEmptyResponse(context);
            }
        }

        /// <summary>
        /// Func is used to create empty response
        /// </summary>
        /// <param name="context"></param>
        private static void CreateEmptyResponse(ActionExecutedContext context)
        {
            APIResponse<Object> apiResponse = new APIResponse<Object>();
            apiResponse.CreateEmptyResponse();
            context.Result = new ContentResult { Content = JsonConvert.SerializeObject(apiResponse), ContentType = ContentType };
        }

        /// <summary>
        /// Func is used to create success response.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="respData"></param>
        private static void CreateSuccessResponse(ActionExecutedContext context, object respData)
        {
            APIResponse<Object> apiResponse = new APIResponse<Object>();
            apiResponse.CreateSuccessResponse(respData);
            context.Result = new ContentResult { Content = JsonConvert.SerializeObject(apiResponse, new JsonSerializerSettings() { MetadataPropertyHandling = MetadataPropertyHandling.Ignore }), ContentType = ContentType };
        }


    }
}
