﻿using System.Collections.Generic;

namespace Nedbank.CardlessTransactions.Application.Models
{
    public class ResponseMetadata
    {
        public int? Page { get; set; }

        public int? PageSize { get; set; }

        public int? PageLimit { get; set; }

        public List<ResponseResult> ResultData { get; set; }
    }
}
