﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.Api.Exception
{
    public enum ErrorCodeEnum
    {
        None = 0,
        InternalError = 1,
        RecordNotFound = 2
    }
}
