﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Nedbank.CardlessTransactions.API.ApplicationCore.CustomValidations
{
    public class CardExpiryDateMonthValidation : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            var isValid = true;
            if (value != null && value.ToString().Length == 4)
            {
                var expiryDate = Convert.ToString(value);
                var month = Convert.ToInt32(expiryDate.Substring(2));
                if (month > 12 || month == 0)
                {
                    isValid = isValid & false;
                }
            }
            else
            {
                isValid = isValid & false;
            }
            return isValid;
        }
    }
}
