﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Nedbank.CardlessTransactions.API.ApplicationCore.CustomValidations
{
    public class CardExpiryDateValidation : ValidationAttribute
    {
        public override bool IsValid(object value)
        {          
            var isValid = true;
            if (value != null)
            {
                var expiryDate = Convert.ToUInt32(value);
                var currentDateYYMM = Convert.ToUInt32(DateTime.Now.ToString("yyMM"));
                if (expiryDate.ToString().Length != 4)
                {
                    isValid = isValid & false;
                } 
            }
            else
            {
                isValid = isValid & false;
            }
            return isValid;
        }
    }
}
