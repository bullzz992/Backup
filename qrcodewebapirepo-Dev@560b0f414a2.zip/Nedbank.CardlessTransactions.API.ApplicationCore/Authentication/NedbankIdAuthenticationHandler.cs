﻿
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Principal;
using System.Net.Http.Headers;
using Microsoft.Net.Http.Headers;
using System.Diagnostics.CodeAnalysis;

namespace Nedbank.CardlessTransactions.API.ApplicationCore.Authentication
{
    /// <summary>
    /// Authentication handler for Nedbank JWT implementation. Because Authorisation is handled by APIConnect, we don't need to handle signature authentication
    /// </summary>
    /// 
    [ExcludeFromCodeCoverage]
    public class NedbankIdAuthenticationHandler : AuthenticationHandler<NedbankIdAuthenticationOptions>
    {
        private const string AuthorizationScheme = "Bearer";
        public NedbankIdAuthenticationHandler(IOptionsMonitor<NedbankIdAuthenticationOptions> options, ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock) : base(options, logger, encoder, clock)
        {
        }

        protected override Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            if (!Request.Headers.ContainsKey(HeaderNames.Authorization))
            {
                //Authorization header not in request
                Logger.LogDebug("No authorization header", null);
                return Task.FromResult(AuthenticateResult.NoResult());
            }

            if (!AuthenticationHeaderValue.TryParse(Request.Headers[HeaderNames.Authorization], out AuthenticationHeaderValue headerValue))
            {
                //Invalid Authorization header
                Logger.LogDebug("Could not parse authorization header", null);
                return Task.FromResult(AuthenticateResult.NoResult());
            }

            if (!headerValue.Scheme.Equals(AuthorizationScheme, StringComparison.InvariantCultureIgnoreCase))
            {
                //Invalid auth scheme
                Logger.LogDebug("Incorrect auth scheme", null);
                return Task.FromResult(AuthenticateResult.NoResult());
            }

            var jwtTokenHandler = new JwtSecurityTokenHandler();
            if (!jwtTokenHandler.CanReadToken(headerValue.Parameter))
            {
                Logger.LogDebug("Invalid authorisation token", null);
                return Task.FromResult(AuthenticateResult.NoResult());
            }
            var jwtSecurityToken = jwtTokenHandler.ReadToken(headerValue.Parameter) as JwtSecurityToken;
            var claims = jwtSecurityToken.Claims;


            if (!claims.Any())
            {
                Logger.LogDebug("No claims in token", null);
                return Task.FromResult(AuthenticateResult.NoResult());
            }
            var userName = claims.FirstOrDefault(t => t.Type == Options.IdentifyingClaim);
            var audienceName = claims.FirstOrDefault(t => t.Type == Options.IdentifyAudClaim);
            //
            if (userName == null && audienceName == null)
            {
                Logger.LogDebug("No identifying claim in token", null);
                return Task.FromResult(AuthenticateResult.NoResult());
            }
            ClaimsIdentity claimsIdentity;
            AuthenticationTicket ticket;
            if (userName != null)
            {
                claimsIdentity = new ClaimsIdentity(new GenericIdentity(userName.Value), claims, NedbankAuthenticationDefaults.AuthenticationScheme, Options.IdentifyingClaim, null);
                ticket = new AuthenticationTicket(new ClaimsPrincipal(claimsIdentity), NedbankAuthenticationDefaults.AuthenticationScheme);
                Logger.LogDebug("Token authorised", null);
                return Task.FromResult(AuthenticateResult.Success(ticket));
            }
            else
            {
                claimsIdentity = new ClaimsIdentity(new GenericIdentity(audienceName.Value), claims, NedbankAuthenticationDefaults.AuthenticationScheme, Options.IdentifyAudClaim, null);
                ticket = new AuthenticationTicket(new ClaimsPrincipal(claimsIdentity), NedbankAuthenticationDefaults.AuthenticationScheme);
                Logger.LogDebug("Token authorised", null);
                return Task.FromResult(AuthenticateResult.Success(ticket));
            }
            //

            //if (userName == null)
            //{
            //    Logger.LogDebug("No identifying claim in token", null);
            //    return Task.FromResult(AuthenticateResult.NoResult());
            //}

            //var claimsIdentity = new ClaimsIdentity(new GenericIdentity(userName.Value), claims, NedbankAuthenticationDefaults.AuthenticationScheme, Options.IdentifyingClaim, null);
            //var ticket = new AuthenticationTicket(new ClaimsPrincipal(claimsIdentity), NedbankAuthenticationDefaults.AuthenticationScheme);
            //Logger.LogDebug("Token authorised", null);
            //return Task.FromResult(AuthenticateResult.Success(ticket));

        }

        protected override async Task HandleChallengeAsync(AuthenticationProperties properties)
        {
            Response.Headers["WWW-Authenticate"] = AuthorizationScheme;
            await base.HandleChallengeAsync(properties);
        }
    }
}
