﻿using System.Diagnostics.CodeAnalysis;

namespace Nedbank.CardlessTransactions.API.ApplicationCore.Authentication
{
    /// <summary>
    /// Default values for the Nedbank Authentication handler
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class NedbankAuthenticationDefaults
    {
        public const string AuthenticationScheme = "NedbankIdAuthenticationScheme";
    }
}
