﻿using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Authentication;

namespace Nedbank.CardlessTransactions.API.ApplicationCore.Authentication
{
    [ExcludeFromCodeCoverage]
    public static class AuthenticationBuilderExtensions
    {
        public static AuthenticationBuilder AddNedbankId(this AuthenticationBuilder builder, Action<NedbankIdAuthenticationOptions> configureOptions)
        {
            return builder.AddScheme<NedbankIdAuthenticationOptions, NedbankIdAuthenticationHandler>(NedbankAuthenticationDefaults.AuthenticationScheme, NedbankAuthenticationDefaults.AuthenticationScheme, configureOptions);
        }

        public static AuthenticationBuilder AddNedbankId(this AuthenticationBuilder builder)
        {
            return builder.AddScheme<NedbankIdAuthenticationOptions, NedbankIdAuthenticationHandler>(NedbankAuthenticationDefaults.AuthenticationScheme, NedbankAuthenticationDefaults.AuthenticationScheme, _ => { });
        }
    }
}
