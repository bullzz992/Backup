﻿using Microsoft.AspNetCore.Authentication;
using System.Diagnostics.CodeAnalysis;

namespace Nedbank.CardlessTransactions.API.ApplicationCore.Authentication
{
    /// <summary>
    /// Options object for NedbankIdAuthenticationHandler
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class NedbankIdAuthenticationOptions : AuthenticationSchemeOptions
    {
        public string IdentifyingClaim { get; set; } = "sub";
        //public string IdentifyAudClaim { get; set; } = "aud";
        public string IdentifyAudClaim { get; set; } = "sessionid";
    }
}
