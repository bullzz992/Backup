﻿using System;

namespace Nedbank.CardlessTransactions.API.ApplicationCore.Caching
{
    public interface IMemoryCacheManager
    {
        public void Write(string Key, object Value);

        public void Write(string Key, int minutesToExpiration, object Value);

        public T Read<T>(string Key);

        public object TryRead(string Key);

        public T GetCachedValue<T>(string cacheKey, Func<T> getValue);

        public T GetCachedValue<T>(string cacheKey, int minutesToExpiration, Func<T> getValue);

        public static MemoryCacheManager Instance { get; }

        public void InvalidateCache(string key);

    }
}