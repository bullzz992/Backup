﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;


namespace Nedbank.CardlessTransactions.API.ApplicationCore.Caching
{
    public class MemoryCacheManager : IMemoryCacheManager
    {
        
        private static MemoryCache _memoryCache { get; set; }      
        private static string settingMemoryCacheName;
        private static int settingCacheExpirationTimeInMinutes;
        public static IConfiguration Configuration;


        public MemoryCacheManager()
        {
           
            _memoryCache = new MemoryCache(new MemoryCacheOptions
            {
                //SizeLimit = 1024                
            });

            IConfigurationSection configurationSection = Configuration.GetSection("Caching");

            settingMemoryCacheName = configurationSection["MemoryCacheName"].ToString();

            if (settingMemoryCacheName == null)
                throw new Exception("Please enter a name for the cache in app.config, under 'MemoryCacheName'");

            if (!Int32.TryParse(configurationSection["CacheExpirationTimeInMinutes"], out settingCacheExpirationTimeInMinutes))
                throw new Exception("Please enter how many minutes the cache should be kept in app.config, under 'CacheExpirationTimeInMinutes'");

        }
               

        /// <summary>
        /// Writes Key Value Pair to Cache
        /// </summary>
        /// <param name="Key">Key to associate Value with in Cache</param>
        /// <param name="Value">Value to be stored in Cache associated with Key</param>
        public void Write(string Key, object Value)
        {
            try
            {
                _memoryCache.Set(Key, Value, DateTimeOffset.Now.AddMinutes(settingCacheExpirationTimeInMinutes));
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurred while writing to cache", ex.InnerException);
            }
        }

        /// <summary>
        /// Writes Key Value Pair to Cache
        /// </summary>
        /// <param name="Key">Key to associate Value with in Cache</param>
        /// <param name="Value">Value to be stored in Cache associated with Key</param>
        public void Write(string Key, int minutesToExpiration, object Value)
        {
            _memoryCache.Set(Key, Value, DateTimeOffset.Now.AddMinutes(minutesToExpiration));
        }

        /// <summary>
        /// Returns Value stored in Cache
        /// </summary>
        /// <param name="Key"></param>
        /// <returns>Value stored in cache</returns>
        public T Read<T>(string Key)
        {
            return (T)_memoryCache.Get(Key);
        }

        /// <summary>
        /// Returns Value stored in Cache, null if non existent
        /// </summary>
        /// <param name="Key"></param>
        /// <returns>Value stored in cache</returns>
        public object TryRead(string Key)
        {
            try
            {
                return _memoryCache.Get(Key);
            }
            catch (Exception)
            {
                return null;
            }

        }


        /// <summary>
        /// Returns the cached value based on the cache key, add new value in cache if not already present.
        /// </summary>
        /// <typeparam name="T">Any cache object type</typeparam>
        /// <param name="cacheKey">Key of the cached object</param>
        /// <param name="getValue">Func to get new value if no cached value is present</param>
        /// <returns>Cached object</returns>
        public T GetCachedValue<T>(string cacheKey, Func<T> getValue)
        {
            return GetCachedValue<T>(cacheKey, settingCacheExpirationTimeInMinutes, getValue);  //by default 2 minute expiration timing.
        }

        /// <summary>
        /// Returns the cached value based on the cache key, add new value in cache if not already present.
        /// </summary>
        /// <typeparam name="T">Any cache object type</typeparam>
        /// <param name="cacheKey">Key of the cached object</param>
        /// <param name="getValue">Func to get new value if no cached value is present</param>
        /// <returns>Cached object</returns>    Z
        public T GetCachedValue<T>(string cacheKey, int minutesToExpiration, Func<T> getValue)
        {
            T cachedValue = (T)_memoryCache.Get(cacheKey);

            if (cachedValue == null)
            {
                cachedValue = getValue();
                _memoryCache.Set(cacheKey, cachedValue, DateTime.Now.AddMinutes(minutesToExpiration));
            }

            return cachedValue;
        }

        /// <summary>
        /// Removes the cached object
        /// </summary>
        public void InvalidateCache(string key)
        {
            _memoryCache.Remove(key);
        }
    }
}
