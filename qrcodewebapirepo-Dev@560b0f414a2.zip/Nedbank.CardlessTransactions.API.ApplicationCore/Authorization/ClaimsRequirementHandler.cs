﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace Nedbank.CardlessTransactions.API.ApplicationCore.Authorization
{
    public class ClaimsRequirementHandler : AuthorizationHandler<ClaimRequirement>
    {

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context,
                                                       ClaimRequirement requirement)
        {
            if (!context.User.Identity.IsAuthenticated)
                return Task.CompletedTask;

            if (context.User.HasClaim(c => c.Type == requirement.ClaimName &&
                               c.Value.Contains(requirement.ClaimValue)))
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
