﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Resources.Configurations
{
    public class MQEndpoint
    {
        public string HOST { get; set; }

        public string PORT { get; set; }
        public string CHANNEL { get; set; }
        public string QMGR { get; set; }

        public string APP_USER { get; set; }
        public string APP_PASSWORD { get; set; }
        public string QUEUE_NAME { get; set; }
        public string MODEL_QUEUE_NAME { get; set; }
        public string DYNAMIC_QUEUE_PREFIX { get; set; }

        public string TOPIC_NAME { get; set; }

    }
}
