﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Resources.Configurations
{
    public class MQTimeout
    {
        public string TIME_OUT_TIME { get; set; }

        public string POLL_INTERVAL { get; set; }

    }
}
