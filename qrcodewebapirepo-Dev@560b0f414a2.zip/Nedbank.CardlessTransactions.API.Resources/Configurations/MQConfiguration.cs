﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Resources.Configurations
{
    public class MQConfiguration
    {
        public List<MQEndpoint> MQ_ENDPOINTS { get; set; }
    }
}
