﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Resources.NotificationBackOffice
{
    public class BackOfficeNotificationHelperDto
    {
        //public string clientIdentifierType { get; set; }
        public string body { get; set; }
        public string displayCategory { get; set; }
        public string displaySubCategory { get; set; }
        public string heading { get; set; }
        public string notificationType { get; set; }
        public string subHeading { get; set; }
        public string url { get; set; }
    }
}
