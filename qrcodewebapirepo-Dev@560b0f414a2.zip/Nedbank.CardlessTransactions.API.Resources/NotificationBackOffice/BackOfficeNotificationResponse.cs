﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Resources.NotificationBackOffice
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class BackOfficeNotificationResponse
    {
        public Metadata metadata { get; set; }
    }
    public class Metadata
    {
        public List<ResultData> resultData { get; set; }
    }
    public class ResultData
    {
        public string batchID { get; set; }
        public string transactionID { get; set; }
        public string recInstrID { get; set; }
        public string execEngineRef { get; set; }
        public List<ResultDetail> resultDetail { get; set; }
    }

    public class ResultDetail
    {
        public string operationReference { get; set; }
        public string result { get; set; }
        public string status { get; set; }
        public string reason { get; set; }
    }

}
