﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Resources.NotificationBackOffice
{
    public class BackOfficeNotificationRequest
    {
        public Notification notification { get; set; }
        public BackOfficeNotificationRequest()
        {
            this.notification = new Notification();
        }
    }
    public class Notification
    {
        public string backOfficeNotificationId { get; set; }
        public string notificationType { get; set; }
        public ClientIdentity clientIdentity { get; set; }
        public string displayCategory { get; set; }
        public string displaySubCategory { get; set; }
        public string heading { get; set; }
        public string subHeading { get; set; }
        public string body { get; set; }
        public string url { get; set; }
        public DateTime backOfficeNotificationDate { get; set; }
        public DateTime activeExpiryDate { get; set; }
        public DateTime deviceExpiryDate { get; set; }
        public int deliveryPriority { get; set; }
        public int responsePriority { get; set; }
        public bool mustTrackFirstRead { get; set; }
        public bool mustTrackAllReads { get; set; }
        public bool mustTrackDismiss { get; set; }
        public bool allowMultipleResponses { get; set; }
        public bool allowAnonymous { get; set; }
        public bool mustBlockApp { get; set; }
        public bool mustPush { get; set; }
        public bool isDirectFlow { get; set; }
        public bool mustNotShowInInbox { get; set; }
        public List<ResponseOption> responseOptions { get; set; }
        public List<Channel> channels { get; set; }
        public List<RichContent> richContent { get; set; }
        public List<Meta> meta { get; set; }
        public Notification()
        {
            clientIdentity = new ClientIdentity();
            responseOptions = new List<ResponseOption>();
            channels = new List<Channel>();
            richContent = new List<RichContent>();
            meta = new List<Meta>();
        }
    }
    public class ClientIdentity
    {
        public string clientIdentifier { get; set; }
        public string clientIdentifierType { get; set; }
    }

    public class ResponseOption
    {
        public string type { get; set; }
        public string label { get; set; }
        public string value { get; set; }
        public string action { get; set; }
        public List<AdditionalParameter> additionalParameters { get; set; }
        public ResponseOption()
        {
            additionalParameters = new List<AdditionalParameter>();
        }
    }
    public class AdditionalParameter
    {
        public string name { get; set; }
        public string value { get; set; }
    }

    public class Channel
    {
        public int channel { get; set; }
    }

    public class RichContent
    {
        public string token { get; set; }
        public string displayName { get; set; }
        public string contentType { get; set; }
        public string displayType { get; set; }
        public string sourceCms { get; set; }
        public string sourcePath { get; set; }
    }

    public class Meta
    {
        public string name { get; set; }
        public string value { get; set; }
    }

    

}
