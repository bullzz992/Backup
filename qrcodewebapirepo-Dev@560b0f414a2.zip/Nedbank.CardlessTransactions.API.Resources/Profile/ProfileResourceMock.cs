﻿using Nedbank.EAPI.RestApiModels.Skynet100;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.EAPI.Skynet.Resources.Profile
{
    public class ProfileResourceMock : IProfileResource
    {
        public Task<List<Account>> GetAccounts(long profileNumber)
        {
            throw new NotImplementedException();
        }
    }
}
