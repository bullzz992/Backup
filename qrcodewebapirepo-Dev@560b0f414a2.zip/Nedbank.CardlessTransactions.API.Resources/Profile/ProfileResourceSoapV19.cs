﻿using Nedbank.EAPI.RestApiModels.Skynet100;
using Nedbank.EAPI.SDK.Configuration;
using Nedbank.EAPI.SDK.Security.Cryptography;
using Nedbank.EAPI.SDK.ServiceModel.Headers;
using Nedbank.EAPI.SoapServiceProxies.ProfileV19;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.EAPI.Skynet.Resources.Profile
{
    public class ProfileResourceSoapV19 : IProfileResource
    {

        private readonly IEnterpriseContextResource _enterpriseContextResource;
        private readonly IX509CertificateResource _x509CertificateResource;
        private readonly IEndpointResolver _endpointResolver;

        public ProfileResourceSoapV19(IEnterpriseContextResource enterpriseContextResource, IX509CertificateResource x509CertificateResource, IEndpointResolver endpointResolver)
        {
            _enterpriseContextResource = enterpriseContextResource;
            _x509CertificateResource = x509CertificateResource;
            _endpointResolver = endpointResolver;
        }
        public async Task<List<Account>> GetAccounts(long profileNumber)
        {
            try
            {
                var accounts = new List<Account>();
                var serviceManager = _endpointResolver.GetServiceClientManager("Retail.Profile.v19");

                using (var client = new ProfileClient(serviceManager.GetBinding(), serviceManager.GetRemoteAddress()))
                {
                    serviceManager.ManageClient(client);

                    var serviceRequest = new ProfileGetInfoRequest()
                    {
                        EnterpriseContext = _enterpriseContextResource.GetEnterpriseContext2008(),
                        ProfileNr = profileNumber
                    };

                    Task<ProfileGetInfoResponse> profileGetInfoTask = serviceManager.SetupRequest(client, () =>
                    {
                        return client.ProfileGetInfoAsync(serviceRequest);
                    });

                    try
                    {
                        var profileGetInfoResponse = await profileGetInfoTask;

                        foreach (var accoutnItem in profileGetInfoResponse.ProfileInfo.AccountInfoResponseList.AccountInfo)
                        {
                            accounts.Add(new Account()
                            {
                                AccountName = accoutnItem.AccountName,
                                AccountNumber = accoutnItem.AccountNr,
                                AccountType = accoutnItem.AccountType.ToString(),
                                AvailableBalance = accoutnItem.AvailableBalance,
                                CurrentBalance = accoutnItem.CurrentBalance,
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                        client.Abort();
                        throw;
                    }
                    finally
                    {
                        await client.CloseAsync();
                    }
                }
                return accounts;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
