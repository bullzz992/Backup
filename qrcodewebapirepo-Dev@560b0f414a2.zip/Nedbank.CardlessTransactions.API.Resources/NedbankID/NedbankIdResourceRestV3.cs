﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Nedbank.EAPI.RestApiModels.NedbankId3;
using Nedbank.EAPI.RestApiModels.SdkModels.Configuration;
using Nedbank.EAPI.RestApiModels.SdkModels.Configuration.Endpoints;
using Nedbank.EAPI.SDK.Configuration;
using Nedbank.EAPI.SDK.Net;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.EAPI.Skynet.Resources.NedbankID
{
    public class NedbankIdResourceRestV3 : INedbankIdResource
    {
        private readonly ApplicationSettings _appSettings;
        private readonly IConfiguration _configuration;
        private readonly IRestClient _restClient;
        private readonly Endpoints _endpoints;

        public NedbankIdResourceRestV3(IOptions<ApplicationSettings> appSettings, IConfiguration configuration, IRestClient restClient)
        {
            _appSettings = appSettings.Value;
            _configuration = configuration;
            _restClient = restClient;
            _appSettings = _configuration.GetSection("AppplicationSettings").Get<ApplicationSettings>();
            _endpoints = _configuration.GetSection("Endpoints").Get<Endpoints>();
        }

        public Task<ContextSwitchResponse> ContextSwitchDefaultProfile(string authenticatedToken)
        {
            var contextSwitchUrl = ConfigurationUtility.GetEndpoint("Nid.ContextSwitch.v3", _endpoints);

            var contextSwitchResult = _restClient.Put<RestApiModels.NedbankId3.ContextSwitchResponse, ContextSwitchRequest>(
                new Uri(contextSwitchUrl.Uri),
                new List<RestParameter>()
                {
                    new RestParameter()
                    {
                        Name = "Authorization",
                        Type = ParameterType.Header,
                        Value = $"Bearer {authenticatedToken}"
                    }
                },
                false,
                new ContextSwitchRequest()
                {
                    profileNumber = string.Empty,
                    profileType = string.Empty
                });
            return contextSwitchResult;
        }

        public Task<AuthenticationResponse> NidAuthenticate(string salutToken, string username, string password)
        {
            var authenticationUrl = ConfigurationUtility.GetEndpoint("Nid.Authenticate.v3", _endpoints);

            var authenticationResult = _restClient.Post<RestApiModels.NedbankId3.AuthenticationResponse, AuthenticationRequest>(
                new Uri(authenticationUrl.Uri),
                new List<RestParameter>()
                {
                    new RestParameter()
                    {
                        Name = "Authorization",
                        Type = ParameterType.Header,
                        Value = $"Bearer {salutToken}"
                    }
                },
                false,
                new AuthenticationRequest()
                {
                    username = username,
                    password = password,
                    appliesTo = "https://newmoneyweb/pilot",
                    secretType = "PWD"
                });
            return authenticationResult;
        }

        public Task<SalutResponse> Salut()
        {
            var longJwt = _appSettings.ApiSettings["LongLifeJwtToken"];
            var salutUrl = ConfigurationUtility.GetEndpoint("Nid.Salut.v3", _endpoints);
            var salutResult = _restClient.Get<SalutResponse>(
                new Uri(salutUrl.Uri),
                new List<RestParameter>()
                {
                    new RestParameter()
                    {
                        Name = "Authorization",
                        Type = ParameterType.Header,
                        Value = $"Bearer {longJwt}"
                    }
                },
                false);
            return salutResult;
        }
    }
}
