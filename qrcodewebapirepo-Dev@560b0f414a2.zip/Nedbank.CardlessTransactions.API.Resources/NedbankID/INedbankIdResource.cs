﻿using Nedbank.EAPI.RestApiModels.NedbankId3;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.EAPI.Skynet.Resources.NedbankID
{
    public interface INedbankIdResource
    {
        Task<SalutResponse> Salut();
        Task<AuthenticationResponse> NidAuthenticate(string salutToken, string username, string password);
        Task<ContextSwitchResponse> ContextSwitchDefaultProfile(string authenticatedToken);
    }
}
