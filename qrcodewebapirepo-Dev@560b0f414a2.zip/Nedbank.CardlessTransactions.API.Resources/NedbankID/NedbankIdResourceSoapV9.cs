﻿using Nedbank.EAPI.RestApiModels.NedbankId3;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.EAPI.Skynet.Resources.NedbankID
{
    public class NedbankIdResourceSoapV9 : INedbankIdResource
    {
        public Task<ContextSwitchResponse> ContextSwitchDefaultProfile(string authenticatedToken)
        {
            throw new NotImplementedException();
        }

        public Task<AuthenticationResponse> NidAuthenticate(string salutToken, string username, string password)
        {
            throw new NotImplementedException();
        }

        public Task<SalutResponse> Salut()
        {
            throw new NotImplementedException();
        }
    }
}
