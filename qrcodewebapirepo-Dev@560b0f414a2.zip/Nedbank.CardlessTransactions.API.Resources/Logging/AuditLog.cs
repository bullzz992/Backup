﻿namespace Nedbank.CardlessTransactions.API.Resources.Logging
{
    public class AuditLog
    {
    }
}
