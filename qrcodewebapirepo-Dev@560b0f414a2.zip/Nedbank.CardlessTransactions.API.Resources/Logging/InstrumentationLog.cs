﻿namespace Nedbank.CardlessTransactions.API.Resources.Logging
{
    public class InstrumentationLog
    {
        
    }
}
