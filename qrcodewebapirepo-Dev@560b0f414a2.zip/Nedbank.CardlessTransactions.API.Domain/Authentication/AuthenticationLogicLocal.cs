﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Nedbank.EAPI.RestApiModels.SdkModels.Configuration;
using Nedbank.EAPI.RestApiModels.Skynet100;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Domain.Authentication
{
    public class AuthenticationLogicLocal : IAuthenticationLogic
    {
        private readonly ApplicationSettings _appSettings;

        public AuthenticationLogicLocal(IOptions<ApplicationSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }

        public Task<Token> AuthenticateUser(LoginItem loginRequest)
        {
            var role = "NormalUser";
            if ("terminator" == loginRequest.Username)
            {
                role = "Admin";
            }
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.ApiSettings["JwtSigningSecret"]);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, loginRequest.Username),
                    new Claim(ClaimTypes.Role, role)
                }),
                Expires = DateTime.Now.AddDays(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);

            var tokenResult = new Token()
            {
                TokenType = "JWT",
                TokenValue = tokenHandler.WriteToken(token)
            };
            return Task.FromResult(tokenResult);
        }
    }
}
