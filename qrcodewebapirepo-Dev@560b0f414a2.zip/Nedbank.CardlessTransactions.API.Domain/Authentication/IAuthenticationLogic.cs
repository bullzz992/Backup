﻿using Nedbank.EAPI.RestApiModels.Skynet100;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Domain.Authentication
{
    public interface IAuthenticationLogic
    {
        Task<Token> AuthenticateUser(LoginItem loginRequest);
    }
}
