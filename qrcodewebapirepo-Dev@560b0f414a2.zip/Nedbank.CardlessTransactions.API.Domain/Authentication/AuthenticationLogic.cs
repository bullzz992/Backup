﻿using Nedbank.EAPI.RestApiModels.Skynet100;
using Nedbank.EAPI.Skynet.Resources.NedbankID;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Domain.Authentication
{
    public class AuthenticationLogic: IAuthenticationLogic
    {
        private readonly INedbankIdResource _nedbankIdResource;

        public AuthenticationLogic(INedbankIdResource nedbankIdService)
        {
            this._nedbankIdResource = nedbankIdService;
        }

        public async Task<Token> AuthenticateUser(LoginItem loginRequest)
        {
            //get tracked token using the default long life jwt
            var salutResult = await _nedbankIdResource.Salut();

            //authenticate the login
            var authenticateResult = await _nedbankIdResource.NidAuthenticate(salutResult?.Data?.TokenValue, loginRequest.Username, loginRequest.Password);

            //context switch to primary profile
            var contextSwitchResult = await _nedbankIdResource.ContextSwitchDefaultProfile(authenticateResult?.Data?.TokenValue);

            return new Token()
            {
                TokenType = "JWT",
                TokenValue = contextSwitchResult?.Data?.Token
            };
        }
    }
}
