﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto
{
    public class QrCodesTransactionStatusResponse : BaseDto
    {
        public string StatusCode { get; set; }
        public string StatusDescription { get; set; }
    }
}
