﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto
{
    public class QRCodeResponse:BaseDto
    {
        public string QRCode { get; set; }
    }
}
