﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto
{
    public class PostQRCodeRequest : BaseDto
    {
        [Required]
        public int PrestageId { get; set; }
        [Required]
        public string QrCode { get; set; }
    }
}
