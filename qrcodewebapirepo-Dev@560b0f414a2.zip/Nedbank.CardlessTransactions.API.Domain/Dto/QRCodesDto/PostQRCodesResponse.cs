﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto
{
    public class PostQRCodesResponse : BaseDto
    {
        public string TransactionId { get; set; }
        public string TerminalId { get; set; }
        public bool Isvalid { get; set; }
    }
}
