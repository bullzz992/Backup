﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class UpdatePrestageStatusRequestDto : BaseDto
    {
        [Required]
        public string StatusCode { get; set; }

        [Required]
        public string StatusDescription { get; set; }
    }
}
