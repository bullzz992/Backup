﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class PrestageStatusResponseDto:BaseDto
    {
        public string StatusCode { get; set; }
        public string StatusDescription { get; set; }
    }
}
