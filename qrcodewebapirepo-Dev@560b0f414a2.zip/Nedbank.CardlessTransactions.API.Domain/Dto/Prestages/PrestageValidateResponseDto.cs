﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class PrestageValidateResponseDto : BaseDto
    {
        public long PrestageId { get; set; }
        public string TransactionId { get; set; }
        public string TerminalId { get; set; }
        public bool IsValid { get; set; }

        public PrestageValidateResponseDto()
        {
           
        }

    }
}
