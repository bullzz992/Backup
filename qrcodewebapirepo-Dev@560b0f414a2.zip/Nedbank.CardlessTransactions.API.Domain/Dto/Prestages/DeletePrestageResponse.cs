﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class DeletePrestageResponse
    {
        public long PrestageId;

        public DeletePrestageResponse()
        {

        }
    }
}
