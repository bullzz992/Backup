﻿using Nedbank.CardlessTransactions.API.ApplicationCore.CustomValidations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class CreatePrestageRequestDto:BaseDto
    {
        [Required]
        [MaxLength(20)]
        public string CardNumber { get; set; }

        [Required]
        [CardExpiryDateValidation(ErrorMessage = "Please enter CardExpiryDate in YYMM format")]
        [CardExpiryDateMonthValidation(ErrorMessage = "Please enter valid Month for CardExpiryDate in YYMM format")]
        public int CardExpiryDate { get; set; }

        [Required]
        public string AccountType { get; set; }

        [Required]
        [RegularExpression(@"^[0-9]*$", ErrorMessage = "Amount should be in proper format a numeric value")]
        [Range(100, 5000, ErrorMessage = "{0} must be between {1} and {2}.")]
        public int Amount { get; set; }
    
    }
}
