﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class PrestageResponses
    {
        public long PrestageId { get; set; }
        public string CardNumber { get; set; }
        public int CardExpiryDate { get; set; }
        public string AccountType { get; set; }
        public int Amount { get; set; }
        public string Status { get; set; }
        public DateTime validUpto { get; set; }
    }
}
