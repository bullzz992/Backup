﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class UpdatePrestageResponseDto
    {
        public long PrestageId { get; set; }
        public UpdatePrestageResponseDto()
        {

        }
        
    }
}
