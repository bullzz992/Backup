﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class PrestageResponseCheckIsExistingUserDto : BaseDto
    {
        public bool IsExistingUser { get; set; }
    }
}