﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class PrestageValidateRequestDto : BaseDto
    {
        [Required]
        [MaxLength(10)]
        public string TerminalId { get; set; }

        [Required]
        [MaxLength(15)]
        public string TransactionId { get; set; }

        [Required]
        [MaxLength(20)]
        public string CardNumber { get; set; }
        [Required]
        [RegularExpression(@"^[0-9]*$", ErrorMessage = "Amount should be in proper format a numeric value")]
        [Range(100, 5000, ErrorMessage = "{0} must be between {1} and {2}.")]
        public int Amount { get; set; }
    }
}
