﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class PrestageResponsesDto
    {
        public PrestageResponses[] PrestageResponses { get; set; }

        public bool IsExistingUser { get; set; }
    }
}
