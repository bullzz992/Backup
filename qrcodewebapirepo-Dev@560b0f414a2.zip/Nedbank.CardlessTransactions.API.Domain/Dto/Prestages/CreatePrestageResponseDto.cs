﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Prestages
{
    public class CreatePrestageResponseDto:BaseDto
    {
        public CreatePrestageResponseDto()
        {
            
        }
        public long PrestageId { get; set; }
    }
}
