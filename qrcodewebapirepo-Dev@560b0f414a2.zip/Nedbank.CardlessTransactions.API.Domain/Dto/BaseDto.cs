﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto
{
    public class BaseDto
    {
    }
}
