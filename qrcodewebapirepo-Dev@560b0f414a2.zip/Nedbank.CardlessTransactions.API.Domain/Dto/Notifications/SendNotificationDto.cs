﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Dto.Notifications
{
    public class SendNotificationDto : BaseDto
    {
        public string TransactionId { get; set; }
        public string TerminalId { get; set; }
        public long PrestageId { get; set; }
        public long Amount { get; set; }
        public string AccountType { get; set; }
        public string CardNumber { get; set; }
        public int CardExpirydate { get; set; }
        public bool IsValid { get; set; }
    }
}
