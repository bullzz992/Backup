﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Configuration
{
    public class QRCodeConfigurationSetting
    {
        public string NotificationHubBaseUrl { get; set; }
        public double QRCodeExpiry { get; set; }
        public int QRCodeGraphic { get; set; }

    }
}
