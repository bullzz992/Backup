﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Configuration
{
    public class BackOfficeNotificationConfiguration
    {
        public string clientId { get; set; }
        public string clientSecretKey { get; set; }
        public string backOfficeId { get; set; }
        public string backOfficeName { get; set; }
        public string backOfficeToken { get; set; }
        public string backOfficeApiUrl { get; set; }
    }
}
