﻿using AutoMapper;
using Nedbank.CardlessTransactions.API.Domain.Dto;
using Nedbank.CardlessTransactions.API.DataLayer;
using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using Microsoft.AspNetCore.Routing.Constraints;

namespace Nedbank.CardlessTransactions.API.Domain.MappingProfile
{
    /// <summary>
    /// This class will be used to dynamically add mappings. 
    /// </summary>
    public class MappingProfile : Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public MappingProfile()
        {
            //Begin Maintenance mappings
            CreateMap<Prestage, PrestageResponseDto>()
               .ForMember(dest => dest.PrestageId,opt => opt.MapFrom(src => src.Id))
               .ForMember(dest=>dest.Status, opt=> opt.MapFrom(src=>src.PrestageStatus))
               ;
        


        }
    }
}
