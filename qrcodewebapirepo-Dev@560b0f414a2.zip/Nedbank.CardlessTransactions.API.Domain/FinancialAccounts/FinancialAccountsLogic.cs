﻿using Nedbank.EAPI.RestApiModels.Skynet100;
using Nedbank.CardlessTransactions.API.Domain.FinancialAccounts.Models;
using Nedbank.EAPI.Skynet.Resources.Profile;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Domain.FinancialAccounts
{
    public class FinancialAccountsLogic : IFinancialAccountsLogic
    {
        private readonly IProfileResource _profileResource;

        public FinancialAccountsLogic(IProfileResource profileResource)
        {
            this._profileResource = profileResource;
        }

        public async Task<AccountsListResponse> GetAccounts(FinancialAccountRequest request)
        {
            var response = new AccountsListResponse() { Data = new AccountList() };
            var accounts  = await _profileResource.GetAccounts(request.ProfileNumber);

            response.Data.AddRange(accounts);
            return response;
        }
    }
}
