﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.FinancialAccounts.Models
{
    public class FinancialAccountRequest
    {
        public long ProfileNumber { get; set; }
        public string EnterpriseCustomerNumber { get; set; }

    }
}
