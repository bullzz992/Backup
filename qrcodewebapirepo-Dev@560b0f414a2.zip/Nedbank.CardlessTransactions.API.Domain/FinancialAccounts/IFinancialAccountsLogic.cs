﻿using Nedbank.EAPI.RestApiModels.Skynet100;
using Nedbank.CardlessTransactions.API.Domain.FinancialAccounts.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Domain.FinancialAccounts
{
    public interface IFinancialAccountsLogic
    {
        Task<AccountsListResponse> GetAccounts(FinancialAccountRequest request);
    }
}
