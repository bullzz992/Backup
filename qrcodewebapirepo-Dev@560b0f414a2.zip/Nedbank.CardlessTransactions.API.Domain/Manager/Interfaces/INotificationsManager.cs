﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces
{
    public interface INotificationsManager
    {
    }
}
