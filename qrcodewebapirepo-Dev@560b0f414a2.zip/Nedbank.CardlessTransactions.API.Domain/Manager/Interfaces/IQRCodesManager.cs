﻿using Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces
{
    public interface IQRCodesManager
    {
        Task<string> GetQRCodeAsync(string terminalId, string transactionId);
        
        Task<PostQRCodesResponse> PostQRCodeAsync(PostQRCodeRequest input);
        Task<bool> PostSendNotificationAsync(PostQRCodeRequest input, bool isValid);
    }
}
