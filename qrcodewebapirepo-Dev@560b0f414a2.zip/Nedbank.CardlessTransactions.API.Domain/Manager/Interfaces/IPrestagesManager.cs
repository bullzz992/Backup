﻿using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces
{
    public interface IPrestagesManager
    {
        /// <summary>
        /// Gets prestages cardless withdrawal request for the user
        /// </summary>
        /// <returns></returns>
        Task<PrestageResponsesDto> GetPrestagedAsync();
        
        /// <summary>
        /// Gets the status of the Cardless withdrawal request
        /// </summary>
        /// <param name="id">PrestageId</param>
        /// <returns></returns>
        Task<PrestageStatusResponseDto> GetStatusAsync(long id);
        
        /// <summary>
        /// Validates the cardless withdrawal request
        /// </summary>
        /// <param name="terminalId"></param>
        /// <param name="transactionId"></param>
        /// <param name="account"></param>
        /// <param name="amount"></param>
        /// <returns></returns>
        Task<PrestageValidateResponseDto> GetPrestageValidateAsync(string terminalId, string transactionId, string account, int amount);
       
        /// <summary>
        /// Makes a new cardless withdrawal request
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<CreatePrestageResponseDto> CreateAsync(CreatePrestageRequestDto input);
       
        /// <summary>
        /// Updates the prestaged cardless withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<UpdatePrestageResponseDto> UpdateAsync(long id, UpdatePrestageRequestDto input);

        /// <summary>
        /// Update the status of the prestaged cardless withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<UpdatePrestageResponseDto> UpdatePrestageStatusAsync(string id, UpdatePrestageStatusRequestDto input);
       
        /// <summary>
        /// Delete the prestaged cardless withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<DeletePrestageResponse> DeleteAsync(long id);

        /// <summary>
        /// Check whether user is firsttime user or recurring user
        /// </summary>
        /// <returns></returns>
        Task<PrestageResponseCheckIsExistingUserDto> CheckIsExistingUserAsync();
       
    }
}
