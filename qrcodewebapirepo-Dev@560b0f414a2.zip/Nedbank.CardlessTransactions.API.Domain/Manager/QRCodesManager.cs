﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Net.Http.Headers;
using Nedbank.CardlessTransactions.API.Common.Functional.Enum;
using Nedbank.CardlessTransactions.API.Common.Helper;
using Nedbank.CardlessTransactions.API.DataLayer;
using Nedbank.CardlessTransactions.API.DataLayer.EntityFrameworkCore.UnitOfWork;
using Nedbank.CardlessTransactions.API.DataLayer.Specifications;
using Nedbank.CardlessTransactions.API.Domain.Configuration;
using Nedbank.CardlessTransactions.API.Domain.Dto.Notifications;
using Nedbank.CardlessTransactions.API.Domain.Dto.QRCodesDto;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.API.Resources.NotificationBackOffice;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;
using static Nedbank.CardlessTransactions.API.Common.Constants.GlobalConstants;

namespace Nedbank.CardlessTransactions.API.Domain.Manager
{
    public class QRCodesManager : IQRCodesManager
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly CardlessTransactionsContext _context;
        private readonly IMapper _mapper;
        private readonly ICommonHelper _helper;
        private readonly ILogger<QRCodesManager> _logger;
        private readonly IOptions<QRCodeConfigurationSetting> _qRCodeSetting;

        public QRCodesManager(IUnitOfWork unitOfWork,
                              IHttpContextAccessor httpContextAccessor,
                              CardlessTransactionsContext context,
                              IMapper mapper,
                              ICommonHelper commonHelper,
                              ILogger<QRCodesManager> logger,
                              IOptions<QRCodeConfigurationSetting> qRCodeSetting)
        {
            _unitOfWork = unitOfWork;
            _httpContextAccessor = httpContextAccessor;
            this._context = context;
            _mapper = mapper;
            this._helper = commonHelper;
            this._logger = logger;
            this._qRCodeSetting = qRCodeSetting;
        }
        public async Task<string> GetQRCodeAsync(string terminalId, string transactionId)
        {
            _logger.LogInformation($"Inside QRCodesManager GetQRCodeAsync, TerminalId:{terminalId},TransactionId:{transactionId}");
            if (string.IsNullOrEmpty(terminalId) || string.IsNullOrEmpty(transactionId))
            {
                throw new Exception(ErrorMessages.Bad_Request);
            }
            //Creating the QR Code
            string qrCode = string.Empty;
            DataLayer.Entities.QRCode qRCodeResponse = new DataLayer.Entities.QRCode();
            try
            {
                string sessionjWtToken;
                string sessionId = GetSessionTokenDetail(out sessionjWtToken);
                _logger.LogInformation($"QRCodesManager GetQRCodeAsync: SessionId:{sessionId}");
                var qrCodeRepository = _unitOfWork.GetRepositoryAsync<DataLayer.Entities.QRCode>();
                Bitmap bitMap = QrCodeGeneration(terminalId, transactionId, sessionId);
                qrCode = (Convert.ToBase64String(BitMapToBytes(bitMap)));
                if (string.IsNullOrEmpty(qrCode))
                {
                    _logger.LogError($"QRCodesManager GetQRCodeAsync: Error:{ErrorMessages.QR_Code_Not_Created}");
                    throw new Exception(ErrorMessages.QR_Code_Not_Created);
                }
                var qrCodeData = new DataLayer.Entities.QRCode()
                {
                    TerminalId = terminalId,
                    TransactionId = transactionId,
                    SessionId = sessionId,
                    Token = sessionjWtToken,
                    DateCreated = DateTime.Now,
                    QrCode = $"{terminalId}:{transactionId}:{sessionId}",
                    ValidUpto = DateTime.Now.AddSeconds(_qRCodeSetting.Value.QRCodeExpiry),
                };
                qRCodeResponse = await qrCodeRepository.AddAsync(qrCodeData).ConfigureAwait(false);
                await _unitOfWork.CommitAsync().ConfigureAwait(false);
                _logger.LogInformation($"QRCodesManager GetQRCodeAsync:QR Code created, Id: {qRCodeResponse.Id}, QRCode:{qRCodeResponse.QrCode}");

            }
            catch (Exception ex)
            {
                throw ex;
            }
            _logger.LogInformation("Exit QRCodesManager GetQRCodeAsync");
            return qrCode;
        }

        public async Task<PostQRCodesResponse> PostQRCodeAsync(PostQRCodeRequest input)
        {
            _logger.LogInformation("Inside QRCodesManager PostQRCodeAsync");
            PostQRCodesResponse response = new PostQRCodesResponse();
            string terminalId, transactionId, sessionId;
            if (!string.IsNullOrEmpty(input.QrCode) && (input.QrCode.Split(":").Length > 2))
            {
                string[] qrCodeInput = input.QrCode.Split(":");
                terminalId = qrCodeInput[0];
                transactionId = qrCodeInput[1];
                sessionId = qrCodeInput[2];
                _logger.LogInformation($"QRCodesManager PostQRCodeAsync: TerminalId:{terminalId}, TransactionId:{transactionId}," +
                    $"SessionId:{sessionId}, PrestageId:{input.PrestageId}");
            }
            else
                return response;
            try
            {
                // Getting QR and validation 
                var qrCodeSpecification = new QRCodeValidateFilterSpecification(terminalId: terminalId,
                                                                                transactionId: transactionId,
                                                                                 sessionId: sessionId);
                var qRrepository = _unitOfWork.GetRepositoryAsync<DataLayer.Entities.QRCode>();
                var qRCodeData = await qRrepository.FindSingleByAsync(qrCodeSpecification).ConfigureAwait(false);
                if (qRCodeData == null)
                {
                    _logger.LogInformation("QRCodesManager PostQRCodeAsync: qRCodeData is null.");
                    return response;
                }
                // PreStage data based on preStageId
                // string profileNumber = GetProfileNumber();
                string authJwtToken;
                string profileNumber = UserAuthDetail(out authJwtToken);
                var preStageRepository = _unitOfWork.GetRepositoryAsync<DataLayer.Entities.Prestage>();
                var preStageSpecification = new PrestageUpdateFilterSpecification(Id: input.PrestageId,
                                                                                  PrestageStatus: Statuses.Prestaged.ToString(),
                                                                                  ProfileNumber: profileNumber);
                _logger.LogInformation($"QRCodesManager PostQRCodeAsync:preStageSpecification PrestageId:{input.PrestageId}, PrestageStatus:{Statuses.Prestaged}," +
                   $"ProfileNumber:{profileNumber}");

                var preStageData = await preStageRepository.FindSingleByAsync(preStageSpecification).ConfigureAwait(false);
                if (preStageData == null)
                {
                    _logger.LogInformation("QRCodesManager PostQRCodeAsync: preStageData is null.");
                    return response;
                }

                if (qRCodeData.QrCode == input.QrCode)
                {
                    response.TransactionId = qRCodeData.TransactionId;
                    response.TerminalId = qRCodeData.TerminalId;
                    response.Isvalid = true;
                    // Update the QRcodeId to PreStage data
                    if (qRCodeData.ValidUpto > DateTime.Now)
                    {
                        preStageData.QRCodeId = qRCodeData.Id;
                        preStageData.DateChanged = DateTime.Now;
                        await preStageRepository.UpdateAsync(preStageData).ConfigureAwait(false);
                        await _unitOfWork.CommitAsync().ConfigureAwait(false);
                        _logger.LogInformation($"QRCodesManager PostQRCodeAsync: updated the PrestageTransactions table with QRCodeId:{preStageData.QRCodeId}.");
                    }
                    else
                        throw new Exception($"{ErrorMessages.QR_Code_Expired } {input.PrestageId}");
                }
                else
                    response.Isvalid = false;

                _logger.LogInformation($"QRCodesManager PostQRCodeAsync: Isvalid:{response.Isvalid}.");
            }
            catch (Exception ex)
            {
                _logger.LogError("error ocurrurred while validaing the qr code");
                throw ex;
            }
            _logger.LogInformation("Exit QRCodesManager PostQRCodeAsync.");
            return response;
        }

        public async Task<bool> PostSendNotificationAsync(PostQRCodeRequest input, bool isValid)
        {
            _logger.LogInformation("Inside QRCodesManager PostSendNotificationAsync");
            return true; //TODO: need to remove
            #region initialization
            string notificationHubUrl = _qRCodeSetting.Value.NotificationHubBaseUrl;
            SendNotificationDto notificationDto = new SendNotificationDto();
            string[] qrCodeInput = input.QrCode.Split(":");
            string terminalId = qrCodeInput[0];
            string transactionId = qrCodeInput[1];
            string sessionId = qrCodeInput[2];
            string authJwtToken;
            string profileNumber = UserAuthDetail(out authJwtToken);
            _logger.LogInformation($"QRCodesManager PostSendNotificationAsync: ProfileNumber:{profileNumber}," +
                $"terminalId:{terminalId}, transactionId:{transactionId}, sessionId:{sessionId}");
            #endregion
            var prestageRepository = _unitOfWork.GetRepositoryAsync<DataLayer.Entities.Prestage>();

            var prestageSpec = new PrestageGetFilterSpecification(ProfileNumber: profileNumber,
                                                                  ValidUpto: DateTime.Now,
                                                                  PrestageStatus: Statuses.Prestaged.ToString());
            var prestageData = await prestageRepository.FindSingleByAsync(prestageSpec).ConfigureAwait(false);
            if (prestageData == null || prestageData.QRCodeId == null)
            {
                _logger.LogInformation("QRCodesManager PostSendNotificationAsync: prestageData is null.");

                notificationDto.IsValid = false;
                notificationDto.TerminalId = terminalId;
                notificationDto.TransactionId = transactionId;
            }
            else
            {
                notificationDto.Amount = prestageData.Amount;
                notificationDto.CardNumber = prestageData.CardNumber;
                notificationDto.CardExpirydate = prestageData.CardExpiryDate;
                notificationDto.AccountType = prestageData.AccountType;
                notificationDto.PrestageId = prestageData.Id;
                notificationDto.TerminalId = terminalId;
                notificationDto.TransactionId = transactionId;
                notificationDto.IsValid = isValid;

                _logger.LogInformation($"QRCodesManager PostSendNotificationAsync: Calling Notificationhub URL:{notificationHubUrl}," +
               $"TerminalId:{terminalId}, TransactionId: {transactionId}, IsValid: {isValid}, CardNumber:{prestageData.CardNumber}," +
               $"CardExpiryDate:{prestageData.CardExpiryDate}, Amount:{prestageData.Amount}, PrestageId: {prestageData.Id}" +
               $"AccountType:{prestageData.AccountType}");
            }
            bool response = false;
            try
            {
                _logger.LogInformation("QRCodesManager PostSendNotificationAsync: Calling PostAsync().");
                response = await _helper.PostAsync<SendNotificationDto, bool>(notificationHubUrl, notificationDto,  null, null, false);
                _logger.LogInformation($"QRCodesManager PostSendNotificationAsync:Response from Notification hub:" +
                $" {notificationHubUrl}: Response: {response} ");
                _logger.LogInformation("Exit QRCodesManager PostSendNotificationAsync");

            }
            catch (Exception)
            {
                response = false;
                //throw;
            }
            return response;
        }

        #region Private Methods
        /// <summary>
        /// QR Code generation
        /// </summary>
        /// <param name="terminalId"></param>
        /// <param name="transactionId"></param>
        /// <param name="sessionId"></param>
        /// <returns></returns>
        private Bitmap QrCodeGeneration(string terminalId, string transactionId, string sessionId)
        {
            QRCodeGenerator qRCodeGen = new QRCodeGenerator();
            QRCodeData rCodeData = qRCodeGen.CreateQrCode($"{terminalId}:{transactionId}:{sessionId}", QRCodeGenerator.ECCLevel.Q);
            QRCode rCode = new QRCode(rCodeData);
            return rCode.GetGraphic(_qRCodeSetting.Value.QRCodeGraphic);
        }
        /// <summary>
        /// Getting the Sssion Id
        /// </summary>
        /// <returns></returns>
        private string GetSessionTokenDetail(out string sessionjWtToken)
        {
            string sessionId = string.Empty;
            sessionjWtToken = string.Empty;
            var context = _httpContextAccessor.HttpContext;

            if (context != null && context.User != null && context.User.Identity != null && context.User.Identity.IsAuthenticated)
            {
                sessionjWtToken = AuthenticationHeaderValue.Parse(_httpContextAccessor.HttpContext.Request.Headers[HeaderNames.Authorization]).Parameter;
                var identity = context.User.Identity as ClaimsIdentity;
                if (identity != null)
                {
                    IEnumerable<Claim> claims = identity.Claims;
                    sessionId = identity.FindFirst("sessionid").Value;
                }
            }
            return sessionId;
        }

        private byte[] BitMapToBytes(Bitmap bitmap)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                bitmap.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                return stream.ToArray();
            }
        }
        private string GetProfileNumber()
        {
            var userId = string.Empty;
            var context = _httpContextAccessor.HttpContext;
            if (context != null && context.User != null && context.User.Identity != null && context.User.Identity.IsAuthenticated)
            {
                var identity = context.User.Identity as ClaimsIdentity;
                if (identity != null)
                {
                    IEnumerable<Claim> claims = identity.Claims;
                    userId = identity.FindFirst("BusinessEntityUserId").Value;
                }
            }
            return userId;
        }
        private string GetToken()
        {
            var token = string.Empty;

            if (_httpContextAccessor.HttpContext != null && _httpContextAccessor.HttpContext.Request != null)
            {
                token = AuthenticationHeaderValue.Parse(_httpContextAccessor.HttpContext.Request.Headers[HeaderNames.Authorization]).Parameter;
            }

            return token;
        }
        private string UserAuthDetail(out string authjWtToken)
        {
            string sessionId = string.Empty;
            authjWtToken = string.Empty;
            var context = _httpContextAccessor.HttpContext;

            if (context != null && context.User != null && context.User.Identity != null && context.User.Identity.IsAuthenticated)
            {
                authjWtToken = AuthenticationHeaderValue.Parse(_httpContextAccessor.HttpContext.Request.Headers[HeaderNames.Authorization]).Parameter;
                var identity = context.User.Identity as ClaimsIdentity;
                if (identity != null)
                {
                    IEnumerable<Claim> claims = identity.Claims;
                    sessionId = identity.FindFirst("BusinessEntityUserId").Value;
                }
            }
            return sessionId;
        }
        #endregion
    }
}
