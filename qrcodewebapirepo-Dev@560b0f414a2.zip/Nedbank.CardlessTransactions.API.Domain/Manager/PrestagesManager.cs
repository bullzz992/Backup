﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using Nedbank.CardlessTransactions.API.Common.Constants;
using Nedbank.CardlessTransactions.API.Common.Functional.Enum;
using Nedbank.CardlessTransactions.API.Common.Helper;
using Nedbank.CardlessTransactions.API.Common.Helper.Interfaces;
using Nedbank.CardlessTransactions.API.DataLayer;
using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using Nedbank.CardlessTransactions.API.DataLayer.EntityFrameworkCore.UnitOfWork;
using Nedbank.CardlessTransactions.API.DataLayer.Specifications;
using Nedbank.CardlessTransactions.API.Domain.Configuration;
using Nedbank.CardlessTransactions.API.Domain.Dto.Prestages;
using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using Nedbank.CardlessTransactions.API.Resources.NotificationBackOffice;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using static Nedbank.CardlessTransactions.API.Common.Constants.GlobalConstants;

namespace Nedbank.CardlessTransactions.API.Domain.Manager
{
    public class PrestagesManager : IPrestagesManager
    {
        #region Private fields
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHttpContextAccessor _httpContextAccessor;
        readonly CardlessTransactionsContext _cardlessTransactionsContext;
        private readonly IMapper _mapper;
        private readonly ILogger<PrestagesManager> _logger;
        private readonly CardlessTransactionsContext context;
        private readonly ICommonHelper _helper;
        private readonly IEnumHelper _enumHelper;
        private readonly IOptions<BackOfficeNotificationConfiguration> _notificationOptions;
        #endregion

        #region Constructors

        public PrestagesManager(CardlessTransactionsContext context, IMapper mapper, ICommonHelper helper,
          IUnitOfWork unitOfWork, IEnumHelper enumHelper, IHttpContextAccessor httpContextAccessor)
        {
            this.context = context;
            this._mapper = mapper;
            this._helper = helper;
            this._unitOfWork = unitOfWork;
            this._enumHelper = enumHelper;
            this._httpContextAccessor = httpContextAccessor;
        }

        public PrestagesManager(CardlessTransactionsContext context, IMapper mapper, ICommonHelper helper,
            IUnitOfWork unitOfWork, IEnumHelper enumHelper, IHttpContextAccessor httpContextAccessor, ILogger<PrestagesManager> logger,
            IOptions<BackOfficeNotificationConfiguration> notificationOptions)
        {
            this.context = context;
            this._mapper = mapper;
            this._helper = helper;
            this._unitOfWork = unitOfWork;
            this._enumHelper = enumHelper;
            this._httpContextAccessor = httpContextAccessor;
            this._logger = logger;
            this._notificationOptions = notificationOptions;
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Gets prestages cardless withdrawal request for the user
        /// </summary>
        /// <returns></returns>
        public async Task<PrestageResponsesDto> GetPrestagedAsync()
        {
            _logger.LogInformation("Inside GetPrestagedAsync PrestagesManager");
            PrestageResponsesDto responsedto = new PrestageResponsesDto();
            PrestageResponses dto = new PrestageResponses();

            string profilenumber = _helper.GetUserId();
            var prestageRepository = _unitOfWork.GetRepositoryAsync<Prestage>();
            try
            {
                _logger.LogInformation($"PrestagesManager GetPrestagedAsync : ProfileNumber:{profilenumber}");
                // First check if user is Recurring or Existing user
                var existingUserDto = await CheckIsExistingUserAsync();
                if (existingUserDto.IsExistingUser)
                {
                    _logger.LogInformation($"PrestagesManager GetPrestagedAsync :, IsExistingUser:{existingUserDto.IsExistingUser}");
                    responsedto.IsExistingUser = true;
                    var validUpto = DateTime.Now;
                    var prestageSpec = new PrestageGetFilterSpecification(ProfileNumber: profilenumber,
                                     ValidUpto: DateTime.Now, PrestageStatus: Statuses.Prestaged.ToString());
                    _logger.LogInformation($"PrestagesManager GetPrestagedAsync :Getting Prestage data for" +
                        $" ProfileNumber:{profilenumber}, PrestageStatus:{Statuses.Prestaged.ToString()} and ValidUpto:{validUpto}");

                    var prestageData = await prestageRepository.FindSingleByAsync(prestageSpec).ConfigureAwait(false);
                    if (prestageData == null)
                    {
                        _logger.LogInformation($"PrestagesManager GetPrestagedAsync :No Cradless request is found.");
                        return responsedto;
                    }
                    PrestageResponses res = new PrestageResponses();
                    res.PrestageId = prestageData.Id;
                    res.CardNumber = prestageData.CardNumber;
                    res.CardExpiryDate = prestageData.CardExpiryDate;
                    res.Amount = prestageData.Amount;
                    res.Status = prestageData.PrestageStatus;
                    res.AccountType = prestageData.AccountType;
                    res.validUpto = prestageData.ValidUpto;

                    responsedto.PrestageResponses = new PrestageResponses[1] { res };
                    responsedto.IsExistingUser = true;
                }
                _logger.LogInformation("Exit GetPrestagedAsync manager");
                return responsedto;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Gets status of a Cardless request
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PrestageStatusResponseDto> GetStatusAsync(long id)
        {
            _logger.LogInformation($"Inside GetStatusAsync manager Id: {id}");
            PrestageStatusResponseDto dto = new PrestageStatusResponseDto();
            string profilenumber = _helper.GetUserId();
            _logger.LogInformation($"GetStatusAsync profilenumber: {profilenumber}");
            var prestageSpec = new PrestageGetStatusFilterSpecification(Id: id, ProfileNumber: profilenumber);
            var prestageRepository = _unitOfWork.GetRepositoryAsync<Prestage>();
            try
            {
                var prestageData = await prestageRepository.FindSingleByAsync(prestageSpec);
                if (prestageData != null)
                {
                    _logger.LogInformation($"GetStatusAsync StatusCode: {prestageData.PrestageStatus}" +
                        $",StatusDescription:{prestageData.StatusMessage}");

                    dto.StatusCode = prestageData.PrestageStatus;
                    dto.StatusDescription = prestageData.StatusMessage;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            _logger.LogInformation($"Exit GetStatusAsync manager");
            return dto;
        }

        /// <summary>
        /// Validate the prestaged withdrawal request from terminalid and transactionId
        /// </summary>
        /// <param name="terminalId"></param>
        /// <param name="transactionId"></param>
        /// <param name="fromAccount"></param>
        /// <param name="amount"></param>
        /// <returns></returns>
        public async Task<PrestageValidateResponseDto> GetPrestageValidateAsync(string terminalId, string transactionId,
           string cardNumber, int amount)
        {
            _logger.LogInformation($"Inside GetPrestageValidateAsync manager terminalId:" +
                $" {terminalId},transactionId: {transactionId},cardNumber: {cardNumber},amount:{amount}");

            if (!string.IsNullOrWhiteSpace(terminalId) && !string.IsNullOrWhiteSpace(transactionId) &&
                !string.IsNullOrWhiteSpace(cardNumber) && amount > 0)
            {
                PrestageValidateResponseDto responsedto = new PrestageValidateResponseDto();

                // QR Code repository to get the QRCode for validation
                var qRCodeGetSpec = new QRCodeGetFilterTransactionIdTerminalIdSpecification(Terminalid: terminalId,
                    Transactionid: transactionId, ValidUpto: DateTime.Now);
                var qRCodeRepository = _unitOfWork.GetRepositoryAsync<QRCode>();
                var qRCodeDetail = await qRCodeRepository.FindSingleByAsync(qRCodeGetSpec).ConfigureAwait(false);
               
                if (qRCodeDetail == null)
                {
                    _logger.LogInformation($"GetPrestageValidateAsync manager: qRCodeId is null");
                    return responsedto;
                }
                long qRCodeId = qRCodeDetail.Id;
                // Get the Prestage request QRCodeId,Status and active
                var prestageSpec = new PrestageGetByQRCodeIdFilterSpecification(QRCodeId: qRCodeId,
                                       PrestageStatus: Statuses.Prestaged.ToString(), ValidUpto: DateTime.Now);

                var prestageRepository = _unitOfWork.GetRepositoryAsync<Prestage>();
                var prestageDetail = await prestageRepository.FindSingleByAsync(prestageSpec);               
                if (prestageDetail == null)
                {
                    _logger.LogInformation($"GetPrestageValidateAsync manager: prestageDetail is null.");
                    return responsedto;
                }

                // validate account and amount
                if (prestageDetail.CardNumber.Equals(cardNumber) && prestageDetail.Amount.Equals(amount))
                {
                    responsedto.IsValid = true;
                    responsedto.PrestageId = prestageDetail.Id;
                    _logger.LogInformation($"GetPrestageValidateAsync manager: IsValid:{responsedto.IsValid}" +
                       $",PrestageId:{responsedto.PrestageId}");
                }
                else
                {
                    responsedto.IsValid = false;
                    responsedto.PrestageId = prestageDetail.Id;
                    _logger.LogInformation($"GetPrestageValidateAsync manager: IsValid:{responsedto.IsValid}" +
                       $",PrestageId:{responsedto.PrestageId}");
                }
                return responsedto;
            }
            else
            {
                throw new Exception(ErrorMessages.Invaid_Arguments);
            }
        }

        /// <summary>
        /// Makes a new cardless withdrawal request
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<CreatePrestageResponseDto> CreateAsync(CreatePrestageRequestDto input)
        {
            _logger.LogInformation($"Inside CreateAsync manager.");
            if (input == null || string.IsNullOrWhiteSpace(input.CardNumber)
                || string.IsNullOrWhiteSpace(input.AccountType) || input.Amount < PrestageConstants.MinWithdrawalAmount
                || input.Amount > PrestageConstants.MaxWithdrawalAmount)
            {
                _logger.LogError($"CreateAsync manager:Error:{ErrorMessages.Invaid_Arguments}");
                throw new ArgumentNullException(ErrorMessages.Invaid_Arguments);
            }
            var prestageRepository = _unitOfWork.GetRepositoryAsync<Prestage>();
            CreatePrestageResponseDto responsedto = new CreatePrestageResponseDto();
            try
            {
                string profilenumber = _helper.GetUserId();
                _logger.LogInformation($"CreateAsync manager:profilenumber:{profilenumber}");
                string token = _helper.GetToken();
                _logger.LogInformation($"CreateAsync manager:token:{token}");

                // Check whether cardless request is already in Prestaged state for user,then new request will not be prestaged
                var prestageSpec = new PrestageGetFilterSpecification(ProfileNumber: profilenumber, ValidUpto: DateTime.Now,
                                                                      PrestageStatus: Statuses.Prestaged.ToString());

                var prestageData = await prestageRepository.FindSingleByAsync(prestageSpec);
                if (prestageData != null)
                {
                    _logger.LogInformation($"CreateAsync manager: There is already a Prestaged request for Profile: {profilenumber}," +
                        $" and Existing Request id:{prestageData.Id}");
                    return responsedto;
                }

                DateTime prestageCreateddate = DateTime.Now;
                Prestage prestage = new Prestage();
                prestage.CardNumber = input.CardNumber;
                prestage.CardExpiryDate = input.CardExpiryDate;
                prestage.AccountType = input.AccountType;
                prestage.Amount = input.Amount;
                prestage.ProfileNumber = profilenumber;
                prestage.DateCreated = prestageCreateddate;
                prestage.ValidUpto = prestageCreateddate.AddHours(PrestageConstants.PrestageReqValidUpto);
                prestage.PrestageStatus = Statuses.Prestaged.ToString();
                prestage.CreatedToken = "Request is " + Statuses.Prestaged.ToString();
                prestage.CreatedToken = token;

                // Insert new Prestage request                     
                var createdPrestage = await prestageRepository.AddAsync(prestage).ConfigureAwait(false);
                await _unitOfWork.CommitAsync().ConfigureAwait(false);

                responsedto.PrestageId = createdPrestage.Id;
                _logger.LogInformation($"CreateAsync manager:Prestage Request is created for Peofile: {profilenumber}," +
                    $" Prestage request Id:{createdPrestage.Id}");

                _logger.LogInformation($"CreateAsync manager:Exit.");
                return responsedto;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Updates the prestaged withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<UpdatePrestageResponseDto> UpdateAsync(long id, UpdatePrestageRequestDto input)
        {
            _logger.LogInformation($"Inside UpdateAsync PrestagesManager.");
            UpdatePrestageResponseDto responseDto = new UpdatePrestageResponseDto();
            if (input == null || id <= 0)
            {
                _logger.LogError($"UpdateAsync manager:Error:{ErrorMessages.Invaid_Arguments}");
                throw new ArgumentException(ErrorMessages.Invaid_Arguments);
            }
            try
            {
                var prestageRepository = _unitOfWork.GetRepositoryAsync<Prestage>();
                string profileNumber = _helper.GetUserId();
                _logger.LogInformation($"UpdateAsync PrestagesManager:profilenumber:{profileNumber}");
                string token = _helper.GetToken();
                _logger.LogInformation($"UpdateAsync manager:profilenumber:{token}");
                var prestageUpdate_Spec = new PrestageUpdateFilterSpecification(Id: id, PrestageStatus: Statuses.Prestaged.ToString(),
                                                                                        ProfileNumber: profileNumber);
                //get Prestage details by PrestageId
                var prestageData = await prestageRepository.FindSingleByAsync(prestageUpdate_Spec).ConfigureAwait(false);
                if (prestageData == null)
                {
                    _logger.LogInformation($"UpdateAsync manager: no Cardless request is found to update for PrestageId: {id}");
                    return responseDto;
                }
                prestageData.DateChanged = DateTime.Now;
                prestageData.CardNumber = input.CardNumber;
                prestageData.CardExpiryDate = input.CardExpiryDate;
                prestageData.Amount = input.Amount;
                prestageData.AccountType = input.AccountType;
                prestageData.LastModifiedToken = token;
                await prestageRepository.UpdateAsync(prestageData);
                await _unitOfWork.CommitAsync().ConfigureAwait(false);
                responseDto.PrestageId = id;

                _logger.LogInformation($"UpdateAsync manager: Cardless request is updated for PrestageId: {id}");
                _logger.LogInformation($"UpdateAsync manager: Exit.");
                return responseDto;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Updates the prestaged cardless withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<UpdatePrestageResponseDto> UpdatePrestageStatusAsync(string transactionId, UpdatePrestageStatusRequestDto input)
        {
            _logger.LogInformation($"Inside UpdatePrestageStatusAsync manager.");
            UpdatePrestageResponseDto responseDto = new UpdatePrestageResponseDto();
            if (input == null || string.IsNullOrWhiteSpace(transactionId))
            {
                _logger.LogError($"UpdatePrestageStatusAsync manager: Exception:{ErrorMessages.Invaid_Arguments}");
                throw new ArgumentException(ErrorMessages.Invaid_Arguments);
            }
            try
            {
                string profileNumber = _helper.GetUserId();
                _logger.LogInformation($"UpdatePrestageStatusAsync manager: ProfileNumber:{profileNumber}");
                string token = _helper.GetToken();
                _logger.LogInformation($"UpdatePrestageStatusAsync manager: Token :{token}");
                var qrCodeRepository = _unitOfWork.GetRepositoryAsync<QRCode>();
                DateTime validUpto = DateTime.Now;
                var qrCodeSpec = new QRCodeGetQRCodeByTransactionIdSpecification(TransactionId: transactionId, ValidUpto: validUpto);
                var qrCodeData = await qrCodeRepository.FindSingleByAsync(qrCodeSpec).ConfigureAwait(false);
                if (qrCodeData == null)
                {
                    _logger.LogInformation($"UpdatePrestageStatusAsync manager: No QrCode is for Transactionid:{transactionId} and " +
                        $"validUpto:{ validUpto}");
                    return responseDto;
                }

                long qrCodeId = qrCodeData.Id;
                _logger.LogInformation($"UpdatePrestageStatusAsync manager: QRCodeId:{qrCodeId}");

                var prestageUpdateSpec = new PrestageGetPrestageByQRCodeIdSpecification(QRCodeId: qrCodeId,
                                             Status: Statuses.Prestaged.ToString(), ValidUpto: validUpto);

                var prestageRepository = _unitOfWork.GetRepositoryAsync<Prestage>();

                //get Prestage details by PrestageId
                var prestageData = await prestageRepository.FindSingleByAsync(prestageUpdateSpec).ConfigureAwait(false);
                if (prestageData == null)
                {
                    _logger.LogInformation($"UpdatePrestageStatusAsync manager: No Prestaged Cardless request found for" +
                        $" QRCodeId:{qrCodeId} and validUpto:{ validUpto}");
                    return responseDto;
                };

                Statuses status = (Statuses)Enum.Parse(typeof(Statuses), input.StatusCode);

                prestageData.DateChanged = DateTime.Now;
                prestageData.PrestageStatus = status.ToString();
                prestageData.StatusMessage = input.StatusDescription;
                prestageData.LastModifiedToken = token;

                await prestageRepository.UpdateAsync(prestageData);
                await _unitOfWork.CommitAsync().ConfigureAwait(false);

                responseDto.PrestageId = prestageData.Id;
                _logger.LogInformation($"UpdatePrestageStatusAsync manager: Cardless request updated for PrestageId:" +
                    $"{responseDto.PrestageId} to status:{ status.ToString()}");

                _logger.LogInformation($"Exit UpdatePrestageStatusAsync manager.");
                return responseDto;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Delete the prestaged cardless withdrawal request
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<DeletePrestageResponse> DeleteAsync(long id)
        {
            _logger.LogInformation($"Inside PrestagesManager DeleteAsync Id:{id}");
            DeletePrestageResponse responsedto = new DeletePrestageResponse();
            if (id <= 0)
            {
                _logger.LogError($"PrestagesManager DeleteAsync Exception:{ErrorMessages.ID_SHDBE_GRTR_THN_ZERO}");
                throw new ArgumentException(ErrorMessages.ID_SHDBE_GRTR_THN_ZERO);
            }

            var prestageRepository = _unitOfWork.GetRepositoryAsync<Prestage>();
            try
            {
                string profilenumber = _helper.GetUserId();
                _logger.LogInformation($"PrestagesManager DeleteAsync: profilenumber:{profilenumber}");
                string token = _helper.GetToken();
                _logger.LogInformation($"PrestagesManager DeleteAsync: Token:{token}");
                var prestageDeleteSpec = new PrestageDeleteFilterSpecification(Id: id, PrestagedStatus: Statuses.Prestaged.ToString(),
                                                                                                   ProfileNuber: profilenumber);
                //get Prestage details by PrestageId
                _logger.LogInformation($"PrestagesManager DeleteAsync:make Cardless request for Id:{id},ProfileNuber: {profilenumber}");
                var prestageData = await prestageRepository.FindSingleByAsync(prestageDeleteSpec).ConfigureAwait(false);
                if (prestageData == null)
                {
                    _logger.LogInformation($"PrestagesManager DeleteAsync: No Cardless request is found.");
                    return responsedto;
                };
                prestageData.PrestageStatus = Statuses.Deleted.ToString();
                prestageData.DateChanged = DateTime.Now;
                prestageData.LastModifiedToken = token;

                await prestageRepository.UpdateAsync(prestageData);
                await _unitOfWork.CommitAsync().ConfigureAwait(false);

                responsedto.PrestageId = id;
                _logger.LogInformation($"PrestagesManager DeleteAsync: Cardless request is deleted for Id:{id}.");
                _logger.LogInformation($"Exit PrestagesManager DeleteAsync Id:{id}");
                return responsedto;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Check whether user is firsttime user or recurring user
        /// </summary>
        /// <returns></returns>
        public async Task<PrestageResponseCheckIsExistingUserDto> CheckIsExistingUserAsync()
        {
            _logger.LogInformation($"Inside PrestagesManager CheckIsExistingUserAsync");
            PrestageResponseCheckIsExistingUserDto dto = new PrestageResponseCheckIsExistingUserDto();
            string profilenumber = _helper.GetUserId();
            _logger.LogInformation($"PrestagesManager CheckIsExistingUserAsync: Profilenumber: {profilenumber}");
            var prestageSpec = new PrestageCheckIsExistingUserFilterSpecification(ProfileNumber: profilenumber);
            var prestageRepository = _unitOfWork.GetRepositoryAsync<Prestage>();
            try
            {
                var prestageData = await prestageRepository.FindFirstOrDefaultByAsync(prestageSpec).ConfigureAwait(false);
                if (prestageData != null)
                {
                    _logger.LogInformation($"PrestagesManager CheckIsExistingUserAsync: Profilenumber: {profilenumber} is an ExistingUser");
                    dto.IsExistingUser = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            _logger.LogInformation($"PrestagesManager CheckIsExistingUserAsync: Profilenumber: {profilenumber} isExistingUser:{dto.IsExistingUser}");
            _logger.LogInformation($"Exit PrestagesManager CheckIsExistingUserAsync");
            return dto;
        }

        public async Task<BackOfficeNotificationResponse> PostAsyncBackOfficeNotification()
        {
            BackOfficeNotificationRequest request = CreateBackOfficeNotificationRequest();
            BackOfficeNotificationResponse notificationResponse = new BackOfficeNotificationResponse();
            //Dictionary<string, string> headers = new Dictionary<string, string>();
            //headers.Add("x-ibm-client-id", _notificationOptions.Value.clientId);
            //headers.Add("x-ibm-client-secret", _notificationOptions.Value.clientSecretKey);
            Dictionary<string, string> headers = new Dictionary<string, string>
            {
                { "x-ibm-client-id",_notificationOptions.Value.clientId },
                { "x-ibm-client-secret",_notificationOptions.Value.clientSecretKey },
                { "backOfficeId",_notificationOptions.Value.backOfficeId },
                { "backOfficeToken",_notificationOptions.Value.backOfficeToken}
            };
            try
            {
                notificationResponse = await _helper.PostAsync<BackOfficeNotificationRequest, BackOfficeNotificationResponse>(_notificationOptions.Value.backOfficeApiUrl,
                                                    request, headers);
            }
            catch (Exception ex)
            {
                throw;
            }

            return notificationResponse;
        }
        #endregion

        #region Private methods
        private BackOfficeNotificationHelperDto CreatePreStagedMessageRequest(int amount)
        {
            return new BackOfficeNotificationHelperDto
            {
                body = BackOfficeNotificationConstants.PreStagedBody.Replace("{", amount.ToString()),
                displayCategory = BackOfficeNotificationConstants.PrestagedDisplayCategory,
                displaySubCategory= BackOfficeNotificationConstants.PrestagedDisplaySubCategory,
                heading= BackOfficeNotificationConstants.Heading,
                notificationType= BackOfficeNotificationConstants.NotificationType,
                subHeading= BackOfficeNotificationConstants.PreStagedSubHeading,
                url= BackOfficeNotificationConstants.url

            };
        }

        /// <summary>
        /// BackOffice Notification APIs request  
        /// </summary>
        /// <returns></returns>
        private BackOfficeNotificationRequest CreateBackOfficeNotificationRequest()
        {
            var nedBankId = _helper.GetNedBankId();
            var clientIdentity = new ClientIdentity()
            {
                clientIdentifier = nedBankId,
                clientIdentifierType = "NED"
            };
            var additionalParameter = new List<AdditionalParameter>()
            {
                new AdditionalParameter()  // Need Discussion
                {
                    name="",
                    value=""
                }
            };

            var responseOptions = new List<ResponseOption>()
            {
                new ResponseOption   // Need Discussion
                {
                    action="",
                    additionalParameters=additionalParameter,
                    label="",
                    type="ALP",  //Need to discuss
                    value="1"
                }
            };
            var channels = new List<Channel>()
            {
                new Channel
                {
                    channel=100,
                }
            };
            var richContent = new List<RichContent>() // optional 
            {
                new RichContent()   // Based on response Options --// Need Discussion
                {
                    contentType="",
                    displayName="",
                    displayType="",
                    sourceCms="",
                    sourcePath="",
                    token="",
                }
            };
            var meta = new List<Meta>()  // Optional parameter  // Need Discussion
            {
                new Meta()
                {
                    name="",
                    value=""
                }
            };
            DateTime expiry = DateTime.Now.AddSeconds(60);
            Notification notification = new Notification
            {
                activeExpiryDate = expiry,// Need to check expiry for Notification 
                allowAnonymous = false,  // Need to verify
                allowMultipleResponses = false,
                backOfficeNotificationDate = DateTime.Now,
                backOfficeNotificationId = $"ATM_QR" + Guid.NewGuid().ToString(),// That has to be unique for every Notification to be sent
                body = $"R waiting for you to withdraw.",
                channels = channels,
                clientIdentity = clientIdentity,
                deliveryPriority = 2,
                deviceExpiryDate = expiry.AddSeconds(60), // Need verification
                displayCategory = "CardLess Transaction",  // Need verification
                displaySubCategory = "QR Code Withdrawals",// Need verification
                heading = "NEDBANK MONEY",// Need verification
                isDirectFlow = false,
                meta = meta,
                mustBlockApp = false,
                mustNotShowInInbox = false,
                mustPush = true,
                mustTrackAllReads = false,
                mustTrackDismiss = true,
                mustTrackFirstRead = true,
                notificationType = "INF",
                responseOptions = responseOptions,
                responsePriority = 2,
                richContent = richContent,
                subHeading = "QR Code Withdrawals",// Need verification
                url = ""
            };
            return new BackOfficeNotificationRequest
            {
                notification = notification
            };
        }
        #endregion
    }
}
