﻿using Nedbank.CardlessTransactions.API.Domain.Manager.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.Domain.Manager
{
    public class NotificationsManager: INotificationsManager
    {
    }
}
