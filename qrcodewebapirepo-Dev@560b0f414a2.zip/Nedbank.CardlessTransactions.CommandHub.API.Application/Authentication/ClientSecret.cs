﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.CommandHub.API.Application.Authentication
{
    public class ClientSecret
    {
        public string ClientId { get; set; }
        public string ClientSecretKey { get; set; }
    }
}
