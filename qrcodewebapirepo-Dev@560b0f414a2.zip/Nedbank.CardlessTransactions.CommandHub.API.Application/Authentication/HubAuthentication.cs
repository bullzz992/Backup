﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.CommandHub.API.Application.Authentication
{
    public class HubAuthentication
    {
        private readonly RequestDelegate _next;
        private readonly ClientSecret _options;

        public HubAuthentication(RequestDelegate next, IOptions<ClientSecret> options)
        {
            _next = next;
            this._options = options.Value;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            string clientId = string.Empty;
            string clientSecretKey = string.Empty;

            var request = httpContext.Request;
            if (!httpContext.Request.Path.StartsWithSegments("/atmNotificationHub"))
            {
                if (!httpContext.Request.Headers.ContainsKey("x-ibm-client-id") || !httpContext.Request.Headers.ContainsKey("x-ibm-client-secret"))
                {
                    httpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                    return;
                }
                if (httpContext.Request.Headers.ContainsKey("x-ibm-client-id") && httpContext.Request.Headers.ContainsKey("x-ibm-client-secret"))
                {
                    clientId = httpContext.Request.Headers["x-ibm-client-id"];
                    clientSecretKey = httpContext.Request.Headers["x-ibm-client-secret"];
                    if (_options.ClientId == clientId && _options.ClientSecretKey == clientSecretKey)
                    {
                        await _next.Invoke(httpContext);
                    }
                    else
                    {
                        httpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                        return;
                    }
                }
            }
            await _next(httpContext);
        }
    }

}
