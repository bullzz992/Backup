﻿using Microsoft.AspNetCore.Mvc;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Dto.Notifications;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications;
using Nedbank.CardlessTransactions.CommandHub.Application.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.CommandHub.API.Application.Controllers.Interfaces
{
    public interface INotificationsController
    {
        Task<APIResponse<SendNotificationResponse>> PostAsyncSendNotification([FromBody] SendNotificationDto input);
    }
}
