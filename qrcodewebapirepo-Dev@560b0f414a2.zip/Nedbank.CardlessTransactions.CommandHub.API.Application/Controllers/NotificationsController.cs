﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Nedbank.CardlessTransactions.CommandHub.API.Application.Controllers.Interfaces;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Dto.Notifications;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Manager.Interface;
using Nedbank.CardlessTransactions.CommandHub.API.Domain.Notifications;
using Nedbank.CardlessTransactions.CommandHub.Application.Models;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.CommandHub.API.Application.Controllers
{
    [Route("/withdrawals/notifications")]
    [ApiController]
    public class NotificationsController : ControllerBase, INotificationsController
    {
        private readonly IHubNotificationManager _hubNotification;
        private readonly ILogger<NotificationsController> _logger;

        public NotificationsController(IHubNotificationManager hubNotification, ILogger<NotificationsController> logger)
        {
            this._hubNotification = hubNotification;
            this._logger = logger;
        }

        [HttpPost("sendNotification")]
        public async Task<APIResponse<SendNotificationResponse>> PostAsyncSendNotification([FromBody] SendNotificationDto input)
        {
            _logger.LogInformation("Inside NotificationsController PostAsyncSendNotification.");
            APIResponse<SendNotificationResponse> apiResponse = new APIResponse<SendNotificationResponse>();
            SendNotificationResponse response = new SendNotificationResponse();
            //try
            //{
            _logger.LogInformation("NotificationsController PostAsyncSendNotification: calling SendNotication.");
            response = await _hubNotification.SendNotication(input);
            _logger.LogInformation($"NotificationsController PostAsyncSendNotification: SendNotication Response:{response.IsSuccess}");
            apiResponse.CreateSuccessResponse(response);
            _logger.LogInformation("Exit NotificationsController PostAsyncSendNotification.");
            return apiResponse;
        }
    }
}

