﻿using Nedbank.CardlessTransactions.API.Common.Constants;
using Nedbank.CardlessTransactions.CommandHub.API.Application.Model;
using System;
using System.Collections.Generic;
using System.Net;

namespace Nedbank.CardlessTransactions.CommandHub.Application.Models
{
    public class APIResponse<T>
    {
        public T Data { get; set; }

        public ResponseMetadata Metadata { get; set; }
        
        public void CreateErrorResponse(string failuremsg)
        {
            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)HttpStatusCode.InternalServerError),
                            ResultCode = GlobalConstants.ResultCodes.ErrorCodeR01,
                            ResultDescription = failuremsg
                        }
                    }
            };
        }
        public void CreateErrorResponse(string failuremsg, HttpStatusCode httpStatusCode)
        {
            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)httpStatusCode),
                            ResultCode = GlobalConstants.ResultCodes.RecordNotFound,
                            ResultDescription = failuremsg
                        }
                    }
            };
        }

        public void CreateErrorResponse(HttpStatusCode httpStatusCode)
        {

            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)httpStatusCode),
                            ResultCode = GlobalConstants.ResultCodes.ErrorCodeR01,
                            ResultDescription = httpStatusCode.ToString()
                        }
                    }
            };

        }
     
        public void CreateEmptyResponse()
        {
            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)HttpStatusCode.NoContent),
                            ResultCode = GlobalConstants.ResultCodes.SuccessCode,
                            ResultDescription = "No Content"
                        }
                    }
            };
        }

        public void CreateNotFoundResponse(string msg = "Not Found")
        {
            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)HttpStatusCode.NotFound),
                            ResultCode = GlobalConstants.ResultCodes.RecordNotFound,
                            ResultDescription = msg
                        }
                    }
            };
        }
        public void CreateSuccessResponse(T t)
        {
            Data = t;
            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)HttpStatusCode.OK),
                            ResultCode = GlobalConstants.ResultCodes.SuccessCode,
                            ResultDescription = "OK"
                        }
                    }
            };
        }

        public void CreateSuccessfulCreatedResponse(T t)
        {

            Data = t;
            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)HttpStatusCode.Created),
                            ResultCode = GlobalConstants.ResultCodes.SuccessCode,
                            ResultDescription = "Created"
                        }
                    }
            };

        }


        //--------------------------------------------------------------------------------------
        public void CreateCustomResponse(T t, string message, HttpStatusCode code, string resultCode)
        {
            Data = t;
            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)code),
                            ResultCode = resultCode,
                            ResultDescription = message
                        }
                    }
            };
        }
        public void CreateCustomEmptyResponse(string message, HttpStatusCode code, string resultCode)
        {
            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)code),
                            ResultCode = resultCode,
                            ResultDescription = message
                        }
                    }
            };
        }

        public void CreateCustomErrorResponse(string message, HttpStatusCode code, string resultCode)
        {
            Metadata = new ResponseMetadata
            {
                Page = 0,
                PageLimit = 0,
                PageSize = 0,
                ResultData = new List<ResponseResult>
                    {
                        new ResponseResult
                        {
                            HttpReturnCode = Convert.ToString((int)code),
                            ResultCode = resultCode,
                            ResultDescription = message
                        }
                    }
            };
        }

    }
}
