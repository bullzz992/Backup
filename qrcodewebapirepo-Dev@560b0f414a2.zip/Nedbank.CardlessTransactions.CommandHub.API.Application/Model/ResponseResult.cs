﻿namespace Nedbank.CardlessTransactions.CommandHub.Application.Models
{
    public class ResponseResult
    {
        public string HttpReturnCode { get; set; }

        public string ResultCode { get; set; }

        public string ResultDescription { get; set; }
    }
}
