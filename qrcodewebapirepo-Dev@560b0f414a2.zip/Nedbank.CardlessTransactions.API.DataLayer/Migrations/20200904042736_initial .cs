﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Nedbank.CardlessTransactions.API.DataLayer.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "QRCodes",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TerminalId = table.Column<string>(type: "nvarchar(10)", nullable: false),
                    TransactionId = table.Column<string>(type: "nvarchar(15)", nullable: false),
                    SessionId = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    QrCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateCreated = table.Column<DateTime>(nullable: false),
                    ValidUpto = table.Column<DateTime>(nullable: false),
                    Token = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QRCodes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PrestageTransactions",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FromAccount = table.Column<string>(type: "nvarchar(20)", nullable: false),
                    AccountType = table.Column<string>(type: "nvarchar(15)", nullable: false),
                    Amount = table.Column<int>(nullable: false),
                    ProfileNumber = table.Column<string>(type: "nvarchar(20)", nullable: false),
                    DateCreated = table.Column<DateTime>(nullable: false),
                    ValidUpto = table.Column<DateTime>(nullable: false),
                    DateChanged = table.Column<DateTime>(nullable: true),
                    PrestageStatus = table.Column<string>(type: "nvarchar(12)", nullable: false),
                    StatusMessage = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    QRCodeId = table.Column<long>(nullable: true),
                    CreatedToken = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastModifiedToken = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PrestageTransactions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PrestageTransactions_QRCodes_QRCodeId",
                        column: x => x.QRCodeId,
                        principalTable: "QRCodes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "QRCodes",
                columns: new[] { "Id", "DateCreated", "QrCode", "SessionId", "TerminalId", "Token", "TransactionId", "ValidUpto" },
                values: new object[] { 1L, new DateTime(2020, 9, 4, 9, 57, 35, 728, DateTimeKind.Local).AddTicks(9748), "ter1tran1", "sess1", "ter1", "Token1", "tran1", new DateTime(2020, 9, 4, 9, 58, 25, 729, DateTimeKind.Local).AddTicks(303) });

            migrationBuilder.InsertData(
                table: "PrestageTransactions",
                columns: new[] { "Id", "AccountType", "Amount", "CreatedToken", "DateChanged", "DateCreated", "FromAccount", "LastModifiedToken", "PrestageStatus", "ProfileNumber", "QRCodeId", "StatusMessage", "ValidUpto" },
                values: new object[] { 1L, "Saving", 1000, "Token1", null, new DateTime(2020, 9, 4, 9, 57, 35, 726, DateTimeKind.Local).AddTicks(6735), "act1", null, "Prestaged", "Pn1", 1L, "Sm1", new DateTime(2020, 9, 4, 17, 57, 35, 727, DateTimeKind.Local).AddTicks(967) });

            migrationBuilder.CreateIndex(
                name: "IX_PrestageTransactions_QRCodeId",
                table: "PrestageTransactions",
                column: "QRCodeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PrestageTransactions");

            migrationBuilder.DropTable(
                name: "QRCodes");
        }
    }
}
