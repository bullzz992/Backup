﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class PrestageGetPrestageByQRCodeIdSpecification:BaseSpecification<Prestage>
    {
        public PrestageGetPrestageByQRCodeIdSpecification(long QRCodeId,string Status, DateTime ValidUpto) :
           base(b => b.QRCodeId.Equals(QRCodeId) && b.PrestageStatus.Equals(Status) && b.ValidUpto.CompareTo(ValidUpto) > 0)
        {

        }
    }
}
