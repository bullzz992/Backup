﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class QRCodeGetFilterTransactionIdTerminalIdSpecification : BaseSpecification<QRCode>
    {
        public QRCodeGetFilterTransactionIdTerminalIdSpecification(string Terminalid,string Transactionid, DateTime ValidUpto)
            : base(b => b.TerminalId.Equals(Terminalid) && b.TransactionId.Equals(Transactionid) &&  b.ValidUpto.CompareTo(ValidUpto) > 0)
        {

        }
    }
}
