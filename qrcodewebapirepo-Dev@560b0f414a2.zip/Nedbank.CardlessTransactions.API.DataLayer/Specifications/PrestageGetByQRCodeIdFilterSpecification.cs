﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class PrestageGetByQRCodeIdFilterSpecification : BaseSpecification<Prestage>
    {
        public PrestageGetByQRCodeIdFilterSpecification(long QRCodeId, string PrestageStatus, DateTime ValidUpto) :
               base(b => b.QRCodeId.Equals(QRCodeId) && b.PrestageStatus.Equals(PrestageStatus) && b.ValidUpto.CompareTo(ValidUpto) > 0)
        {

        }
    }
}
