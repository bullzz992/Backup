﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class PrestageDeleteFilterSpecification : BaseSpecification<Prestage>
    {
        public PrestageDeleteFilterSpecification(long Id, string PrestagedStatus,string ProfileNuber) : 
            base(b => b.Id.Equals(Id) && b.PrestageStatus.Equals(PrestagedStatus) && b.ProfileNumber.Equals(ProfileNuber))
        {

        }
    }
}
