﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class QRCodeGetQRCodeByTransactionIdSpecification : BaseSpecification<QRCode>
    {
        public QRCodeGetQRCodeByTransactionIdSpecification(string TransactionId,DateTime ValidUpto)
          : base(b => b.TransactionId.Equals(TransactionId) && b.ValidUpto.CompareTo(ValidUpto) > 0)
        {

        }
    }
}
