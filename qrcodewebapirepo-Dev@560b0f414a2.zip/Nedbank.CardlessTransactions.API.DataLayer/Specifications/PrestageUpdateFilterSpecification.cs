﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class PrestageUpdateFilterSpecification: BaseSpecification<Prestage>
    {
        public PrestageUpdateFilterSpecification(long Id, string PrestageStatus, string ProfileNumber) :
            base(b => b.Id.Equals(Id) && b.PrestageStatus.Equals(PrestageStatus) && b.ProfileNumber.Equals(ProfileNumber))
        {

        }

        //public PrestageUpdateFilterSpecification(long Id, string ProfileNumber) :
        //   base(b => b.Id.Equals(Id) && b.ProfileNumber.Equals(ProfileNumber))
        //{

        //}
    }
}
