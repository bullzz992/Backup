﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class PrestageCheckIsExistingUserFilterSpecification : BaseSpecification<Prestage>
    {
        public PrestageCheckIsExistingUserFilterSpecification(string ProfileNumber):base(b=>b.ProfileNumber.Equals(ProfileNumber))
        {

        }
    }
}
