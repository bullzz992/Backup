﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class QRCodeValidateFilterSpecification : BaseSpecification<QRCode>
    {
        public QRCodeValidateFilterSpecification(string terminalId, string transactionId, string sessionId)
                                                   : base(a => a.TerminalId == terminalId && a.TransactionId == transactionId
                                                    && a.SessionId == sessionId)
        {

        }
    }
}
