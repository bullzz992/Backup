﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class PrestageGetFilterSpecification : BaseSpecification<Prestage>
    {
        public PrestageGetFilterSpecification(string ProfileNumber, DateTime ValidUpto, string PrestageStatus) :
                    base(b => b.ProfileNumber.Equals(ProfileNumber) && b.PrestageStatus == PrestageStatus && b.ValidUpto.CompareTo(ValidUpto) > 0)
        {
           // AddIncludes(query => query.Include(s => s.PrestageStatus));
        }
    }
}
