﻿using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Specifications
{
    public class PrestageGetStatusFilterSpecification : BaseSpecification<Prestage>
    {
        public PrestageGetStatusFilterSpecification(long Id, string ProfileNumber) :
            base(c => c.Id.Equals(Id) && c.ProfileNumber.Equals(ProfileNumber))
        {
            // AddIncludes(query => query.Include(s => s.PrestageStatus));
        }
    }
}
