﻿using Nedbank.CardlessTransactions.API.DataLayer.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Entities
{
    [Table(name: "QRCodes")]
    public class QRCode : Entity<long>//, IAuditableEntity
    {
        [Required]
        [Column(TypeName = "nvarchar(10)")]
        public string TerminalId { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(15)")]
        public string TransactionId { get; set; }
        [Required]
        [Column(TypeName ="nvarchar(100)")]
        public string SessionId { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(max)")]
        public string QrCode { get; set; }

        [Required]
        public DateTime DateCreated { get; set; }

        [Required]
        public DateTime ValidUpto { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(max)")]
        public string Token { get; set; }

      //  public virtual Prestage Prestage { get; set; }

    }
}
