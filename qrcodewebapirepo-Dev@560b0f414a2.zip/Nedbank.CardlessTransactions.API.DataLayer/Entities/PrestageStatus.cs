﻿using Nedbank.CardlessTransactions.API.DataLayer.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Entities
{
    //[Table(name: "PrestageStatuses")]
    //public class PrestageStatus : Entity<int>
    //{
    //    public string Name { get; set; }

    //   // public virtual Prestage Prestage { get; set; }
    //    public virtual ICollection<Prestage> Prestages { get; set; }
    //}
}