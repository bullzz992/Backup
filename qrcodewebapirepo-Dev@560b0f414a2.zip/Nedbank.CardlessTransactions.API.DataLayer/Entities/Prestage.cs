﻿using Nedbank.CardlessTransactions.API.DataLayer.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Entities
{   
    [Table(name:"PrestageTransactions")]
    public class Prestage : Entity<long>
    {
        //[Required]
        //[Column(TypeName = "nvarchar(20)")]
        //public string FromAccount { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(20)")]
        public string CardNumber { get; set; }

        [Required]      
        public int CardExpiryDate { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(15)")]
        public string AccountType { get; set; }

        [Required]
        public int Amount { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(20)")]
        public string ProfileNumber { get; set; }

        public DateTime DateCreated { get; set; }
        public DateTime ValidUpto { get; set; }
        public DateTime? DateChanged { get; set; }

        //[ForeignKey("PrestageStatus")]
        //[Required]
        //public int PrestageStatusId { get; set; }
    
        [Required]
        [Column(TypeName = "nvarchar(12)")]
        public string PrestageStatus { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string StatusMessage { get; set; }

        [ForeignKey("QRCode")]
        public long? QRCodeId { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(max)")]
        public string CreatedToken { get; set; }

        [Column(TypeName = "nvarchar(max)")]
        public string LastModifiedToken { get; set; }

        public virtual QRCode QRCode { get; set; }

       //  public virtual PrestageStatus PrestageStatus { get; set; }

    }
}
