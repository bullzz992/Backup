﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Core
{

    [Serializable]
    public abstract class Entity : IEntity
    {
        /// <inheritdoc/>
        //public override string ToString()
        //{
        //    return $"[ENTITY: {GetType().Name}] Keys = {GetKeys().JoinAsString(", ")}";
        //}

        public abstract object[] GetKeys();
    }

    [Serializable]
    public abstract class Entity<TKey> : Entity, IEntity<TKey>
    {
        /// <inheritdoc/>
        public virtual TKey Id { get; set; }

        protected Entity()
        {

        }

        protected Entity(TKey id)
        {
            Id = id;
        }

        public override object[] GetKeys()
        {
            return new object[] { Id };
        }

        /// <inheritdoc/>
        //public override string ToString()
        //{
        //    return $"[ENTITY: {GetType().Name}] Id = {Id}";
        //}
    }
}
