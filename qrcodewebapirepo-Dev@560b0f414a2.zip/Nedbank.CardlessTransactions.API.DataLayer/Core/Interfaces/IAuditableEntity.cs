﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer
{
    public interface IAuditableEntity
    {
        /// <summary>
        /// Gets or Sets DateCreated
        /// </summary>
        DateTime DateCreated { get; set; }

        /// <summary>
        /// Gets or Sets DateChanged
        /// </summary>
        DateTime? DateChanged { get; set; }

        /// <summary>
        /// Gets or Sets CreatedBy
        /// </summary>
        string CreatedBy { get; set; }

        /// <summary>
        /// Gets or Sets ModifiedBy
        /// </summary>
        string ModifiedBy { get; set; }
    }
}
