using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.DataLayer.Repositories
{
    public interface IEfRepository<TEntity>
        where TEntity : class, IEntity
    {
        Task<IReadOnlyList<TEntity>> ListAllAsync();
        Task<IReadOnlyList<TEntity>> ListAsync(ISpecification<TEntity> spec);
        Task<TEntity> AddAsync(TEntity entity);
        Task AddAsync(params TEntity[] entities);
        Task AddAsync(IEnumerable<TEntity> entities);
        Task UpdateAsync(TEntity entity);
        Task UpdateAsync(params TEntity[] entities);
        Task UpdateAsync(IEnumerable<TEntity> entities);
        Task DeleteAsync(TEntity entity);
        Task DeleteAsync(params TEntity[] entities);
        Task DeleteAsync(IEnumerable<TEntity> entities);
        Task<int> CountAsync(ISpecification<TEntity> spec);
        Task<TEntity> FindSingleByAsync(Expression<Func<TEntity, bool>> predicate);
        Task<TEntity> FindSingleByAsync(ISpecification<TEntity> spec);
        Task<TEntity> FindFirstOrDefaultByAsync(ISpecification<TEntity> spec);
    }

    public interface IEfRepository<TEntity, TKey> : IEfRepository<TEntity>
        where TEntity : class, IEntity<TKey>
    {
        Task<TEntity> GetAsync(TKey id);

        Task DeleteAsync(TKey id);
    }
}