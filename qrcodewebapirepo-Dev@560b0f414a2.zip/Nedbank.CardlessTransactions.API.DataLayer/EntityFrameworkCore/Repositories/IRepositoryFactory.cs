﻿using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nedbank.CardlessTransactions.API.DataLayer.Repositories
{
    public interface IRepositoryFactory
    {
        IEfRepository<TEntity> GetRepositoryAsync<TEntity>() where TEntity : class, IEntity;
    }
}
