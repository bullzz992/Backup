﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.DataLayer.Repositories
{
    public class EfRepository<TEntity> : IEfRepository<TEntity>
         where TEntity : class, IEntity
    {

        protected readonly CardlessTransactionsContext _dbContext;

        public EfRepository(CardlessTransactionsContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IReadOnlyList<TEntity>> ListAllAsync()
        {
            return await _dbContext.Set<TEntity>().ToListAsync();
        }

        public async Task<IReadOnlyList<TEntity>> ListAsync(ISpecification<TEntity> spec)
        {
            return await ApplySpecification(spec).ToListAsync();
        }

        public async Task<TEntity> FindSingleByAsync(ISpecification<TEntity> spec)
        {

            return await ApplySpecification(spec).SingleOrDefaultAsync();

        }

        public async Task<TEntity> FindFirstOrDefaultByAsync(ISpecification<TEntity> spec)
        {

            return await ApplySpecification(spec).FirstOrDefaultAsync();

        }

        public async Task<TEntity> FindSingleByAsync(Expression<Func<TEntity, bool>> predicate)
        {
            if (predicate != null)
            {
                return await _dbContext.Set<TEntity>().SingleOrDefaultAsync(predicate);
            }
            else
            {
                throw new ArgumentNullException("Predicate value must be passed to FindSingleByAsync.");
            }
        }

        public async Task<int> CountAsync(ISpecification<TEntity> spec)
        {
            return await ApplySpecification(spec).CountAsync();
        }

        public async Task<TEntity> AddAsync(TEntity entity)
        {
            await _dbContext.Set<TEntity>().AddAsync(entity);
            //await _dbContext.SaveChangesAsync();

            return entity;
        }

        public async Task AddAsync(params TEntity[] entities)
        {
            await _dbContext.Set<TEntity>().AddRangeAsync(entities);
        }

        public async Task AddAsync(IEnumerable<TEntity> entities)
        {
            await _dbContext.Set<TEntity>().AddRangeAsync(entities);
        }

        public async Task UpdateAsync(TEntity entity)
        {
            _dbContext.Set<TEntity>().Update(entity);

        }

        public async Task UpdateAsync(params TEntity[] entities)
        {
            _dbContext.Set<TEntity>().UpdateRange(entities);
        }

        public async Task UpdateAsync(IEnumerable<TEntity> entities)
        {
            _dbContext.Set<TEntity>().UpdateRange(entities);
        }

        public async Task DeleteAsync(TEntity entity)
        {
            _dbContext.Set<TEntity>().Remove(entity);
            //await _dbContext.SaveChangesAsync();

        }

        public async Task DeleteAsync(params TEntity[] entities)
        {
            _dbContext.Set<TEntity>().RemoveRange(entities);
        }

        public async Task DeleteAsync(IEnumerable<TEntity> entities)
        {
            _dbContext.Set<TEntity>().RemoveRange(entities);
        }

        private IQueryable<TEntity> ApplySpecification(ISpecification<TEntity> spec)
        {
            return SpecificationEvaluator<TEntity>.GetQuery(_dbContext.Set<TEntity>().AsQueryable(), spec);
        }

        //public Task<TEntity> GetAsync()
        //{
        //    throw new NotImplementedException();
        //}
    }

    public class EfRepository<TEntity, TKey> : EfRepository<TEntity>,
       IEfRepository<TEntity, TKey>

       where TEntity : class, IEntity<TKey>
    {
        public EfRepository(CardlessTransactionsContext dbContext)
            : base(dbContext)
        {

        }

        public async Task<TEntity> GetAsync(TKey id)
        {
            return await _dbContext.Set<TEntity>().FindAsync(id);
        }

        public async Task DeleteAsync(TKey id)
        {
            var entity = await GetAsync(id);
            if (entity == null)
            {
                return;
            }

            await base.DeleteAsync(entity);
        }
    }
}
