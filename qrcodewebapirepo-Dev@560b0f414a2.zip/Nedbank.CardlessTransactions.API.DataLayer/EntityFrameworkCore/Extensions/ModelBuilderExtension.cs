﻿using Microsoft.EntityFrameworkCore;
using Nedbank.CardlessTransactions.API.Common.Functional.Enum;
using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using System;

namespace Nedbank.CardlessTransactions.API.DataLayer.Extensions
{
    public static class ModelBuilderExtension
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            // modelBuilder.Entity<PrestageStatus>().HasData(
            //    new PrestageStatus() { Id = 1, Name = "Prestaged" },
            //    new PrestageStatus() { Id = 2, Name = "Completed" },
            //    new PrestageStatus() { Id = 3, Name = "Declined"},
            //    new PrestageStatus() { Id = 4, Name = "Deleted"}
            //);

            modelBuilder.Entity<Prestage>().HasData(
              new Prestage()
              {
                  Id = 1,
                  CardNumber = "card1",
                  CardExpiryDate=2009,
                  AccountType = "Saving",
                  Amount = 1000,
                  ProfileNumber = "Pn1",
                  DateCreated = DateTime.Now,
                  ValidUpto = DateTime.Now.AddHours(8),
                  //PrestageStatusId = 1,
                  PrestageStatus = Statuses.Prestaged.ToString(),
                  QRCodeId = 1,
                  StatusMessage = "Sm1",
                  CreatedToken = "Token1"
              }
          ); ;

            modelBuilder.Entity<QRCode>().HasData(
             new QRCode()
             {
                 Id = 1,
                 TerminalId = "ter1",
                 TransactionId = "tran1",
                 SessionId="sess1",
                 QrCode = $"ter1:tran1:sess1",
                 DateCreated=DateTime.Now,
                 ValidUpto=DateTime.Now.AddSeconds(50),
                 Token= "Token1"
             });

        }

        public static void ConfigureEntities(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Prestage>().Property(p => p.Id).ValueGeneratedOnAdd();
           // modelBuilder.Entity<PrestageStatus>().Property(p => p.Id).ValueGeneratedNever();
            modelBuilder.Entity<QRCode>().Property(p => p.Id).ValueGeneratedOnAdd();
        }
    }
}
