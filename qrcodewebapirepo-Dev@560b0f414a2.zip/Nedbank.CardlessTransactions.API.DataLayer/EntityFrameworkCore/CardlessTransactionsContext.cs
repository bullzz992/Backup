﻿using Microsoft.EntityFrameworkCore;
using Nedbank.CardlessTransactions.API.DataLayer.Entities;
using Nedbank.CardlessTransactions.API.DataLayer.Extensions;
using System;

namespace Nedbank.CardlessTransactions.API.DataLayer
{
    public class CardlessTransactionsContext : DbContext, IDisposable
    {
        private readonly DbContextOptions<CardlessTransactionsContext> options;

        public CardlessTransactionsContext(DbContextOptions<CardlessTransactionsContext> options)
        : base(options)
        {
            this.options = options;
        }


        public DbSet<Prestage> Prestage { get; set; }

        public DbSet<QRCode> QRCode { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfigurationsFromAssembly(typeof(CardlessTransactionsContext).Assembly);
            builder.Seed();
            builder.ConfigureEntities();
        }

    }
}