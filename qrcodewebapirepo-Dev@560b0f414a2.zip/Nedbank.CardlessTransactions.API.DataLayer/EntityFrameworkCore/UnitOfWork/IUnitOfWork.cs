﻿using Microsoft.EntityFrameworkCore;
using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.DataLayer.EntityFrameworkCore.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IEfRepository<TEntity> GetRepositoryAsync<TEntity>() where TEntity : class, IEntity;
        IEfRepository<TEntity, TKey> GetRepositoryAsync<TEntity, TKey>() where TEntity : class, IEntity<TKey>;

        Task<int> CommitAsync();

        void Rollback();

        CardlessTransactionsContext Context { get; set; }

    }
}
