﻿using Nedbank.CardlessTransactions.API.DataLayer.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nedbank.CardlessTransactions.API.DataLayer.EntityFrameworkCore.UnitOfWork
{
    public class UnitOfWork : IRepositoryFactory, IUnitOfWork
    {
        private Dictionary<Type, object> _repositories;
        //private readonly BookingContext _context;
        private bool _disposed;
        public UnitOfWork(CardlessTransactionsContext context)
        {
            this.Context = context;
        }

        public virtual IEfRepository<TEntity> GetRepositoryAsync<TEntity>() where TEntity : class, IEntity
        {
            if (_repositories == null) _repositories = new Dictionary<Type, object>();

            var type = typeof(TEntity);
            if (!_repositories.ContainsKey(type)) _repositories[type] = new EfRepository<TEntity>(this.Context);
            return (IEfRepository<TEntity>)_repositories[type];
        }

        public virtual IEfRepository<TEntity,TKey> GetRepositoryAsync<TEntity, TKey>() where TEntity : class, IEntity<TKey>
        {
            if (_repositories == null) _repositories = new Dictionary<Type, object>();

            var type = typeof(TEntity);
            if (!_repositories.ContainsKey(type)) _repositories[type] = new EfRepository<TEntity, TKey>(this.Context);
            return (IEfRepository<TEntity, TKey>)_repositories[type];
        }



        public async Task<int> CommitAsync()
        {
            int affectedRows = await this.Context.SaveChangesAsync()
              .ConfigureAwait(false);
            return affectedRows;
        }

        public void Rollback()
        {
            this.Context
                .ChangeTracker
                .Entries()
                .ToList()
                .ForEach(x => x.Reload());
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public CardlessTransactionsContext Context { get; set; }

        #region [Private Methods]

        private void Dispose(bool disposing)
        {
            if (!this._disposed)
            {
                if (disposing)
                {
                    this.Context.Dispose();
                }
            }

            this._disposed = true;
        }

       

        #endregion
    }
}
